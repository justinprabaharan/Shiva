module.exports = {
  plugins: ['tailwindcss', 'postcss-flexbugs-fixes', 'autoprefixer'],
};
