/* styleMock.js contents */
// module.exports = {};

export default {};
