/* fileMock.js contents */
// module.exports = 'test-file-stub';

export default 'test-file-stub';
