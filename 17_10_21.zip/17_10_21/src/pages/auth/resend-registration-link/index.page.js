import ResendRegistrationLink from './resend-registration-link';

export default ResendRegistrationLink;
