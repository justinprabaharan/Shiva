import RequestPasswordReset from './request-password-reset';

export default RequestPasswordReset;
