import CompleteEmailChange from './complete-email-change';

export default CompleteEmailChange;
