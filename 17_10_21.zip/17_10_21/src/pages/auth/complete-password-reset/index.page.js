import CompletePasswordReset from './complete-password-reset';

export default CompletePasswordReset;
