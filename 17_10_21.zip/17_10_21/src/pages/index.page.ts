import Home from './home/home';

export default Home;
