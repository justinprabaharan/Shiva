webpackHotUpdate_N_E("pages/_app",{

/***/ "./node_modules/next/dist/compiled/css-loader/cjs.js?!./node_modules/next/dist/compiled/postcss-loader/cjs.js?!./node_modules/next/dist/compiled/resolve-url-loader/index.js?!./node_modules/next/dist/compiled/sass-loader/cjs.js?!./src/styles/login.scss":
false,

/***/ "./src/pages/_app.page.tsx":
/*!*********************************!*\
  !*** ./src/pages/_app.page.tsx ***!
  \*********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var J_Project_reference_aws_amplify_react_auth_master_toshare_aws_amplify_react_auth_master_toshare_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _aws_amplify_auth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @aws-amplify/auth */ "./node_modules/@aws-amplify/auth/lib-esm/index.js");
/* harmony import */ var _components_footer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @components/footer */ "./src/components/footer/index.ts");
/* harmony import */ var _components_layout__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @components/layout */ "./src/components/layout/index.ts");
/* harmony import */ var _components_navbar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @components/navbar */ "./src/components/navbar/index.ts");
/* harmony import */ var _context_auth__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @context/auth */ "./src/context/auth/index.ts");
/* harmony import */ var _context_notification__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @context/notification */ "./src/context/notification/index.ts");
/* harmony import */ var _styles_tailwind_css__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @styles/tailwind.css */ "./src/styles/tailwind.css");
/* harmony import */ var _styles_tailwind_css__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_styles_tailwind_css__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! next-seo */ "./node_modules/next-seo/lib/next-seo.module.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var src_constants__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/constants */ "./src/constants.ts");
/* harmony import */ var src_next_seo_config__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/next-seo-config */ "./src/next-seo-config.ts");
/* harmony import */ var stop_runaway_react_effects_hijack__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! stop-runaway-react-effects/hijack */ "./node_modules/stop-runaway-react-effects/hijack.js");
/* harmony import */ var stop_runaway_react_effects_hijack__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(stop_runaway_react_effects_hijack__WEBPACK_IMPORTED_MODULE_14__);


var _jsxFileName = "J:\\Project\\reference\\aws-amplify-react-auth-master-toshare\\aws-amplify-react-auth-master-toshare\\src\\pages\\_app.page.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(J_Project_reference_aws_amplify_react_auth_master_toshare_aws_amplify_react_auth_master_toshare_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }














_aws_amplify_auth__WEBPACK_IMPORTED_MODULE_2__["default"].configure({
  mandatorySignIn: false,
  region: src_constants__WEBPACK_IMPORTED_MODULE_12__["REGION"],
  userPoolId: src_constants__WEBPACK_IMPORTED_MODULE_12__["USER_POOL_ID"],
  identityPoolId: src_constants__WEBPACK_IMPORTED_MODULE_12__["IDENTITY_POOL_ID"],
  userPoolWebClientId: src_constants__WEBPACK_IMPORTED_MODULE_12__["USER_POOL_CLIENT_ID"]
});
const navbarHeight = '172px';
const footerHeight = '232px';

const App = ({
  Component,
  pageProps
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_11__["StrictMode"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(next_head__WEBPACK_IMPORTED_MODULE_10___default.a, {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("meta", {
        content: "IE=edge",
        httpEquiv: "X-UA-Compatible"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 36,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("meta", {
        content: "width=device-width, initial-scale=1",
        name: "viewport"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 37,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 35,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(next_seo__WEBPACK_IMPORTED_MODULE_9__["DefaultSeo"], _objectSpread({}, src_next_seo_config__WEBPACK_IMPORTED_MODULE_13__["default"]), void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 39,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
      className: "bg-gray-50",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_context_notification__WEBPACK_IMPORTED_MODULE_7__["NotificationProvider"], {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_context_auth__WEBPACK_IMPORTED_MODULE_6__["AuthProvider"], {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_navbar__WEBPACK_IMPORTED_MODULE_5__["Navbar"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 43,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_layout__WEBPACK_IMPORTED_MODULE_4__["Container"], {
            className: "mx-auto",
            style: {
              minHeight: `calc(100vh - ${navbarHeight} - ${footerHeight})`
            },
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(Component, _objectSpread({}, pageProps), void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 50,
              columnNumber: 15
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 44,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 42,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 41,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_footer__WEBPACK_IMPORTED_MODULE_3__["Footer"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 54,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 40,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 34,
    columnNumber: 5
  }, undefined);
};

_c = App;
/* harmony default export */ __webpack_exports__["default"] = (App);

var _c;

$RefreshReg$(_c, "App");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./src/styles/login.scss":
false

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL3BhZ2VzL19hcHAucGFnZS50c3giXSwibmFtZXMiOlsiQXV0aCIsImNvbmZpZ3VyZSIsIm1hbmRhdG9yeVNpZ25JbiIsInJlZ2lvbiIsIlJFR0lPTiIsInVzZXJQb29sSWQiLCJVU0VSX1BPT0xfSUQiLCJpZGVudGl0eVBvb2xJZCIsIklERU5USVRZX1BPT0xfSUQiLCJ1c2VyUG9vbFdlYkNsaWVudElkIiwiVVNFUl9QT09MX0NMSUVOVF9JRCIsIm5hdmJhckhlaWdodCIsImZvb3RlckhlaWdodCIsIkFwcCIsIkNvbXBvbmVudCIsInBhZ2VQcm9wcyIsIlNFTyIsIm1pbkhlaWdodCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQU1BO0FBQ0E7QUFFQUEseURBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQ2JDLGlCQUFlLEVBQUUsS0FESjtBQUViQyxRQUFNLEVBQUVDLHFEQUZLO0FBR2JDLFlBQVUsRUFBRUMsMkRBSEM7QUFJYkMsZ0JBQWMsRUFBRUMsK0RBSkg7QUFLYkMscUJBQW1CLEVBQUVDLGtFQUFtQkE7QUFMM0IsQ0FBZjtBQVFBLE1BQU1DLFlBQVksR0FBRyxPQUFyQjtBQUNBLE1BQU1DLFlBQVksR0FBRyxPQUFyQjs7QUFFQSxNQUFNQyxHQUF1QixHQUFHLENBQUM7QUFBQ0MsV0FBRDtBQUFZQztBQUFaLENBQUQsS0FBNEI7QUFDMUQsc0JBQ0UscUVBQUMsaURBQUQ7QUFBQSw0QkFDRSxxRUFBQyxpREFBRDtBQUFBLDhCQUNFO0FBQU0sZUFBTyxFQUFDLFNBQWQ7QUFBd0IsaUJBQVMsRUFBQztBQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBRUU7QUFBTSxlQUFPLEVBQUMscUNBQWQ7QUFBb0QsWUFBSSxFQUFDO0FBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBS0UscUVBQUMsbURBQUQsb0JBQWdCQyw0REFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFMRixlQU1FO0FBQUssZUFBUyxFQUFDLFlBQWY7QUFBQSw4QkFDRSxxRUFBQywwRUFBRDtBQUFBLCtCQUNFLHFFQUFDLDBEQUFEO0FBQUEsa0NBQ0UscUVBQUMseURBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERixlQUVFLHFFQUFDLDREQUFEO0FBQ0UscUJBQVMsRUFBQyxTQURaO0FBRUUsaUJBQUssRUFBRTtBQUNMQyx1QkFBUyxFQUFHLGdCQUFlTixZQUFhLE1BQUtDLFlBQWE7QUFEckQsYUFGVDtBQUFBLG1DQU1FLHFFQUFDLFNBQUQsb0JBQWVHLFNBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQWNFLHFFQUFDLHlEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBeUJELENBMUJEOztLQUFNRixHO0FBNEJTQSxrRUFBZiIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9fYXBwLmQyYWI5ZDEzNTg1NDdjMzkzNmExLmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgQXV0aCBmcm9tICdAYXdzLWFtcGxpZnkvYXV0aCc7XG5pbXBvcnQge0Zvb3Rlcn0gZnJvbSAnQGNvbXBvbmVudHMvZm9vdGVyJztcbmltcG9ydCB7Q29udGFpbmVyfSBmcm9tICdAY29tcG9uZW50cy9sYXlvdXQnO1xuaW1wb3J0IHtOYXZiYXJ9IGZyb20gJ0Bjb21wb25lbnRzL25hdmJhcic7XG5pbXBvcnQge0F1dGhQcm92aWRlcn0gZnJvbSAnQGNvbnRleHQvYXV0aCc7XG5pbXBvcnQge05vdGlmaWNhdGlvblByb3ZpZGVyfSBmcm9tICdAY29udGV4dC9ub3RpZmljYXRpb24nO1xuaW1wb3J0ICdAc3R5bGVzL3RhaWx3aW5kLmNzcyc7XG5pbXBvcnQge0RlZmF1bHRTZW99IGZyb20gJ25leHQtc2VvJztcbmltcG9ydCB7QXBwUHJvcHN9IGZyb20gJ25leHQvYXBwJztcbmltcG9ydCBIZWFkIGZyb20gJ25leHQvaGVhZCc7XG5pbXBvcnQge1N0cmljdE1vZGV9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7XG4gIElERU5USVRZX1BPT0xfSUQsXG4gIFJFR0lPTixcbiAgVVNFUl9QT09MX0NMSUVOVF9JRCxcbiAgVVNFUl9QT09MX0lELFxufSBmcm9tICdzcmMvY29uc3RhbnRzJztcbmltcG9ydCBTRU8gZnJvbSAnc3JjL25leHQtc2VvLWNvbmZpZyc7XG5pbXBvcnQgJ3N0b3AtcnVuYXdheS1yZWFjdC1lZmZlY3RzL2hpamFjayc7XG5cbkF1dGguY29uZmlndXJlKHtcbiAgbWFuZGF0b3J5U2lnbkluOiBmYWxzZSxcbiAgcmVnaW9uOiBSRUdJT04sXG4gIHVzZXJQb29sSWQ6IFVTRVJfUE9PTF9JRCxcbiAgaWRlbnRpdHlQb29sSWQ6IElERU5USVRZX1BPT0xfSUQsXG4gIHVzZXJQb29sV2ViQ2xpZW50SWQ6IFVTRVJfUE9PTF9DTElFTlRfSUQsXG59KTtcblxuY29uc3QgbmF2YmFySGVpZ2h0ID0gJzE3MnB4JztcbmNvbnN0IGZvb3RlckhlaWdodCA9ICcyMzJweCc7XG5cbmNvbnN0IEFwcDogUmVhY3QuRkM8QXBwUHJvcHM+ID0gKHtDb21wb25lbnQsIHBhZ2VQcm9wc30pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8U3RyaWN0TW9kZT5cbiAgICAgIDxIZWFkPlxuICAgICAgICA8bWV0YSBjb250ZW50PVwiSUU9ZWRnZVwiIGh0dHBFcXVpdj1cIlgtVUEtQ29tcGF0aWJsZVwiIC8+XG4gICAgICAgIDxtZXRhIGNvbnRlbnQ9XCJ3aWR0aD1kZXZpY2Utd2lkdGgsIGluaXRpYWwtc2NhbGU9MVwiIG5hbWU9XCJ2aWV3cG9ydFwiIC8+XG4gICAgICA8L0hlYWQ+XG4gICAgICA8RGVmYXVsdFNlbyB7Li4uU0VPfSAvPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwXCI+XG4gICAgICAgIDxOb3RpZmljYXRpb25Qcm92aWRlcj5cbiAgICAgICAgICA8QXV0aFByb3ZpZGVyPlxuICAgICAgICAgICAgPE5hdmJhciAvPlxuICAgICAgICAgICAgPENvbnRhaW5lclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJteC1hdXRvXCJcbiAgICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICBtaW5IZWlnaHQ6IGBjYWxjKDEwMHZoIC0gJHtuYXZiYXJIZWlnaHR9IC0gJHtmb290ZXJIZWlnaHR9KWAsXG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxDb21wb25lbnQgey4uLnBhZ2VQcm9wc30gLz5cbiAgICAgICAgICAgIDwvQ29udGFpbmVyPlxuICAgICAgICAgIDwvQXV0aFByb3ZpZGVyPlxuICAgICAgICA8L05vdGlmaWNhdGlvblByb3ZpZGVyPlxuICAgICAgICA8Rm9vdGVyIC8+XG4gICAgICA8L2Rpdj5cbiAgICA8L1N0cmljdE1vZGU+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBBcHA7XG4iXSwic291cmNlUm9vdCI6IiJ9