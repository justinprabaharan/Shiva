webpackHotUpdate_N_E("pages/_app",{

/***/ "./src/components/navbar/navbar.tsx":
/*!******************************************!*\
  !*** ./src/components/navbar/navbar.tsx ***!
  \******************************************/
/*! exports provided: Navbar */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Navbar", function() { return Navbar; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_avatar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @components/avatar */ "./src/components/avatar/index.ts");
/* harmony import */ var _components_icons_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @components/icons/icons */ "./src/components/icons/icons.tsx");
/* harmony import */ var _components_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @components/layout */ "./src/components/layout/index.ts");
/* harmony import */ var _components_next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @components/next-link */ "./src/components/next-link/index.ts");
/* harmony import */ var _context_auth__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @context/auth */ "./src/context/auth/index.ts");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_icons_go__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react-icons/go */ "./node_modules/react-icons/go/index.esm.js");
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-icons/hi */ "./node_modules/react-icons/hi/index.esm.js");
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react-icons/io5 */ "./node_modules/react-icons/io5/index.esm.js");
/* harmony import */ var src_constants__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/constants */ "./src/constants.ts");
/* harmony import */ var _active_link__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./active-link */ "./src/components/navbar/active-link.tsx");
/* harmony import */ var _mobile_menu__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./mobile-menu */ "./src/components/navbar/mobile-menu.tsx");
/* harmony import */ var _use_click_outside__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./use-click-outside */ "./src/components/navbar/use-click-outside.ts");
/* harmony import */ var _use_logout__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./use-logout */ "./src/components/navbar/use-logout.tsx");
/* harmony import */ var _user_dropdown__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./user-dropdown */ "./src/components/navbar/user-dropdown.tsx");



var _jsxFileName = "J:\\Project\\reference\\aws-amplify-react-auth-master-toshare\\aws-amplify-react-auth-master-toshare\\src\\components\\navbar\\navbar.tsx",
    _s = $RefreshSig$();

















const commonLinks = [{
  href: '/',
  text: 'Home'
}];
const anonymousDropdownLinks = [{
  href: src_constants__WEBPACK_IMPORTED_MODULE_11__["ROUTE_PATHS"].LOGIN,
  text: 'Log in',
  icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(LoginIcon, {
    className: "inline w-5 h-5 mr-2 text-gray-800 align-text-bottom"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 25,
    columnNumber: 7
  }, undefined)
}, {
  href: src_constants__WEBPACK_IMPORTED_MODULE_11__["ROUTE_PATHS"].REGISTER,
  text: 'Sign Up',
  icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(HashTagIcon, {
    className: "inline w-5 h-5 mr-2 align-text-bottom"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 31,
    columnNumber: 11
  }, undefined)
}];
const authenticatedDropdownLinks = [{
  href: src_constants__WEBPACK_IMPORTED_MODULE_11__["ROUTE_PATHS"].SETTINGS,
  text: 'Settings',
  icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(CogIcon, {
    className: "inline w-5 h-5 mr-2 align-text-bottom"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 39,
    columnNumber: 11
  }, undefined)
}];
function Navbar() {
  _s();

  const {
    state: {
      isAuthenticated,
      user
    },
    initializeUser
  } = Object(_context_auth__WEBPACK_IMPORTED_MODULE_5__["useAuth"])();
  const handleLogout = Object(_use_logout__WEBPACK_IMPORTED_MODULE_15__["useLogout"])();
  Object(react__WEBPACK_IMPORTED_MODULE_7__["useEffect"])(() => {
    initializeUser();
  }, [initializeUser]);
  const {
    0: showsUserDropdown,
    1: setShowsUserDropdown
  } = Object(react__WEBPACK_IMPORTED_MODULE_7__["useState"])(false);
  const {
    0: showsMobileMenu,
    1: setShowsMobileMenu
  } = Object(react__WEBPACK_IMPORTED_MODULE_7__["useState"])(false);

  const closeMobileMenu = () => setShowsMobileMenu(false);

  const closeUserDropdown = () => setShowsUserDropdown(false);

  const closeMenus = () => {
    closeMobileMenu();
    closeUserDropdown();
  };

  const navbarRef = Object(react__WEBPACK_IMPORTED_MODULE_7__["useRef"])(null);
  Object(_use_click_outside__WEBPACK_IMPORTED_MODULE_14__["useClickOutside"])(navbarRef, closeMenus);

  const toggleUserDropdown = () => {
    setShowsUserDropdown(prev => !prev);
    closeMobileMenu();
  };

  const toggleMobileMenu = () => {
    setShowsMobileMenu(prev => !prev);
    closeUserDropdown();
  };

  const links = [...commonLinks];

  if (isAuthenticated) {
    if (user !== null && user !== void 0 && user.isAdmin) {
      links.push({
        href: src_constants__WEBPACK_IMPORTED_MODULE_11__["ROUTE_PATHS"].CONTACTS,
        text: 'Contacts'
      });
    }
  }

  const dropdownLinks = isAuthenticated ? authenticatedDropdownLinks : anonymousDropdownLinks;
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "bg-gray-50",
      style: {
        minHeight: '172px'
      },
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("nav", {
        ref: navbarRef,
        className: "bg-purple",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "px-2 mx-auto max-w-7xl sm:px-6 lg:px-8",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_layout__WEBPACK_IMPORTED_MODULE_3__["Flex"], {
            className: "relative justify-between h-16",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_layout__WEBPACK_IMPORTED_MODULE_3__["Flex"], {
              className: "absolute inset-y-0 left-0 items-center sm:hidden",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_mobile_menu__WEBPACK_IMPORTED_MODULE_13__["MobileMenuButton"], {
                onClick: toggleMobileMenu,
                children: showsMobileMenu ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_icons_icons__WEBPACK_IMPORTED_MODULE_2__["CloseIcon"], {}, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 97,
                  columnNumber: 38
                }, this) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(BurgerIcon, {}, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 97,
                  columnNumber: 54
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 96,
                columnNumber: 17
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 95,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_layout__WEBPACK_IMPORTED_MODULE_3__["Flex"], {
              className: "items-center justify-center flex-1 sm:items-stretch sm:justify-start",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_layout__WEBPACK_IMPORTED_MODULE_3__["Flex"], {
                className: "items-center flex-shrink-0",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_next_link__WEBPACK_IMPORTED_MODULE_4__["NextLink"], {
                  href: "/",
                  className: "text-gray-900 title-font md:mb-0",
                  "aria-label": "home",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(BrandIcon, {}, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 107,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 102,
                  columnNumber: 19
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 101,
                columnNumber: 17
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "hidden sm:ml-6 sm:flex sm:space-x-8",
                children: links.map(link => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_active_link__WEBPACK_IMPORTED_MODULE_12__["ActiveLink"], {
                  href: link.href,
                  activeClassName: "border-indigo-500 text-gray-900",
                  inactiveClassName: "border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                    className: "inline-flex items-center px-1 pt-1 text-base font-medium border-b-2",
                    children: link.text
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 119,
                    columnNumber: 23
                  }, this)
                }, link.href, false, {
                  fileName: _jsxFileName,
                  lineNumber: 113,
                  columnNumber: 21
                }, this))
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 111,
                columnNumber: 17
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 100,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_layout__WEBPACK_IMPORTED_MODULE_3__["Flex"], {
              className: "absolute inset-y-0 right-0 items-center pr-2 sm:static sm:inset-auto sm:ml-6 sm:pr-0",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "relative ml-3",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_user_dropdown__WEBPACK_IMPORTED_MODULE_16__["UserDropdownButton"], {
                    onClick: toggleUserDropdown,
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_avatar__WEBPACK_IMPORTED_MODULE_1__["Avatar"], {
                      src: (user === null || user === void 0 ? void 0 : user.picture) || ''
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 130,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 129,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 128,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_user_dropdown__WEBPACK_IMPORTED_MODULE_16__["UserDropdownLinks"], {
                  className: `${!showsUserDropdown ? 'hidden' : ''} absolute right-0 w-48 py-1 mt-2 origin-top-right bg-white rounded-md shadow-lg ring-1 ring-black ring-opacity-5 z-50`,
                  children: [dropdownLinks.map(link => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_6___default.a, {
                    href: link.href,
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                      onClick: closeUserDropdown,
                      role: "menuitem",
                      className: "block px-4 py-2 text-lg text-gray-700 hover:bg-gray-100",
                      children: [link.icon, link.text]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 140,
                      columnNumber: 25
                    }, this)
                  }, link.href, false, {
                    fileName: _jsxFileName,
                    lineNumber: 139,
                    columnNumber: 23
                  }, this)), isAuthenticated && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(LogoutButton, {
                    onClick: () => {
                      handleLogout();
                      closeUserDropdown();
                    },
                    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(LogoutIcon, {
                      className: "inline w-5 h-5 mr-2 align-text-bottom"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 157,
                      columnNumber: 25
                    }, this), ' ', "Log Out"]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 151,
                    columnNumber: 23
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 133,
                  columnNumber: 19
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 127,
                columnNumber: 17
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 126,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 94,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 93,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_mobile_menu__WEBPACK_IMPORTED_MODULE_13__["MobileMenuLinks"], {
          className: `${showsMobileMenu ? 'block' : 'hidden'} sm:hidden`,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "pt-2 pb-4 space-y-1",
            children: links.map(link => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_active_link__WEBPACK_IMPORTED_MODULE_12__["ActiveLink"], {
              href: link.href,
              activeClassName: "bg-indigo-50 border-indigo-500 text-indigo-700",
              inactiveClassName: "border-transparent text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-700",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                onClick: closeMobileMenu,
                role: "link",
                className: "block py-2 pl-3 pr-4 text-base font-medium border-l-4",
                children: link.text
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 178,
                columnNumber: 19
              }, this)
            }, link.href, false, {
              fileName: _jsxFileName,
              lineNumber: 172,
              columnNumber: 17
            }, this))
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 170,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 167,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 92,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 91,
      columnNumber: 7
    }, this)
  }, void 0, false);
}

_s(Navbar, "mFHTvwG1Dp2L1QeC4EI9lkvDyII=", false, function () {
  return [_context_auth__WEBPACK_IMPORTED_MODULE_5__["useAuth"], _use_logout__WEBPACK_IMPORTED_MODULE_15__["useLogout"], _use_click_outside__WEBPACK_IMPORTED_MODULE_14__["useClickOutside"]];
});

_c = Navbar;

function LogoutButton({
  onClick,
  children
}) {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_6___default.a, {
    href: "#",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
      onClick: onClick,
      className: "block px-4 py-2 text-lg text-gray-700 hover:bg-gray-100",
      role: "menuitem",
      children: children
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 204,
      columnNumber: 7
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 203,
    columnNumber: 5
  }, this);
}

_c2 = LogoutButton;

function BurgerIcon({
  className = 'w-6 h-6'
}) {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_icons_hi__WEBPACK_IMPORTED_MODULE_9__["HiMenu"], {
    className: className
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 216,
    columnNumber: 10
  }, this);
}

_c3 = BurgerIcon;

function BrandIcon() {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_icons_io5__WEBPACK_IMPORTED_MODULE_10__["IoCubeSharp"], {
    className: "p-2 text-gray-700 rounded-full w-9 h-9 bg-gray-50 hover:bg-gray-200",
    fill: "currentColor",
    stroke: "currentColor"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 221,
    columnNumber: 5
  }, this);
}

_c4 = BrandIcon;

function CogIcon({
  className
}) {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_icons_hi__WEBPACK_IMPORTED_MODULE_9__["HiCog"], {
    className: className
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 230,
    columnNumber: 10
  }, this);
}

_c5 = CogIcon;

function LogoutIcon({
  className
}) {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_icons_go__WEBPACK_IMPORTED_MODULE_8__["GoSignOut"], {
    className: className
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 234,
    columnNumber: 10
  }, this);
}

_c6 = LogoutIcon;

function LoginIcon({
  className
}) {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_icons_go__WEBPACK_IMPORTED_MODULE_8__["GoSignIn"], {
    className: className
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 238,
    columnNumber: 10
  }, this);
}

_c7 = LoginIcon;

function HashTagIcon({
  className
}) {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_icons_hi__WEBPACK_IMPORTED_MODULE_9__["HiHashtag"], {
    className: className
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 242,
    columnNumber: 10
  }, this);
}

_c8 = HashTagIcon;

var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8;

$RefreshReg$(_c, "Navbar");
$RefreshReg$(_c2, "LogoutButton");
$RefreshReg$(_c3, "BurgerIcon");
$RefreshReg$(_c4, "BrandIcon");
$RefreshReg$(_c5, "CogIcon");
$RefreshReg$(_c6, "LogoutIcon");
$RefreshReg$(_c7, "LoginIcon");
$RefreshReg$(_c8, "HashTagIcon");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvbmF2YmFyL25hdmJhci50c3giXSwibmFtZXMiOlsiY29tbW9uTGlua3MiLCJocmVmIiwidGV4dCIsImFub255bW91c0Ryb3Bkb3duTGlua3MiLCJST1VURV9QQVRIUyIsIkxPR0lOIiwiaWNvbiIsIlJFR0lTVEVSIiwiYXV0aGVudGljYXRlZERyb3Bkb3duTGlua3MiLCJTRVRUSU5HUyIsIk5hdmJhciIsInN0YXRlIiwiaXNBdXRoZW50aWNhdGVkIiwidXNlciIsImluaXRpYWxpemVVc2VyIiwidXNlQXV0aCIsImhhbmRsZUxvZ291dCIsInVzZUxvZ291dCIsInVzZUVmZmVjdCIsInNob3dzVXNlckRyb3Bkb3duIiwic2V0U2hvd3NVc2VyRHJvcGRvd24iLCJ1c2VTdGF0ZSIsInNob3dzTW9iaWxlTWVudSIsInNldFNob3dzTW9iaWxlTWVudSIsImNsb3NlTW9iaWxlTWVudSIsImNsb3NlVXNlckRyb3Bkb3duIiwiY2xvc2VNZW51cyIsIm5hdmJhclJlZiIsInVzZVJlZiIsInVzZUNsaWNrT3V0c2lkZSIsInRvZ2dsZVVzZXJEcm9wZG93biIsInByZXYiLCJ0b2dnbGVNb2JpbGVNZW51IiwibGlua3MiLCJpc0FkbWluIiwicHVzaCIsIkNPTlRBQ1RTIiwiZHJvcGRvd25MaW5rcyIsIm1pbkhlaWdodCIsIm1hcCIsImxpbmsiLCJwaWN0dXJlIiwiTG9nb3V0QnV0dG9uIiwib25DbGljayIsImNoaWxkcmVuIiwiQnVyZ2VySWNvbiIsImNsYXNzTmFtZSIsIkJyYW5kSWNvbiIsIkNvZ0ljb24iLCJMb2dvdXRJY29uIiwiTG9naW5JY29uIiwiSGFzaFRhZ0ljb24iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQSxNQUFNQSxXQUFXLEdBQUcsQ0FBQztBQUFDQyxNQUFJLEVBQUUsR0FBUDtBQUFZQyxNQUFJLEVBQUU7QUFBbEIsQ0FBRCxDQUFwQjtBQUVBLE1BQU1DLHNCQUFzQixHQUFHLENBQzdCO0FBQ0VGLE1BQUksRUFBRUcsMERBQVcsQ0FBQ0MsS0FEcEI7QUFFRUgsTUFBSSxFQUFFLFFBRlI7QUFHRUksTUFBSSxlQUNGLHFFQUFDLFNBQUQ7QUFBVyxhQUFTLEVBQUM7QUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUpKLENBRDZCLEVBUTdCO0FBQ0VMLE1BQUksRUFBRUcsMERBQVcsQ0FBQ0csUUFEcEI7QUFFRUwsTUFBSSxFQUFFLFNBRlI7QUFHRUksTUFBSSxlQUFFLHFFQUFDLFdBQUQ7QUFBYSxhQUFTLEVBQUM7QUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUhSLENBUjZCLENBQS9CO0FBZUEsTUFBTUUsMEJBQTBCLEdBQUcsQ0FDakM7QUFDRVAsTUFBSSxFQUFFRywwREFBVyxDQUFDSyxRQURwQjtBQUVFUCxNQUFJLEVBQUUsVUFGUjtBQUdFSSxNQUFJLGVBQUUscUVBQUMsT0FBRDtBQUFTLGFBQVMsRUFBQztBQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSFIsQ0FEaUMsQ0FBbkM7QUFRTyxTQUFTSSxNQUFULEdBQWtCO0FBQUE7O0FBQ3ZCLFFBQU07QUFDSkMsU0FBSyxFQUFFO0FBQUNDLHFCQUFEO0FBQWtCQztBQUFsQixLQURIO0FBRUpDO0FBRkksTUFHRkMsNkRBQU8sRUFIWDtBQUlBLFFBQU1DLFlBQVksR0FBR0MsOERBQVMsRUFBOUI7QUFDQUMseURBQVMsQ0FBQyxNQUFNO0FBQ2RKLGtCQUFjO0FBQ2YsR0FGUSxFQUVOLENBQUNBLGNBQUQsQ0FGTSxDQUFUO0FBSUEsUUFBTTtBQUFBLE9BQUNLLGlCQUFEO0FBQUEsT0FBb0JDO0FBQXBCLE1BQTRDQyxzREFBUSxDQUFDLEtBQUQsQ0FBMUQ7QUFDQSxRQUFNO0FBQUEsT0FBQ0MsZUFBRDtBQUFBLE9BQWtCQztBQUFsQixNQUF3Q0Ysc0RBQVEsQ0FBQyxLQUFELENBQXREOztBQUNBLFFBQU1HLGVBQWUsR0FBRyxNQUFNRCxrQkFBa0IsQ0FBQyxLQUFELENBQWhEOztBQUNBLFFBQU1FLGlCQUFpQixHQUFHLE1BQU1MLG9CQUFvQixDQUFDLEtBQUQsQ0FBcEQ7O0FBRUEsUUFBTU0sVUFBVSxHQUFHLE1BQU07QUFDdkJGLG1CQUFlO0FBQ2ZDLHFCQUFpQjtBQUNsQixHQUhEOztBQUtBLFFBQU1FLFNBQVMsR0FBR0Msb0RBQU0sQ0FBaUIsSUFBakIsQ0FBeEI7QUFFQUMsNkVBQWUsQ0FBQ0YsU0FBRCxFQUFZRCxVQUFaLENBQWY7O0FBRUEsUUFBTUksa0JBQWtCLEdBQUcsTUFBTTtBQUMvQlYsd0JBQW9CLENBQUNXLElBQUksSUFBSSxDQUFDQSxJQUFWLENBQXBCO0FBQ0FQLG1CQUFlO0FBQ2hCLEdBSEQ7O0FBS0EsUUFBTVEsZ0JBQWdCLEdBQUcsTUFBTTtBQUM3QlQsc0JBQWtCLENBQUNRLElBQUksSUFBSSxDQUFDQSxJQUFWLENBQWxCO0FBQ0FOLHFCQUFpQjtBQUNsQixHQUhEOztBQUtBLFFBQU1RLEtBQUssR0FBRyxDQUFDLEdBQUdqQyxXQUFKLENBQWQ7O0FBRUEsTUFBSVksZUFBSixFQUFxQjtBQUNuQixRQUFJQyxJQUFKLGFBQUlBLElBQUosZUFBSUEsSUFBSSxDQUFFcUIsT0FBVixFQUFtQjtBQUNqQkQsV0FBSyxDQUFDRSxJQUFOLENBQVc7QUFBQ2xDLFlBQUksRUFBRUcsMERBQVcsQ0FBQ2dDLFFBQW5CO0FBQTZCbEMsWUFBSSxFQUFFO0FBQW5DLE9BQVg7QUFDRDtBQUNGOztBQUVELFFBQU1tQyxhQUFhLEdBQUd6QixlQUFlLEdBQ2pDSiwwQkFEaUMsR0FFakNMLHNCQUZKO0FBSUEsc0JBQ0U7QUFBQSwyQkFDRTtBQUFLLGVBQVMsRUFBQyxZQUFmO0FBQTRCLFdBQUssRUFBRTtBQUFDbUMsaUJBQVMsRUFBRTtBQUFaLE9BQW5DO0FBQUEsNkJBQ0U7QUFBSyxXQUFHLEVBQUVYLFNBQVY7QUFBcUIsaUJBQVMsRUFBQyxXQUEvQjtBQUFBLGdDQUNFO0FBQUssbUJBQVMsRUFBQyx3Q0FBZjtBQUFBLGlDQUNFLHFFQUFDLHVEQUFEO0FBQU0scUJBQVMsRUFBQywrQkFBaEI7QUFBQSxvQ0FDRSxxRUFBQyx1REFBRDtBQUFNLHVCQUFTLEVBQUMsa0RBQWhCO0FBQUEscUNBQ0UscUVBQUMsOERBQUQ7QUFBa0IsdUJBQU8sRUFBRUssZ0JBQTNCO0FBQUEsMEJBQ0dWLGVBQWUsZ0JBQUcscUVBQUMsaUVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFBSCxnQkFBbUIscUVBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQURGLGVBTUUscUVBQUMsdURBQUQ7QUFBTSx1QkFBUyxFQUFDLHNFQUFoQjtBQUFBLHNDQUNFLHFFQUFDLHVEQUFEO0FBQU0seUJBQVMsRUFBQyw0QkFBaEI7QUFBQSx1Q0FDRSxxRUFBQyw4REFBRDtBQUNFLHNCQUFJLEVBQUMsR0FEUDtBQUVFLDJCQUFTLEVBQUMsa0NBRlo7QUFHRSxnQ0FBVyxNQUhiO0FBQUEseUNBS0UscUVBQUMsU0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBREYsZUFXRTtBQUFLLHlCQUFTLEVBQUMscUNBQWY7QUFBQSwwQkFDR1csS0FBSyxDQUFDTSxHQUFOLENBQVVDLElBQUksaUJBQ2IscUVBQUMsd0RBQUQ7QUFFRSxzQkFBSSxFQUFFQSxJQUFJLENBQUN2QyxJQUZiO0FBR0UsaUNBQWUsRUFBQyxpQ0FIbEI7QUFJRSxtQ0FBaUIsRUFBQyw0RUFKcEI7QUFBQSx5Q0FNRTtBQUFHLDZCQUFTLEVBQUMscUVBQWI7QUFBQSw4QkFDR3VDLElBQUksQ0FBQ3RDO0FBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQU5GLG1CQUNPc0MsSUFBSSxDQUFDdkMsSUFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUREO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBTkYsZUFnQ0UscUVBQUMsdURBQUQ7QUFBTSx1QkFBUyxFQUFDLHNGQUFoQjtBQUFBLHFDQUNFO0FBQUsseUJBQVMsRUFBQyxlQUFmO0FBQUEsd0NBQ0U7QUFBQSx5Q0FDRSxxRUFBQyxrRUFBRDtBQUFvQiwyQkFBTyxFQUFFNkIsa0JBQTdCO0FBQUEsMkNBQ0UscUVBQUMseURBQUQ7QUFBUSx5QkFBRyxFQUFFLENBQUFqQixJQUFJLFNBQUosSUFBQUEsSUFBSSxXQUFKLFlBQUFBLElBQUksQ0FBRTRCLE9BQU4sS0FBaUI7QUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQURGLGVBTUUscUVBQUMsaUVBQUQ7QUFDRSwyQkFBUyxFQUFHLEdBQ1YsQ0FBQ3RCLGlCQUFELEdBQXFCLFFBQXJCLEdBQWdDLEVBQ2pDLHVIQUhIO0FBQUEsNkJBS0drQixhQUFhLENBQUNFLEdBQWQsQ0FBa0JDLElBQUksaUJBQ3JCLHFFQUFDLGdEQUFEO0FBQXNCLHdCQUFJLEVBQUVBLElBQUksQ0FBQ3ZDLElBQWpDO0FBQUEsMkNBQ0U7QUFDRSw2QkFBTyxFQUFFd0IsaUJBRFg7QUFFRSwwQkFBSSxFQUFDLFVBRlA7QUFHRSwrQkFBUyxFQUFDLHlEQUhaO0FBQUEsaUNBS0dlLElBQUksQ0FBQ2xDLElBTFIsRUFNR2tDLElBQUksQ0FBQ3RDLElBTlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREYscUJBQVdzQyxJQUFJLENBQUN2QyxJQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQURELENBTEgsRUFpQkdXLGVBQWUsaUJBQ2QscUVBQUMsWUFBRDtBQUNFLDJCQUFPLEVBQUUsTUFBTTtBQUNiSSxrQ0FBWTtBQUNaUyx1Q0FBaUI7QUFDbEIscUJBSkg7QUFBQSw0Q0FNRSxxRUFBQyxVQUFEO0FBQVksK0JBQVMsRUFBQztBQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQU5GLEVBTW1FLEdBTm5FO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFsQko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBREYsZUEyRUUscUVBQUMsNkRBQUQ7QUFDRSxtQkFBUyxFQUFHLEdBQUVILGVBQWUsR0FBRyxPQUFILEdBQWEsUUFBUyxZQURyRDtBQUFBLGlDQUdFO0FBQUsscUJBQVMsRUFBQyxxQkFBZjtBQUFBLHNCQUNHVyxLQUFLLENBQUNNLEdBQU4sQ0FBVUMsSUFBSSxpQkFDYixxRUFBQyx3REFBRDtBQUVFLGtCQUFJLEVBQUVBLElBQUksQ0FBQ3ZDLElBRmI7QUFHRSw2QkFBZSxFQUFDLGdEQUhsQjtBQUlFLCtCQUFpQixFQUFDLDZGQUpwQjtBQUFBLHFDQU1FO0FBQ0UsdUJBQU8sRUFBRXVCLGVBRFg7QUFFRSxvQkFBSSxFQUFDLE1BRlA7QUFHRSx5QkFBUyxFQUFDLHVEQUhaO0FBQUEsMEJBS0dnQixJQUFJLENBQUN0QztBQUxSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFORixlQUNPc0MsSUFBSSxDQUFDdkMsSUFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUREO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBM0VGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERixtQkFERjtBQXdHRDs7R0F0SmVTLE07VUFJVksscUQsRUFDaUJFLHNELEVBaUJyQlksbUU7OztLQXRCY25CLE07O0FBd0poQixTQUFTZ0MsWUFBVCxDQUFzQjtBQUNwQkMsU0FEb0I7QUFFcEJDO0FBRm9CLENBQXRCLEVBTUc7QUFDRCxzQkFDRSxxRUFBQyxnREFBRDtBQUFNLFFBQUksRUFBQyxHQUFYO0FBQUEsMkJBQ0U7QUFDRSxhQUFPLEVBQUVELE9BRFg7QUFFRSxlQUFTLEVBQUMseURBRlo7QUFHRSxVQUFJLEVBQUMsVUFIUDtBQUFBLGdCQUtHQztBQUxIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUFXRDs7TUFsQlFGLFk7O0FBb0JULFNBQVNHLFVBQVQsQ0FBb0I7QUFBQ0MsV0FBUyxHQUFHO0FBQWIsQ0FBcEIsRUFBNkM7QUFDM0Msc0JBQU8scUVBQUMscURBQUQ7QUFBUSxhQUFTLEVBQUVBO0FBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFBUDtBQUNEOztNQUZRRCxVOztBQUlULFNBQVNFLFNBQVQsR0FBcUI7QUFDbkIsc0JBQ0UscUVBQUMsNERBQUQ7QUFDRSxhQUFTLEVBQUMscUVBRFo7QUFFRSxRQUFJLEVBQUMsY0FGUDtBQUdFLFVBQU0sRUFBQztBQUhUO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQU9EOztNQVJRQSxTOztBQVVULFNBQVNDLE9BQVQsQ0FBaUI7QUFBQ0Y7QUFBRCxDQUFqQixFQUFtRDtBQUNqRCxzQkFBTyxxRUFBQyxvREFBRDtBQUFPLGFBQVMsRUFBRUE7QUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUFQO0FBQ0Q7O01BRlFFLE87O0FBSVQsU0FBU0MsVUFBVCxDQUFvQjtBQUFDSDtBQUFELENBQXBCLEVBQXNEO0FBQ3BELHNCQUFPLHFFQUFDLHdEQUFEO0FBQVcsYUFBUyxFQUFFQTtBQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBQVA7QUFDRDs7TUFGUUcsVTs7QUFJVCxTQUFTQyxTQUFULENBQW1CO0FBQUNKO0FBQUQsQ0FBbkIsRUFBcUQ7QUFDbkQsc0JBQU8scUVBQUMsdURBQUQ7QUFBVSxhQUFTLEVBQUVBO0FBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFBUDtBQUNEOztNQUZRSSxTOztBQUlULFNBQVNDLFdBQVQsQ0FBcUI7QUFBQ0w7QUFBRCxDQUFyQixFQUF1RDtBQUNyRCxzQkFBTyxxRUFBQyx3REFBRDtBQUFXLGFBQVMsRUFBRUE7QUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUFQO0FBQ0Q7O01BRlFLLFciLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvX2FwcC42NTA3NDE1NzIzZTg3MDdlMTExMi5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtBdmF0YXJ9IGZyb20gJ0Bjb21wb25lbnRzL2F2YXRhcic7XG5pbXBvcnQge0Nsb3NlSWNvbn0gZnJvbSAnQGNvbXBvbmVudHMvaWNvbnMvaWNvbnMnO1xuaW1wb3J0IHtGbGV4fSBmcm9tICdAY29tcG9uZW50cy9sYXlvdXQnO1xuaW1wb3J0IHtOZXh0TGlua30gZnJvbSAnQGNvbXBvbmVudHMvbmV4dC1saW5rJztcbmltcG9ydCB7dXNlQXV0aH0gZnJvbSAnQGNvbnRleHQvYXV0aCc7XG5pbXBvcnQgTGluayBmcm9tICduZXh0L2xpbmsnO1xuaW1wb3J0IHtSZWFjdE5vZGUsIHVzZUVmZmVjdCwgdXNlUmVmLCB1c2VTdGF0ZX0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHtHb1NpZ25JbiwgR29TaWduT3V0fSBmcm9tICdyZWFjdC1pY29ucy9nbyc7XG5pbXBvcnQge0hpQ29nLCBIaUhhc2h0YWcsIEhpTWVudX0gZnJvbSAncmVhY3QtaWNvbnMvaGknO1xuaW1wb3J0IHtJb0N1YmVTaGFycH0gZnJvbSAncmVhY3QtaWNvbnMvaW81JztcbmltcG9ydCB7Uk9VVEVfUEFUSFN9IGZyb20gJ3NyYy9jb25zdGFudHMnO1xuaW1wb3J0IHtBY3RpdmVMaW5rfSBmcm9tICcuL2FjdGl2ZS1saW5rJztcbmltcG9ydCB7TW9iaWxlTWVudUJ1dHRvbiwgTW9iaWxlTWVudUxpbmtzfSBmcm9tICcuL21vYmlsZS1tZW51JztcbmltcG9ydCB7dXNlQ2xpY2tPdXRzaWRlfSBmcm9tICcuL3VzZS1jbGljay1vdXRzaWRlJztcbmltcG9ydCB7dXNlTG9nb3V0fSBmcm9tICcuL3VzZS1sb2dvdXQnO1xuaW1wb3J0IHtVc2VyRHJvcGRvd25CdXR0b24sIFVzZXJEcm9wZG93bkxpbmtzfSBmcm9tICcuL3VzZXItZHJvcGRvd24nO1xuXG5jb25zdCBjb21tb25MaW5rcyA9IFt7aHJlZjogJy8nLCB0ZXh0OiAnSG9tZSd9XTtcblxuY29uc3QgYW5vbnltb3VzRHJvcGRvd25MaW5rcyA9IFtcbiAge1xuICAgIGhyZWY6IFJPVVRFX1BBVEhTLkxPR0lOLFxuICAgIHRleHQ6ICdMb2cgaW4nLFxuICAgIGljb246IChcbiAgICAgIDxMb2dpbkljb24gY2xhc3NOYW1lPVwiaW5saW5lIHctNSBoLTUgbXItMiB0ZXh0LWdyYXktODAwIGFsaWduLXRleHQtYm90dG9tXCIgLz5cbiAgICApLFxuICB9LFxuICB7XG4gICAgaHJlZjogUk9VVEVfUEFUSFMuUkVHSVNURVIsXG4gICAgdGV4dDogJ1NpZ24gVXAnLFxuICAgIGljb246IDxIYXNoVGFnSWNvbiBjbGFzc05hbWU9XCJpbmxpbmUgdy01IGgtNSBtci0yIGFsaWduLXRleHQtYm90dG9tXCIgLz4sXG4gIH0sXG5dO1xuXG5jb25zdCBhdXRoZW50aWNhdGVkRHJvcGRvd25MaW5rcyA9IFtcbiAge1xuICAgIGhyZWY6IFJPVVRFX1BBVEhTLlNFVFRJTkdTLFxuICAgIHRleHQ6ICdTZXR0aW5ncycsXG4gICAgaWNvbjogPENvZ0ljb24gY2xhc3NOYW1lPVwiaW5saW5lIHctNSBoLTUgbXItMiBhbGlnbi10ZXh0LWJvdHRvbVwiIC8+LFxuICB9LFxuXTtcblxuZXhwb3J0IGZ1bmN0aW9uIE5hdmJhcigpIHtcbiAgY29uc3Qge1xuICAgIHN0YXRlOiB7aXNBdXRoZW50aWNhdGVkLCB1c2VyfSxcbiAgICBpbml0aWFsaXplVXNlcixcbiAgfSA9IHVzZUF1dGgoKTtcbiAgY29uc3QgaGFuZGxlTG9nb3V0ID0gdXNlTG9nb3V0KCk7XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaW5pdGlhbGl6ZVVzZXIoKTtcbiAgfSwgW2luaXRpYWxpemVVc2VyXSk7XG5cbiAgY29uc3QgW3Nob3dzVXNlckRyb3Bkb3duLCBzZXRTaG93c1VzZXJEcm9wZG93bl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtzaG93c01vYmlsZU1lbnUsIHNldFNob3dzTW9iaWxlTWVudV0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IGNsb3NlTW9iaWxlTWVudSA9ICgpID0+IHNldFNob3dzTW9iaWxlTWVudShmYWxzZSk7XG4gIGNvbnN0IGNsb3NlVXNlckRyb3Bkb3duID0gKCkgPT4gc2V0U2hvd3NVc2VyRHJvcGRvd24oZmFsc2UpO1xuXG4gIGNvbnN0IGNsb3NlTWVudXMgPSAoKSA9PiB7XG4gICAgY2xvc2VNb2JpbGVNZW51KCk7XG4gICAgY2xvc2VVc2VyRHJvcGRvd24oKTtcbiAgfTtcblxuICBjb25zdCBuYXZiYXJSZWYgPSB1c2VSZWY8SFRNTERpdkVsZW1lbnQ+KG51bGwpO1xuXG4gIHVzZUNsaWNrT3V0c2lkZShuYXZiYXJSZWYsIGNsb3NlTWVudXMpO1xuXG4gIGNvbnN0IHRvZ2dsZVVzZXJEcm9wZG93biA9ICgpID0+IHtcbiAgICBzZXRTaG93c1VzZXJEcm9wZG93bihwcmV2ID0+ICFwcmV2KTtcbiAgICBjbG9zZU1vYmlsZU1lbnUoKTtcbiAgfTtcblxuICBjb25zdCB0b2dnbGVNb2JpbGVNZW51ID0gKCkgPT4ge1xuICAgIHNldFNob3dzTW9iaWxlTWVudShwcmV2ID0+ICFwcmV2KTtcbiAgICBjbG9zZVVzZXJEcm9wZG93bigpO1xuICB9O1xuXG4gIGNvbnN0IGxpbmtzID0gWy4uLmNvbW1vbkxpbmtzXTtcblxuICBpZiAoaXNBdXRoZW50aWNhdGVkKSB7XG4gICAgaWYgKHVzZXI/LmlzQWRtaW4pIHtcbiAgICAgIGxpbmtzLnB1c2goe2hyZWY6IFJPVVRFX1BBVEhTLkNPTlRBQ1RTLCB0ZXh0OiAnQ29udGFjdHMnfSk7XG4gICAgfVxuICB9XG5cbiAgY29uc3QgZHJvcGRvd25MaW5rcyA9IGlzQXV0aGVudGljYXRlZFxuICAgID8gYXV0aGVudGljYXRlZERyb3Bkb3duTGlua3NcbiAgICA6IGFub255bW91c0Ryb3Bkb3duTGlua3M7XG5cbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwXCIgc3R5bGU9e3ttaW5IZWlnaHQ6ICcxNzJweCd9fT5cbiAgICAgICAgPG5hdiByZWY9e25hdmJhclJlZn0gY2xhc3NOYW1lPVwiYmctcHVycGxlXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC0yIG14LWF1dG8gbWF4LXctN3hsIHNtOnB4LTYgbGc6cHgtOFwiPlxuICAgICAgICAgICAgPEZsZXggY2xhc3NOYW1lPVwicmVsYXRpdmUganVzdGlmeS1iZXR3ZWVuIGgtMTZcIj5cbiAgICAgICAgICAgICAgPEZsZXggY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQteS0wIGxlZnQtMCBpdGVtcy1jZW50ZXIgc206aGlkZGVuXCI+XG4gICAgICAgICAgICAgICAgPE1vYmlsZU1lbnVCdXR0b24gb25DbGljaz17dG9nZ2xlTW9iaWxlTWVudX0+XG4gICAgICAgICAgICAgICAgICB7c2hvd3NNb2JpbGVNZW51ID8gPENsb3NlSWNvbiAvPiA6IDxCdXJnZXJJY29uIC8+fVxuICAgICAgICAgICAgICAgIDwvTW9iaWxlTWVudUJ1dHRvbj5cbiAgICAgICAgICAgICAgPC9GbGV4PlxuICAgICAgICAgICAgICA8RmxleCBjbGFzc05hbWU9XCJpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZmxleC0xIHNtOml0ZW1zLXN0cmV0Y2ggc206anVzdGlmeS1zdGFydFwiPlxuICAgICAgICAgICAgICAgIDxGbGV4IGNsYXNzTmFtZT1cIml0ZW1zLWNlbnRlciBmbGV4LXNocmluay0wXCI+XG4gICAgICAgICAgICAgICAgICA8TmV4dExpbmtcbiAgICAgICAgICAgICAgICAgICAgaHJlZj1cIi9cIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktOTAwIHRpdGxlLWZvbnQgbWQ6bWItMFwiXG4gICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJob21lXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPEJyYW5kSWNvbiAvPlxuICAgICAgICAgICAgICAgICAgPC9OZXh0TGluaz5cbiAgICAgICAgICAgICAgICA8L0ZsZXg+XG4gICAgICAgICAgICAgICAgey8qIHJlZ3VsYXIgbmF2bGlua3MgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoaWRkZW4gc206bWwtNiBzbTpmbGV4IHNtOnNwYWNlLXgtOFwiPlxuICAgICAgICAgICAgICAgICAge2xpbmtzLm1hcChsaW5rID0+IChcbiAgICAgICAgICAgICAgICAgICAgPEFjdGl2ZUxpbmtcbiAgICAgICAgICAgICAgICAgICAgICBrZXk9e2xpbmsuaHJlZn1cbiAgICAgICAgICAgICAgICAgICAgICBocmVmPXtsaW5rLmhyZWZ9XG4gICAgICAgICAgICAgICAgICAgICAgYWN0aXZlQ2xhc3NOYW1lPVwiYm9yZGVyLWluZGlnby01MDAgdGV4dC1ncmF5LTkwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgaW5hY3RpdmVDbGFzc05hbWU9XCJib3JkZXItdHJhbnNwYXJlbnQgdGV4dC1ncmF5LTUwMCBob3Zlcjpib3JkZXItZ3JheS0zMDAgaG92ZXI6dGV4dC1ncmF5LTcwMFwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8YSBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtMSBwdC0xIHRleHQtYmFzZSBmb250LW1lZGl1bSBib3JkZXItYi0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7bGluay50ZXh0fVxuICAgICAgICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgICAgICAgPC9BY3RpdmVMaW5rPlxuICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvRmxleD5cbiAgICAgICAgICAgICAgPEZsZXggY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQteS0wIHJpZ2h0LTAgaXRlbXMtY2VudGVyIHByLTIgc206c3RhdGljIHNtOmluc2V0LWF1dG8gc206bWwtNiBzbTpwci0wXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBtbC0zXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8VXNlckRyb3Bkb3duQnV0dG9uIG9uQ2xpY2s9e3RvZ2dsZVVzZXJEcm9wZG93bn0+XG4gICAgICAgICAgICAgICAgICAgICAgPEF2YXRhciBzcmM9e3VzZXI/LnBpY3R1cmUgfHwgJyd9IC8+XG4gICAgICAgICAgICAgICAgICAgIDwvVXNlckRyb3Bkb3duQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8VXNlckRyb3Bkb3duTGlua3NcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgJHtcbiAgICAgICAgICAgICAgICAgICAgICAhc2hvd3NVc2VyRHJvcGRvd24gPyAnaGlkZGVuJyA6ICcnXG4gICAgICAgICAgICAgICAgICAgIH0gYWJzb2x1dGUgcmlnaHQtMCB3LTQ4IHB5LTEgbXQtMiBvcmlnaW4tdG9wLXJpZ2h0IGJnLXdoaXRlIHJvdW5kZWQtbWQgc2hhZG93LWxnIHJpbmctMSByaW5nLWJsYWNrIHJpbmctb3BhY2l0eS01IHotNTBgfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICB7ZHJvcGRvd25MaW5rcy5tYXAobGluayA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgPExpbmsga2V5PXtsaW5rLmhyZWZ9IGhyZWY9e2xpbmsuaHJlZn0+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YVxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtjbG9zZVVzZXJEcm9wZG93bn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgcm9sZT1cIm1lbnVpdGVtXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgcHgtNCBweS0yIHRleHQtbGcgdGV4dC1ncmF5LTcwMCBob3ZlcjpiZy1ncmF5LTEwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtsaW5rLmljb259XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtsaW5rLnRleHR9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAge2lzQXV0aGVudGljYXRlZCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgPExvZ291dEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVMb2dvdXQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xvc2VVc2VyRHJvcGRvd24oKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPExvZ291dEljb24gY2xhc3NOYW1lPVwiaW5saW5lIHctNSBoLTUgbXItMiBhbGlnbi10ZXh0LWJvdHRvbVwiIC8+eycgJ31cbiAgICAgICAgICAgICAgICAgICAgICAgIExvZyBPdXRcbiAgICAgICAgICAgICAgICAgICAgICA8L0xvZ291dEJ1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIDwvVXNlckRyb3Bkb3duTGlua3M+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvRmxleD5cbiAgICAgICAgICAgIDwvRmxleD5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxNb2JpbGVNZW51TGlua3NcbiAgICAgICAgICAgIGNsYXNzTmFtZT17YCR7c2hvd3NNb2JpbGVNZW51ID8gJ2Jsb2NrJyA6ICdoaWRkZW4nfSBzbTpoaWRkZW5gfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtMiBwYi00IHNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICB7bGlua3MubWFwKGxpbmsgPT4gKFxuICAgICAgICAgICAgICAgIDxBY3RpdmVMaW5rXG4gICAgICAgICAgICAgICAgICBrZXk9e2xpbmsuaHJlZn1cbiAgICAgICAgICAgICAgICAgIGhyZWY9e2xpbmsuaHJlZn1cbiAgICAgICAgICAgICAgICAgIGFjdGl2ZUNsYXNzTmFtZT1cImJnLWluZGlnby01MCBib3JkZXItaW5kaWdvLTUwMCB0ZXh0LWluZGlnby03MDBcIlxuICAgICAgICAgICAgICAgICAgaW5hY3RpdmVDbGFzc05hbWU9XCJib3JkZXItdHJhbnNwYXJlbnQgdGV4dC1ncmF5LTUwMCBob3ZlcjpiZy1ncmF5LTUwIGhvdmVyOmJvcmRlci1ncmF5LTMwMCBob3Zlcjp0ZXh0LWdyYXktNzAwXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8YVxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtjbG9zZU1vYmlsZU1lbnV9XG4gICAgICAgICAgICAgICAgICAgIHJvbGU9XCJsaW5rXCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgcHktMiBwbC0zIHByLTQgdGV4dC1iYXNlIGZvbnQtbWVkaXVtIGJvcmRlci1sLTRcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICB7bGluay50ZXh0fVxuICAgICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICAgIDwvQWN0aXZlTGluaz5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L01vYmlsZU1lbnVMaW5rcz5cbiAgICAgICAgPC9uYXY+XG4gICAgICA8L2Rpdj5cbiAgICA8Lz5cbiAgKTtcbn1cblxuZnVuY3Rpb24gTG9nb3V0QnV0dG9uKHtcbiAgb25DbGljayxcbiAgY2hpbGRyZW4sXG59OiB7XG4gIG9uQ2xpY2s6ICgpID0+IHZvaWQ7XG4gIGNoaWxkcmVuOiBSZWFjdE5vZGU7XG59KSB7XG4gIHJldHVybiAoXG4gICAgPExpbmsgaHJlZj1cIiNcIj5cbiAgICAgIDxhXG4gICAgICAgIG9uQ2xpY2s9e29uQ2xpY2t9XG4gICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIHB4LTQgcHktMiB0ZXh0LWxnIHRleHQtZ3JheS03MDAgaG92ZXI6YmctZ3JheS0xMDBcIlxuICAgICAgICByb2xlPVwibWVudWl0ZW1cIlxuICAgICAgPlxuICAgICAgICB7Y2hpbGRyZW59XG4gICAgICA8L2E+XG4gICAgPC9MaW5rPlxuICApO1xufVxuXG5mdW5jdGlvbiBCdXJnZXJJY29uKHtjbGFzc05hbWUgPSAndy02IGgtNid9KSB7XG4gIHJldHVybiA8SGlNZW51IGNsYXNzTmFtZT17Y2xhc3NOYW1lfSAvPjtcbn1cblxuZnVuY3Rpb24gQnJhbmRJY29uKCkge1xuICByZXR1cm4gKFxuICAgIDxJb0N1YmVTaGFycFxuICAgICAgY2xhc3NOYW1lPVwicC0yIHRleHQtZ3JheS03MDAgcm91bmRlZC1mdWxsIHctOSBoLTkgYmctZ3JheS01MCBob3ZlcjpiZy1ncmF5LTIwMFwiXG4gICAgICBmaWxsPVwiY3VycmVudENvbG9yXCJcbiAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXG4gICAgLz5cbiAgKTtcbn1cblxuZnVuY3Rpb24gQ29nSWNvbih7Y2xhc3NOYW1lfToge2NsYXNzTmFtZTogc3RyaW5nfSkge1xuICByZXR1cm4gPEhpQ29nIGNsYXNzTmFtZT17Y2xhc3NOYW1lfSAvPjtcbn1cblxuZnVuY3Rpb24gTG9nb3V0SWNvbih7Y2xhc3NOYW1lfToge2NsYXNzTmFtZTogc3RyaW5nfSkge1xuICByZXR1cm4gPEdvU2lnbk91dCBjbGFzc05hbWU9e2NsYXNzTmFtZX0gLz47XG59XG5cbmZ1bmN0aW9uIExvZ2luSWNvbih7Y2xhc3NOYW1lfToge2NsYXNzTmFtZTogc3RyaW5nfSkge1xuICByZXR1cm4gPEdvU2lnbkluIGNsYXNzTmFtZT17Y2xhc3NOYW1lfSAvPjtcbn1cblxuZnVuY3Rpb24gSGFzaFRhZ0ljb24oe2NsYXNzTmFtZX06IHtjbGFzc05hbWU6IHN0cmluZ30pIHtcbiAgcmV0dXJuIDxIaUhhc2h0YWcgY2xhc3NOYW1lPXtjbGFzc05hbWV9IC8+O1xufVxuIl0sInNvdXJjZVJvb3QiOiIifQ==