webpackHotUpdate_N_E("pages/auth/register",{

/***/ "./src/pages/auth/register/register.tsx":
/*!**********************************************!*\
  !*** ./src/pages/auth/register/register.tsx ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @components/forms */ "./src/components/forms/index.ts");
/* harmony import */ var _components_icons_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @components/icons/icons */ "./src/components/icons/icons.tsx");
/* harmony import */ var _components_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @components/layout */ "./src/components/layout/index.ts");
/* harmony import */ var _components_loading_spinner__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @components/loading-spinner */ "./src/components/loading-spinner/index.ts");
/* harmony import */ var _components_next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @components/next-link */ "./src/components/next-link/index.ts");
/* harmony import */ var _context_notification__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @context/notification */ "./src/context/notification/index.ts");
/* harmony import */ var _shared_index__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @shared/index */ "./shared/index.ts");
/* harmony import */ var _utils_route_hocs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @utils/route-hocs */ "./src/utils/route-hocs.tsx");
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! next-seo */ "./node_modules/next-seo/lib/next-seo.module.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var src_constants__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/constants */ "./src/constants.ts");
/* harmony import */ var _use_register__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./use-register */ "./src/pages/auth/register/use-register.js");



var _jsxFileName = "J:\\Project\\reference\\aws-amplify-react-auth-master-toshare\\aws-amplify-react-auth-master-toshare\\src\\pages\\auth\\register\\register.tsx",
    _s = $RefreshSig$();













const url = `${src_constants__WEBPACK_IMPORTED_MODULE_11__["FRONTEND_BASE_URL"]}${src_constants__WEBPACK_IMPORTED_MODULE_11__["ROUTE_PATHS"].REGISTER}`;
const title = 'Register';
const description = 'Register for an account';
/* harmony default export */ __webpack_exports__["default"] = (_c = Object(_utils_route_hocs__WEBPACK_IMPORTED_MODULE_8__["withAnonymous"])(Register));

function Register() {
  _s();

  var _formErrors$email, _formErrors$password, _formErrors$confirmPa, _formErrors$givenName, _formErrors$familyNam;

  const {
    handleSubmit,
    register,
    formErrors,
    passwordRef,
    isError,
    error,
    isSuccess,
    isLoading
  } = Object(_use_register__WEBPACK_IMPORTED_MODULE_12__["useRegister"])();
  const {
    addNotification
  } = Object(_context_notification__WEBPACK_IMPORTED_MODULE_6__["useNotification"])();
  Object(react__WEBPACK_IMPORTED_MODULE_10__["useEffect"])(() => {
    if (isSuccess) {
      addNotification({
        type: _context_notification__WEBPACK_IMPORTED_MODULE_6__["NotificationType"].SUCCESS,
        title: 'Please click on the activation link, sent to your email address to complete the registration.',
        message: 'Form submitted successfully.'
      });
    }

    if (isError && error) {
      addNotification({
        type: _context_notification__WEBPACK_IMPORTED_MODULE_6__["NotificationType"].ERROR,
        title: error.message
      });
    }
  }, [addNotification, error, isError, isSuccess]);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_seo__WEBPACK_IMPORTED_MODULE_9__["NextSeo"], {
      title: title,
      description: description,
      canonical: url,
      openGraph: {
        url,
        title,
        description
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 52,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_layout__WEBPACK_IMPORTED_MODULE_3__["Flex"], {
      className: "flex-col py-12 mt-4 sm:px-6 lg:px-8",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "lg:flex",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "lg:flex-1",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "mt-8 sm:mx-auto sm:w-full sm:max-w-md test",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "px-4 py-8 bg-white shadow sm:rounded-lg sm:px-10",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "text-center mb-5 customheader",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "text-900 text-3xl font-medium mb-3",
                  children: "Welcome"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 81,
                  columnNumber: 13
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  className: "text-600 font-medium line-height-3",
                  children: "Create an account"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 82,
                  columnNumber: 13
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 80,
                columnNumber: 15
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("form", {
                className: "space-y-2",
                onSubmit: handleSubmit,
                noValidate: true,
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_forms__WEBPACK_IMPORTED_MODULE_1__["Label"], {
                    htmlFor: "email",
                    children: "Email"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 87,
                    columnNumber: 21
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_forms__WEBPACK_IMPORTED_MODULE_1__["Input"], {
                    type: "email",
                    id: "email",
                    name: "email",
                    placeholder: "email@address.com",
                    ref: register({
                      required: 'Email is required.',
                      validate: email => Object(_shared_index__WEBPACK_IMPORTED_MODULE_7__["isValidEmail"])(email) || 'Email address is invalid.'
                    }),
                    error: (_formErrors$email = formErrors.email) === null || _formErrors$email === void 0 ? void 0 : _formErrors$email.message,
                    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_icons_icons__WEBPACK_IMPORTED_MODULE_2__["EmailIcon"], {}, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 99,
                      columnNumber: 29
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 88,
                    columnNumber: 21
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 86,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_forms__WEBPACK_IMPORTED_MODULE_1__["Label"], {
                    htmlFor: "password",
                    children: "Password"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 104,
                    columnNumber: 21
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_forms__WEBPACK_IMPORTED_MODULE_1__["Input"], {
                    type: "password",
                    id: "password",
                    name: "password",
                    placeholder: "Password",
                    ref: register({
                      required: 'Password is required.',
                      minLength: {
                        value: 6,
                        message: 'Password must be at least 6 characters.'
                      }
                    }),
                    error: (_formErrors$password = formErrors.password) === null || _formErrors$password === void 0 ? void 0 : _formErrors$password.message,
                    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_icons_icons__WEBPACK_IMPORTED_MODULE_2__["LockIcon"], {}, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 118,
                      columnNumber: 29
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 105,
                    columnNumber: 21
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 103,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_forms__WEBPACK_IMPORTED_MODULE_1__["Label"], {
                    htmlFor: "confirmPassword",
                    children: "Confirm Password"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 123,
                    columnNumber: 21
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_forms__WEBPACK_IMPORTED_MODULE_1__["Input"], {
                    type: "password",
                    id: "confirmPassword",
                    name: "confirmPassword",
                    placeholder: "Confirm Password",
                    ref: register({
                      required: 'Password confirmation is required.',
                      minLength: {
                        value: 6,
                        message: 'Password must be at least 6 characters.'
                      },
                      validate: confirmPassword => confirmPassword === passwordRef.current || 'The passwords do not match.'
                    }),
                    error: (_formErrors$confirmPa = formErrors.confirmPassword) === null || _formErrors$confirmPa === void 0 ? void 0 : _formErrors$confirmPa.message,
                    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_icons_icons__WEBPACK_IMPORTED_MODULE_2__["LockIcon"], {}, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 143,
                      columnNumber: 29
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 127,
                    columnNumber: 21
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 122,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_forms__WEBPACK_IMPORTED_MODULE_1__["Label"], {
                    htmlFor: "givenName",
                    children: "Referral Code"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 148,
                    columnNumber: 21
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_forms__WEBPACK_IMPORTED_MODULE_1__["Input"], {
                    type: "text",
                    id: "givenName",
                    name: "givenName",
                    placeholder: "Referral Code",
                    ref: register({
                      required: 'First Name is required.'
                    }),
                    error: (_formErrors$givenName = formErrors.givenName) === null || _formErrors$givenName === void 0 ? void 0 : _formErrors$givenName.message,
                    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_icons_icons__WEBPACK_IMPORTED_MODULE_2__["UserIcon"], {}, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 156,
                      columnNumber: 29
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 149,
                    columnNumber: 21
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 147,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_forms__WEBPACK_IMPORTED_MODULE_1__["Label"], {
                    htmlFor: "familyName",
                    children: "Last Name"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 161,
                    columnNumber: 21
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_forms__WEBPACK_IMPORTED_MODULE_1__["Input"], {
                    type: "text",
                    id: "familyName",
                    name: "familyName",
                    placeholder: "e.g. Smith",
                    ref: register({
                      required: 'Last Name is required.'
                    }),
                    error: (_formErrors$familyNam = formErrors.familyName) === null || _formErrors$familyNam === void 0 ? void 0 : _formErrors$familyNam.message,
                    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_icons_icons__WEBPACK_IMPORTED_MODULE_2__["UserIcon"], {}, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 169,
                      columnNumber: 29
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 162,
                    columnNumber: 21
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 160,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_layout__WEBPACK_IMPORTED_MODULE_3__["Flex"], {
                  className: "items-center justify-between",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_next_link__WEBPACK_IMPORTED_MODULE_5__["NextLink"], {
                    href: src_constants__WEBPACK_IMPORTED_MODULE_11__["ROUTE_PATHS"].RESEND_REGISTRATION_LINK,
                    className: "text-sm font-medium text-indigo-600 hover:text-indigo-500",
                    children: "Resend activation link"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 174,
                    columnNumber: 21
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_next_link__WEBPACK_IMPORTED_MODULE_5__["NextLink"], {
                    href: src_constants__WEBPACK_IMPORTED_MODULE_11__["ROUTE_PATHS"].LOGIN,
                    className: "text-sm font-medium text-indigo-600 hover:text-indigo-500",
                    children: "Already have an account?"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 180,
                    columnNumber: 21
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 173,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_forms__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                    type: "submit",
                    isFullWidth: true,
                    disabled: !!isLoading,
                    children: ["Register ", isLoading && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_loading_spinner__WEBPACK_IMPORTED_MODULE_4__["LoadingInline"], {}, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 190,
                      columnNumber: 46
                    }, this)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 189,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 188,
                  columnNumber: 19
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 85,
                columnNumber: 17
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 79,
              columnNumber: 15
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 78,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 64,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 63,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 62,
      columnNumber: 7
    }, this)]
  }, void 0, true);
}

_s(Register, "oKaOfQdA030LeSKwOOKs+mxjRtU=", false, function () {
  return [_use_register__WEBPACK_IMPORTED_MODULE_12__["useRegister"], _context_notification__WEBPACK_IMPORTED_MODULE_6__["useNotification"]];
});

_c2 = Register;

var _c, _c2;

$RefreshReg$(_c, "%default%");
$RefreshReg$(_c2, "Register");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL3BhZ2VzL2F1dGgvcmVnaXN0ZXIvcmVnaXN0ZXIudHN4Il0sIm5hbWVzIjpbInVybCIsIkZST05URU5EX0JBU0VfVVJMIiwiUk9VVEVfUEFUSFMiLCJSRUdJU1RFUiIsInRpdGxlIiwiZGVzY3JpcHRpb24iLCJ3aXRoQW5vbnltb3VzIiwiUmVnaXN0ZXIiLCJoYW5kbGVTdWJtaXQiLCJyZWdpc3RlciIsImZvcm1FcnJvcnMiLCJwYXNzd29yZFJlZiIsImlzRXJyb3IiLCJlcnJvciIsImlzU3VjY2VzcyIsImlzTG9hZGluZyIsInVzZVJlZ2lzdGVyIiwiYWRkTm90aWZpY2F0aW9uIiwidXNlTm90aWZpY2F0aW9uIiwidXNlRWZmZWN0IiwidHlwZSIsIk5vdGlmaWNhdGlvblR5cGUiLCJTVUNDRVNTIiwibWVzc2FnZSIsIkVSUk9SIiwicmVxdWlyZWQiLCJ2YWxpZGF0ZSIsImVtYWlsIiwiaXNWYWxpZEVtYWlsIiwibWluTGVuZ3RoIiwidmFsdWUiLCJwYXNzd29yZCIsImNvbmZpcm1QYXNzd29yZCIsImN1cnJlbnQiLCJnaXZlbk5hbWUiLCJmYW1pbHlOYW1lIiwiUkVTRU5EX1JFR0lTVFJBVElPTl9MSU5LIiwiTE9HSU4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUEsTUFBTUEsR0FBRyxHQUFJLEdBQUVDLGdFQUFrQixHQUFFQywwREFBVyxDQUFDQyxRQUFTLEVBQXhEO0FBQ0EsTUFBTUMsS0FBSyxHQUFHLFVBQWQ7QUFDQSxNQUFNQyxXQUFXLEdBQUcseUJBQXBCO0FBRWUsb0VBQUFDLHVFQUFhLENBQUNDLFFBQUQsQ0FBNUI7O0FBRUEsU0FBU0EsUUFBVCxHQUFvQjtBQUFBOztBQUFBOztBQUNsQixRQUFNO0FBQ0pDLGdCQURJO0FBRUpDLFlBRkk7QUFHSkMsY0FISTtBQUlKQyxlQUpJO0FBS0pDLFdBTEk7QUFNSkMsU0FOSTtBQU9KQyxhQVBJO0FBUUpDO0FBUkksTUFTRkMsa0VBQVcsRUFUZjtBQVdBLFFBQU07QUFBQ0M7QUFBRCxNQUFvQkMsNkVBQWUsRUFBekM7QUFFQUMsMERBQVMsQ0FBQyxNQUFNO0FBQ2QsUUFBSUwsU0FBSixFQUFlO0FBQ2JHLHFCQUFlLENBQUM7QUFDZEcsWUFBSSxFQUFFQyxzRUFBZ0IsQ0FBQ0MsT0FEVDtBQUVkbEIsYUFBSyxFQUNILCtGQUhZO0FBSWRtQixlQUFPLEVBQUU7QUFKSyxPQUFELENBQWY7QUFNRDs7QUFFRCxRQUFJWCxPQUFPLElBQUlDLEtBQWYsRUFBc0I7QUFDcEJJLHFCQUFlLENBQUM7QUFBQ0csWUFBSSxFQUFFQyxzRUFBZ0IsQ0FBQ0csS0FBeEI7QUFBK0JwQixhQUFLLEVBQUVTLEtBQUssQ0FBQ1U7QUFBNUMsT0FBRCxDQUFmO0FBQ0Q7QUFDRixHQWJRLEVBYU4sQ0FBQ04sZUFBRCxFQUFrQkosS0FBbEIsRUFBeUJELE9BQXpCLEVBQWtDRSxTQUFsQyxDQWJNLENBQVQ7QUFlQSxzQkFDRTtBQUFBLDRCQUNFLHFFQUFDLGdEQUFEO0FBQ0UsV0FBSyxFQUFFVixLQURUO0FBRUUsaUJBQVcsRUFBRUMsV0FGZjtBQUdFLGVBQVMsRUFBRUwsR0FIYjtBQUlFLGVBQVMsRUFBRTtBQUNUQSxXQURTO0FBRVRJLGFBRlM7QUFHVEM7QUFIUztBQUpiO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERixlQVdFLHFFQUFDLHVEQUFEO0FBQU0sZUFBUyxFQUFDLHFDQUFoQjtBQUFBLDZCQUNFO0FBQUssaUJBQVMsRUFBQyxTQUFmO0FBQUEsK0JBQ0U7QUFBSyxtQkFBUyxFQUFDLFdBQWY7QUFBQSxpQ0FjRTtBQUFLLHFCQUFTLEVBQUMsNENBQWY7QUFBQSxtQ0FDRTtBQUFLLHVCQUFTLEVBQUMsa0RBQWY7QUFBQSxzQ0FDQTtBQUFLLHlCQUFTLEVBQUMsK0JBQWY7QUFBQSx3Q0FDRjtBQUFLLDJCQUFTLEVBQUMsb0NBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBREUsZUFFRjtBQUFNLDJCQUFTLEVBQUMsb0NBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUZFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFEQSxlQU1FO0FBQU0seUJBQVMsRUFBQyxXQUFoQjtBQUE0Qix3QkFBUSxFQUFFRyxZQUF0QztBQUFvRCwwQkFBVSxNQUE5RDtBQUFBLHdDQUNFO0FBQUEsMENBQ0UscUVBQUMsdURBQUQ7QUFBTywyQkFBTyxFQUFDLE9BQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBREYsZUFFRSxxRUFBQyx1REFBRDtBQUNFLHdCQUFJLEVBQUMsT0FEUDtBQUVFLHNCQUFFLEVBQUMsT0FGTDtBQUdFLHdCQUFJLEVBQUMsT0FIUDtBQUlFLCtCQUFXLEVBQUMsbUJBSmQ7QUFLRSx1QkFBRyxFQUFFQyxRQUFRLENBQUM7QUFDWmdCLDhCQUFRLEVBQUUsb0JBREU7QUFFWkMsOEJBQVEsRUFBRUMsS0FBSyxJQUNiQyxrRUFBWSxDQUFDRCxLQUFELENBQVosSUFBdUI7QUFIYixxQkFBRCxDQUxmO0FBVUUseUJBQUssdUJBQUVqQixVQUFVLENBQUNpQixLQUFiLHNEQUFFLGtCQUFrQkosT0FWM0I7QUFXRSx3QkFBSSxlQUFFLHFFQUFDLGlFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFYUjtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFERixlQWtCRTtBQUFBLDBDQUNFLHFFQUFDLHVEQUFEO0FBQU8sMkJBQU8sRUFBQyxVQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQURGLGVBRUUscUVBQUMsdURBQUQ7QUFDRSx3QkFBSSxFQUFDLFVBRFA7QUFFRSxzQkFBRSxFQUFDLFVBRkw7QUFHRSx3QkFBSSxFQUFDLFVBSFA7QUFJRSwrQkFBVyxFQUFDLFVBSmQ7QUFLRSx1QkFBRyxFQUFFZCxRQUFRLENBQUM7QUFDWmdCLDhCQUFRLEVBQUUsdUJBREU7QUFFWkksK0JBQVMsRUFBRTtBQUNUQyw2QkFBSyxFQUFFLENBREU7QUFFVFAsK0JBQU8sRUFBRTtBQUZBO0FBRkMscUJBQUQsQ0FMZjtBQVlFLHlCQUFLLDBCQUFFYixVQUFVLENBQUNxQixRQUFiLHlEQUFFLHFCQUFxQlIsT0FaOUI7QUFhRSx3QkFBSSxlQUFFLHFFQUFDLGdFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFiUjtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFsQkYsZUFxQ0U7QUFBQSwwQ0FDRSxxRUFBQyx1REFBRDtBQUFPLDJCQUFPLEVBQUMsaUJBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBREYsZUFLRSxxRUFBQyx1REFBRDtBQUNFLHdCQUFJLEVBQUMsVUFEUDtBQUVFLHNCQUFFLEVBQUMsaUJBRkw7QUFHRSx3QkFBSSxFQUFDLGlCQUhQO0FBSUUsK0JBQVcsRUFBQyxrQkFKZDtBQUtFLHVCQUFHLEVBQUVkLFFBQVEsQ0FBQztBQUNaZ0IsOEJBQVEsRUFBRSxvQ0FERTtBQUVaSSwrQkFBUyxFQUFFO0FBQ1RDLDZCQUFLLEVBQUUsQ0FERTtBQUVUUCwrQkFBTyxFQUFFO0FBRkEsdUJBRkM7QUFNWkcsOEJBQVEsRUFBRU0sZUFBZSxJQUN2QkEsZUFBZSxLQUFLckIsV0FBVyxDQUFDc0IsT0FBaEMsSUFDQTtBQVJVLHFCQUFELENBTGY7QUFlRSx5QkFBSywyQkFBRXZCLFVBQVUsQ0FBQ3NCLGVBQWIsMERBQUUsc0JBQTRCVCxPQWZyQztBQWdCRSx3QkFBSSxlQUFFLHFFQUFDLGdFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFoQlI7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBckNGLGVBOERFO0FBQUEsMENBQ0UscUVBQUMsdURBQUQ7QUFBTywyQkFBTyxFQUFDLFdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBREYsZUFFRSxxRUFBQyx1REFBRDtBQUNFLHdCQUFJLEVBQUMsTUFEUDtBQUVFLHNCQUFFLEVBQUMsV0FGTDtBQUdFLHdCQUFJLEVBQUMsV0FIUDtBQUlFLCtCQUFXLEVBQUMsZUFKZDtBQUtFLHVCQUFHLEVBQUVkLFFBQVEsQ0FBQztBQUFDZ0IsOEJBQVEsRUFBRTtBQUFYLHFCQUFELENBTGY7QUFNRSx5QkFBSywyQkFBRWYsVUFBVSxDQUFDd0IsU0FBYiwwREFBRSxzQkFBc0JYLE9BTi9CO0FBT0Usd0JBQUksZUFBRSxxRUFBQyxnRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBUFI7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBOURGLGVBMkVFO0FBQUEsMENBQ0UscUVBQUMsdURBQUQ7QUFBTywyQkFBTyxFQUFDLFlBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBREYsZUFFRSxxRUFBQyx1REFBRDtBQUNFLHdCQUFJLEVBQUMsTUFEUDtBQUVFLHNCQUFFLEVBQUMsWUFGTDtBQUdFLHdCQUFJLEVBQUMsWUFIUDtBQUlFLCtCQUFXLEVBQUMsWUFKZDtBQUtFLHVCQUFHLEVBQUVkLFFBQVEsQ0FBQztBQUFDZ0IsOEJBQVEsRUFBRTtBQUFYLHFCQUFELENBTGY7QUFNRSx5QkFBSywyQkFBRWYsVUFBVSxDQUFDeUIsVUFBYiwwREFBRSxzQkFBdUJaLE9BTmhDO0FBT0Usd0JBQUksZUFBRSxxRUFBQyxnRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBUFI7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBM0VGLGVBd0ZFLHFFQUFDLHVEQUFEO0FBQU0sMkJBQVMsRUFBQyw4QkFBaEI7QUFBQSwwQ0FDRSxxRUFBQyw4REFBRDtBQUNFLHdCQUFJLEVBQUVyQiwwREFBVyxDQUFDa0Msd0JBRHBCO0FBRUUsNkJBQVMsRUFBQywyREFGWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFERixlQU9FLHFFQUFDLDhEQUFEO0FBQ0Usd0JBQUksRUFBRWxDLDBEQUFXLENBQUNtQyxLQURwQjtBQUVFLDZCQUFTLEVBQUMsMkRBRlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQXhGRixlQXVHRTtBQUFBLHlDQUNFLHFFQUFDLHdEQUFEO0FBQVEsd0JBQUksRUFBQyxRQUFiO0FBQXNCLCtCQUFXLE1BQWpDO0FBQWtDLDRCQUFRLEVBQUUsQ0FBQyxDQUFDdEIsU0FBOUM7QUFBQSw0Q0FDWUEsU0FBUyxpQkFBSSxxRUFBQyx5RUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQUR6QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQXZHRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVhGO0FBQUEsa0JBREY7QUE4SkQ7O0dBM0xRUixRO1VBVUhTLDBELEVBRXNCRSxxRTs7O01BWm5CWCxRIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL2F1dGgvcmVnaXN0ZXIuODBkZWRkNzU5MDQyNWNmODI0YjkuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7QnV0dG9uLCBJbnB1dCwgTGFiZWx9IGZyb20gJ0Bjb21wb25lbnRzL2Zvcm1zJztcbmltcG9ydCB7SGVhZGluZywgU3ViSGVhZGluZ30gZnJvbSAnQGNvbXBvbmVudHMvaGVhZGluZy9oZWFkaW5nJztcbmltcG9ydCB7RW1haWxJY29uLCBMb2NrSWNvbiwgVXNlckljb259IGZyb20gJ0Bjb21wb25lbnRzL2ljb25zL2ljb25zJztcbmltcG9ydCB7RmxleH0gZnJvbSAnQGNvbXBvbmVudHMvbGF5b3V0JztcbmltcG9ydCB7TG9hZGluZ0lubGluZX0gZnJvbSAnQGNvbXBvbmVudHMvbG9hZGluZy1zcGlubmVyJztcbmltcG9ydCB7TmV4dExpbmt9IGZyb20gJ0Bjb21wb25lbnRzL25leHQtbGluayc7XG5pbXBvcnQge05vdGlmaWNhdGlvblR5cGUsIHVzZU5vdGlmaWNhdGlvbn0gZnJvbSAnQGNvbnRleHQvbm90aWZpY2F0aW9uJztcbmltcG9ydCB7aXNWYWxpZEVtYWlsfSBmcm9tICdAc2hhcmVkL2luZGV4JztcbmltcG9ydCB7d2l0aEFub255bW91c30gZnJvbSAnQHV0aWxzL3JvdXRlLWhvY3MnO1xuaW1wb3J0IHtOZXh0U2VvfSBmcm9tICduZXh0LXNlbyc7XG5pbXBvcnQge3VzZUVmZmVjdH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHtGUk9OVEVORF9CQVNFX1VSTCwgSU1BR0VfUEFUSFMsIFJPVVRFX1BBVEhTfSBmcm9tICdzcmMvY29uc3RhbnRzJztcbmltcG9ydCB7dXNlUmVnaXN0ZXJ9IGZyb20gJy4vdXNlLXJlZ2lzdGVyJztcblxuY29uc3QgdXJsID0gYCR7RlJPTlRFTkRfQkFTRV9VUkx9JHtST1VURV9QQVRIUy5SRUdJU1RFUn1gO1xuY29uc3QgdGl0bGUgPSAnUmVnaXN0ZXInO1xuY29uc3QgZGVzY3JpcHRpb24gPSAnUmVnaXN0ZXIgZm9yIGFuIGFjY291bnQnO1xuXG5leHBvcnQgZGVmYXVsdCB3aXRoQW5vbnltb3VzKFJlZ2lzdGVyKTtcblxuZnVuY3Rpb24gUmVnaXN0ZXIoKSB7XG4gIGNvbnN0IHtcbiAgICBoYW5kbGVTdWJtaXQsXG4gICAgcmVnaXN0ZXIsXG4gICAgZm9ybUVycm9ycyxcbiAgICBwYXNzd29yZFJlZixcbiAgICBpc0Vycm9yLFxuICAgIGVycm9yLFxuICAgIGlzU3VjY2VzcyxcbiAgICBpc0xvYWRpbmcsXG4gIH0gPSB1c2VSZWdpc3RlcigpO1xuXG4gIGNvbnN0IHthZGROb3RpZmljYXRpb259ID0gdXNlTm90aWZpY2F0aW9uKCk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoaXNTdWNjZXNzKSB7XG4gICAgICBhZGROb3RpZmljYXRpb24oe1xuICAgICAgICB0eXBlOiBOb3RpZmljYXRpb25UeXBlLlNVQ0NFU1MsXG4gICAgICAgIHRpdGxlOlxuICAgICAgICAgICdQbGVhc2UgY2xpY2sgb24gdGhlIGFjdGl2YXRpb24gbGluaywgc2VudCB0byB5b3VyIGVtYWlsIGFkZHJlc3MgdG8gY29tcGxldGUgdGhlIHJlZ2lzdHJhdGlvbi4nLFxuICAgICAgICBtZXNzYWdlOiAnRm9ybSBzdWJtaXR0ZWQgc3VjY2Vzc2Z1bGx5LicsXG4gICAgICB9KTtcbiAgICB9XG5cbiAgICBpZiAoaXNFcnJvciAmJiBlcnJvcikge1xuICAgICAgYWRkTm90aWZpY2F0aW9uKHt0eXBlOiBOb3RpZmljYXRpb25UeXBlLkVSUk9SLCB0aXRsZTogZXJyb3IubWVzc2FnZX0pO1xuICAgIH1cbiAgfSwgW2FkZE5vdGlmaWNhdGlvbiwgZXJyb3IsIGlzRXJyb3IsIGlzU3VjY2Vzc10pO1xuXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDxOZXh0U2VvXG4gICAgICAgIHRpdGxlPXt0aXRsZX1cbiAgICAgICAgZGVzY3JpcHRpb249e2Rlc2NyaXB0aW9ufVxuICAgICAgICBjYW5vbmljYWw9e3VybH1cbiAgICAgICAgb3BlbkdyYXBoPXt7XG4gICAgICAgICAgdXJsLFxuICAgICAgICAgIHRpdGxlLFxuICAgICAgICAgIGRlc2NyaXB0aW9uLFxuICAgICAgICB9fVxuICAgICAgLz5cbiAgICAgIDxGbGV4IGNsYXNzTmFtZT1cImZsZXgtY29sIHB5LTEyIG10LTQgc206cHgtNiBsZzpweC04XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGc6ZmxleFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGc6ZmxleC0xXCI+XG4gICAgICAgICAgICB7LyogPGRpdiBjbGFzc05hbWU9XCJwLTIgc206bXgtYXV0byBzbTp3LWZ1bGwgc206bWF4LXctbWRcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8SGVhZGluZz5SZWdpc3RlciBmb3IgYW4gYWNjb3VudDwvSGVhZGluZz5cbiAgICAgICAgICAgICAgICAgIDxTdWJIZWFkaW5nPlxuICAgICAgICAgICAgICAgICAgICBBZnRlciB5b3UgZmlsbCBpbiB0aGUgZm9ybSwgeW91IHdpbGwgcmVjZWl2ZSBhbiBlbWFpbCB3aXRoXG4gICAgICAgICAgICAgICAgICAgIGFuIGFjdGl2YXRpb24gbGluayAtIGNsaWNrIG9uIHRoZSBsaW5rIHRvIGNvbXBsZXRlIHRoZVxuICAgICAgICAgICAgICAgICAgICBwcm9jZXNzLlxuICAgICAgICAgICAgICAgICAgPC9TdWJIZWFkaW5nPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PiAqL31cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC04IHNtOm14LWF1dG8gc206dy1mdWxsIHNtOm1heC13LW1kIHRlc3RcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC00IHB5LTggYmctd2hpdGUgc2hhZG93IHNtOnJvdW5kZWQtbGcgc206cHgtMTBcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBtYi01IGN1c3RvbWhlYWRlclwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LTkwMCB0ZXh0LTN4bCBmb250LW1lZGl1bSBtYi0zXCI+V2VsY29tZTwvZGl2PlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC02MDAgZm9udC1tZWRpdW0gbGluZS1oZWlnaHQtM1wiPkNyZWF0ZSBhbiBhY2NvdW50PC9zcGFuPlxuICAgICAgICAgICAgXG4gICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cInNwYWNlLXktMlwiIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IG5vVmFsaWRhdGU+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8TGFiZWwgaHRtbEZvcj1cImVtYWlsXCI+RW1haWw8L0xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIlxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwiZW1haWxcIlxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJlbWFpbFwiXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlbWFpbEBhZGRyZXNzLmNvbVwiXG4gICAgICAgICAgICAgICAgICAgICAgcmVmPXtyZWdpc3Rlcih7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZDogJ0VtYWlsIGlzIHJlcXVpcmVkLicsXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0ZTogZW1haWwgPT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgaXNWYWxpZEVtYWlsKGVtYWlsKSB8fCAnRW1haWwgYWRkcmVzcyBpcyBpbnZhbGlkLicsXG4gICAgICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgZXJyb3I9e2Zvcm1FcnJvcnMuZW1haWw/Lm1lc3NhZ2V9XG4gICAgICAgICAgICAgICAgICAgICAgaWNvbj17PEVtYWlsSWNvbiAvPn1cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8TGFiZWwgaHRtbEZvcj1cInBhc3N3b3JkXCI+UGFzc3dvcmQ8L0xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwYXNzd29yZFwiXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJQYXNzd29yZFwiXG4gICAgICAgICAgICAgICAgICAgICAgcmVmPXtyZWdpc3Rlcih7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZDogJ1Bhc3N3b3JkIGlzIHJlcXVpcmVkLicsXG4gICAgICAgICAgICAgICAgICAgICAgICBtaW5MZW5ndGg6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IDYsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6ICdQYXNzd29yZCBtdXN0IGJlIGF0IGxlYXN0IDYgY2hhcmFjdGVycy4nLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICAgICAgICBlcnJvcj17Zm9ybUVycm9ycy5wYXNzd29yZD8ubWVzc2FnZX1cbiAgICAgICAgICAgICAgICAgICAgICBpY29uPXs8TG9ja0ljb24gLz59XG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPExhYmVsIGh0bWxGb3I9XCJjb25maXJtUGFzc3dvcmRcIj5cbiAgICAgICAgICAgICAgICAgICAgICBDb25maXJtIFBhc3N3b3JkXG4gICAgICAgICAgICAgICAgICAgIDwvTGFiZWw+XG5cbiAgICAgICAgICAgICAgICAgICAgPElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cImNvbmZpcm1QYXNzd29yZFwiXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNvbmZpcm1QYXNzd29yZFwiXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJDb25maXJtIFBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICAgICAgICByZWY9e3JlZ2lzdGVyKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkOiAnUGFzc3dvcmQgY29uZmlybWF0aW9uIGlzIHJlcXVpcmVkLicsXG4gICAgICAgICAgICAgICAgICAgICAgICBtaW5MZW5ndGg6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IDYsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6ICdQYXNzd29yZCBtdXN0IGJlIGF0IGxlYXN0IDYgY2hhcmFjdGVycy4nLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRlOiBjb25maXJtUGFzc3dvcmQgPT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29uZmlybVBhc3N3b3JkID09PSBwYXNzd29yZFJlZi5jdXJyZW50IHx8XG4gICAgICAgICAgICAgICAgICAgICAgICAgICdUaGUgcGFzc3dvcmRzIGRvIG5vdCBtYXRjaC4nLFxuICAgICAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgICAgICAgIGVycm9yPXtmb3JtRXJyb3JzLmNvbmZpcm1QYXNzd29yZD8ubWVzc2FnZX1cbiAgICAgICAgICAgICAgICAgICAgICBpY29uPXs8TG9ja0ljb24gLz59XG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPExhYmVsIGh0bWxGb3I9XCJnaXZlbk5hbWVcIj5SZWZlcnJhbCBDb2RlPC9MYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwiZ2l2ZW5OYW1lXCJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ2l2ZW5OYW1lXCJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlJlZmVycmFsIENvZGVcIlxuICAgICAgICAgICAgICAgICAgICAgIHJlZj17cmVnaXN0ZXIoe3JlcXVpcmVkOiAnRmlyc3QgTmFtZSBpcyByZXF1aXJlZC4nfSl9XG4gICAgICAgICAgICAgICAgICAgICAgZXJyb3I9e2Zvcm1FcnJvcnMuZ2l2ZW5OYW1lPy5tZXNzYWdlfVxuICAgICAgICAgICAgICAgICAgICAgIGljb249ezxVc2VySWNvbiAvPn1cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8TGFiZWwgaHRtbEZvcj1cImZhbWlseU5hbWVcIj5MYXN0IE5hbWU8L0xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJmYW1pbHlOYW1lXCJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZmFtaWx5TmFtZVwiXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIFNtaXRoXCJcbiAgICAgICAgICAgICAgICAgICAgICByZWY9e3JlZ2lzdGVyKHtyZXF1aXJlZDogJ0xhc3QgTmFtZSBpcyByZXF1aXJlZC4nfSl9XG4gICAgICAgICAgICAgICAgICAgICAgZXJyb3I9e2Zvcm1FcnJvcnMuZmFtaWx5TmFtZT8ubWVzc2FnZX1cbiAgICAgICAgICAgICAgICAgICAgICBpY29uPXs8VXNlckljb24gLz59XG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPEZsZXggY2xhc3NOYW1lPVwiaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgICA8TmV4dExpbmtcbiAgICAgICAgICAgICAgICAgICAgICBocmVmPXtST1VURV9QQVRIUy5SRVNFTkRfUkVHSVNUUkFUSU9OX0xJTkt9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWluZGlnby02MDAgaG92ZXI6dGV4dC1pbmRpZ28tNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIFJlc2VuZCBhY3RpdmF0aW9uIGxpbmtcbiAgICAgICAgICAgICAgICAgICAgPC9OZXh0TGluaz5cbiAgICAgICAgICAgICAgICAgICAgPE5leHRMaW5rXG4gICAgICAgICAgICAgICAgICAgICAgaHJlZj17Uk9VVEVfUEFUSFMuTE9HSU59XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWluZGlnby02MDAgaG92ZXI6dGV4dC1pbmRpZ28tNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIEFscmVhZHkgaGF2ZSBhbiBhY2NvdW50P1xuICAgICAgICAgICAgICAgICAgICA8L05leHRMaW5rPlxuICAgICAgICAgICAgICAgICAgPC9GbGV4PlxuXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBpc0Z1bGxXaWR0aCBkaXNhYmxlZD17ISFpc0xvYWRpbmd9PlxuICAgICAgICAgICAgICAgICAgICAgIFJlZ2lzdGVyIHtpc0xvYWRpbmcgJiYgPExvYWRpbmdJbmxpbmUgLz59XG4gICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9mb3JtPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIHsvKiA8ZGl2IGNsYXNzTmFtZT1cImxnOmZsZXgtMVwiPlxuICAgICAgICAgICAgPGltZ1xuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoaWRkZW4gb2JqZWN0LWNvbnRhaW4gdy1mdWxsIGgtNTYgbGc6aC1mdWxsIGxnOmlubGluZVwiXG4gICAgICAgICAgICAgIHNyYz17SU1BR0VfUEFUSFMuV09NQU5fU0lHTklOR19VUH1cbiAgICAgICAgICAgICAgYWx0PVwid29tYW4gc2lnbmluZyB1cFwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PiAqL31cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L0ZsZXg+XG4gICAgPC8+XG4gICk7XG59XG4iXSwic291cmNlUm9vdCI6IiJ9