webpackHotUpdate_N_E("pages/auth/register",{

/***/ "./src/pages/auth/register/register.tsx":
/*!**********************************************!*\
  !*** ./src/pages/auth/register/register.tsx ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @components/forms */ "./src/components/forms/index.ts");
/* harmony import */ var _components_icons_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @components/icons/icons */ "./src/components/icons/icons.tsx");
/* harmony import */ var _components_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @components/layout */ "./src/components/layout/index.ts");
/* harmony import */ var _components_loading_spinner__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @components/loading-spinner */ "./src/components/loading-spinner/index.ts");
/* harmony import */ var _components_next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @components/next-link */ "./src/components/next-link/index.ts");
/* harmony import */ var _context_notification__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @context/notification */ "./src/context/notification/index.ts");
/* harmony import */ var _shared_index__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @shared/index */ "./shared/index.ts");
/* harmony import */ var _utils_route_hocs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @utils/route-hocs */ "./src/utils/route-hocs.tsx");
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! next-seo */ "./node_modules/next-seo/lib/next-seo.module.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var src_constants__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/constants */ "./src/constants.ts");
/* harmony import */ var _use_register__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./use-register */ "./src/pages/auth/register/use-register.js");



var _jsxFileName = "J:\\Project\\reference\\aws-amplify-react-auth-master-toshare\\aws-amplify-react-auth-master-toshare\\src\\pages\\auth\\register\\register.tsx",
    _s = $RefreshSig$();













const url = `${src_constants__WEBPACK_IMPORTED_MODULE_11__["FRONTEND_BASE_URL"]}${src_constants__WEBPACK_IMPORTED_MODULE_11__["ROUTE_PATHS"].REGISTER}`;
const title = 'Register';
const description = 'Register for an account';
/* harmony default export */ __webpack_exports__["default"] = (_c = Object(_utils_route_hocs__WEBPACK_IMPORTED_MODULE_8__["withAnonymous"])(Register));

function Register() {
  _s();

  var _formErrors$email, _formErrors$password, _formErrors$confirmPa, _formErrors$givenName, _formErrors$familyNam;

  const {
    handleSubmit,
    register,
    formErrors,
    passwordRef,
    isError,
    error,
    isSuccess,
    isLoading
  } = Object(_use_register__WEBPACK_IMPORTED_MODULE_12__["useRegister"])();
  const {
    addNotification
  } = Object(_context_notification__WEBPACK_IMPORTED_MODULE_6__["useNotification"])();
  Object(react__WEBPACK_IMPORTED_MODULE_10__["useEffect"])(() => {
    if (isSuccess) {
      addNotification({
        type: _context_notification__WEBPACK_IMPORTED_MODULE_6__["NotificationType"].SUCCESS,
        title: 'Please click on the activation link, sent to your email address to complete the registration.',
        message: 'Form submitted successfully.'
      });
    }

    if (isError && error) {
      addNotification({
        type: _context_notification__WEBPACK_IMPORTED_MODULE_6__["NotificationType"].ERROR,
        title: error.message
      });
    }
  }, [addNotification, error, isError, isSuccess]);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_seo__WEBPACK_IMPORTED_MODULE_9__["NextSeo"], {
      title: title,
      description: description,
      canonical: url,
      openGraph: {
        url,
        title,
        description
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 52,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_layout__WEBPACK_IMPORTED_MODULE_3__["Flex"], {
      className: "flex-col py-12 mt-4 sm:px-6 lg:px-8",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "lg:flex",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "lg:flex-1",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "mt-8 sm:mx-auto sm:w-full sm:max-w-md test",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "px-4 py-8 bg-white shadow sm:rounded-lg sm:px-10",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "text-center mb-5 customheader",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "text-900 text-3xl font-medium mb-3",
                  children: "Welcome"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 81,
                  columnNumber: 13
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  className: "text-600 font-medium line-height-3",
                  children: "Create an account"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 82,
                  columnNumber: 13
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 80,
                columnNumber: 15
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("form", {
                className: "space-y-2",
                onSubmit: handleSubmit,
                noValidate: true,
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_forms__WEBPACK_IMPORTED_MODULE_1__["Label"], {
                    htmlFor: "email",
                    children: "Email"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 87,
                    columnNumber: 21
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_forms__WEBPACK_IMPORTED_MODULE_1__["Input"], {
                    type: "email",
                    id: "email",
                    name: "email",
                    placeholder: "email@address.com",
                    ref: register({
                      required: 'Email is required.',
                      validate: email => Object(_shared_index__WEBPACK_IMPORTED_MODULE_7__["isValidEmail"])(email) || 'Email address is invalid.'
                    }),
                    error: (_formErrors$email = formErrors.email) === null || _formErrors$email === void 0 ? void 0 : _formErrors$email.message,
                    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_icons_icons__WEBPACK_IMPORTED_MODULE_2__["EmailIcon"], {}, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 99,
                      columnNumber: 29
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 88,
                    columnNumber: 21
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 86,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_forms__WEBPACK_IMPORTED_MODULE_1__["Label"], {
                    htmlFor: "password",
                    children: "Password"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 104,
                    columnNumber: 21
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_forms__WEBPACK_IMPORTED_MODULE_1__["Input"], {
                    type: "password",
                    id: "password",
                    name: "password",
                    placeholder: "Password",
                    ref: register({
                      required: 'Password is required.',
                      minLength: {
                        value: 6,
                        message: 'Password must be at least 6 characters.'
                      }
                    }),
                    error: (_formErrors$password = formErrors.password) === null || _formErrors$password === void 0 ? void 0 : _formErrors$password.message,
                    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_icons_icons__WEBPACK_IMPORTED_MODULE_2__["LockIcon"], {}, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 118,
                      columnNumber: 29
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 105,
                    columnNumber: 21
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 103,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_forms__WEBPACK_IMPORTED_MODULE_1__["Label"], {
                    htmlFor: "confirmPassword",
                    children: "Confirm Password"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 123,
                    columnNumber: 21
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_forms__WEBPACK_IMPORTED_MODULE_1__["Input"], {
                    type: "password",
                    id: "confirmPassword",
                    name: "confirmPassword",
                    placeholder: "Confirm Password",
                    ref: register({
                      required: 'Password confirmation is required.',
                      minLength: {
                        value: 6,
                        message: 'Password must be at least 6 characters.'
                      },
                      validate: confirmPassword => confirmPassword === passwordRef.current || 'The passwords do not match.'
                    }),
                    error: (_formErrors$confirmPa = formErrors.confirmPassword) === null || _formErrors$confirmPa === void 0 ? void 0 : _formErrors$confirmPa.message,
                    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_icons_icons__WEBPACK_IMPORTED_MODULE_2__["LockIcon"], {}, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 143,
                      columnNumber: 29
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 127,
                    columnNumber: 21
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 122,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_forms__WEBPACK_IMPORTED_MODULE_1__["Label"], {
                    htmlFor: "givenName",
                    children: "Referral Code"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 148,
                    columnNumber: 21
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_forms__WEBPACK_IMPORTED_MODULE_1__["Input"], {
                    type: "text",
                    id: "givenName",
                    name: "givenName",
                    placeholder: "Referral Code",
                    ref: register({
                      required: 'First Name is required.'
                    }),
                    error: (_formErrors$givenName = formErrors.givenName) === null || _formErrors$givenName === void 0 ? void 0 : _formErrors$givenName.message,
                    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_icons_icons__WEBPACK_IMPORTED_MODULE_2__["UserIcon"], {}, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 156,
                      columnNumber: 29
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 149,
                    columnNumber: 21
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 147,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_forms__WEBPACK_IMPORTED_MODULE_1__["Label"], {
                    htmlFor: "familyName",
                    children: "Last Name"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 161,
                    columnNumber: 21
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_forms__WEBPACK_IMPORTED_MODULE_1__["Input"], {
                    type: "text",
                    id: "familyName",
                    name: "familyName",
                    placeholder: "e.g. Smith",
                    ref: register({
                      required: 'Last Name is required.'
                    }),
                    error: (_formErrors$familyNam = formErrors.familyName) === null || _formErrors$familyNam === void 0 ? void 0 : _formErrors$familyNam.message,
                    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_icons_icons__WEBPACK_IMPORTED_MODULE_2__["UserIcon"], {}, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 169,
                      columnNumber: 29
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 162,
                    columnNumber: 21
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 160,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_forms__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                    type: "submit",
                    isFullWidth: true,
                    disabled: !!isLoading,
                    children: ["Register ", isLoading && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_loading_spinner__WEBPACK_IMPORTED_MODULE_4__["LoadingInline"], {}, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 175,
                      columnNumber: 46
                    }, this)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 174,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 173,
                  columnNumber: 19
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 85,
                columnNumber: 17
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "text-center mt-5 mb-5",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  className: "text-600 font-medium line-height-3",
                  children: "Already have an account "
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 180,
                  columnNumber: 13
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_next_link__WEBPACK_IMPORTED_MODULE_5__["NextLink"], {
                  href: src_constants__WEBPACK_IMPORTED_MODULE_11__["ROUTE_PATHS"].LOGIN,
                  className: "text-sm font-medium text-indigo-600 hover:text-indigo-500",
                  children: "Log In"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 181,
                  columnNumber: 13
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 179,
                columnNumber: 17
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 79,
              columnNumber: 15
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 78,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 64,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 63,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 62,
      columnNumber: 7
    }, this)]
  }, void 0, true);
}

_s(Register, "oKaOfQdA030LeSKwOOKs+mxjRtU=", false, function () {
  return [_use_register__WEBPACK_IMPORTED_MODULE_12__["useRegister"], _context_notification__WEBPACK_IMPORTED_MODULE_6__["useNotification"]];
});

_c2 = Register;

var _c, _c2;

$RefreshReg$(_c, "%default%");
$RefreshReg$(_c2, "Register");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL3BhZ2VzL2F1dGgvcmVnaXN0ZXIvcmVnaXN0ZXIudHN4Il0sIm5hbWVzIjpbInVybCIsIkZST05URU5EX0JBU0VfVVJMIiwiUk9VVEVfUEFUSFMiLCJSRUdJU1RFUiIsInRpdGxlIiwiZGVzY3JpcHRpb24iLCJ3aXRoQW5vbnltb3VzIiwiUmVnaXN0ZXIiLCJoYW5kbGVTdWJtaXQiLCJyZWdpc3RlciIsImZvcm1FcnJvcnMiLCJwYXNzd29yZFJlZiIsImlzRXJyb3IiLCJlcnJvciIsImlzU3VjY2VzcyIsImlzTG9hZGluZyIsInVzZVJlZ2lzdGVyIiwiYWRkTm90aWZpY2F0aW9uIiwidXNlTm90aWZpY2F0aW9uIiwidXNlRWZmZWN0IiwidHlwZSIsIk5vdGlmaWNhdGlvblR5cGUiLCJTVUNDRVNTIiwibWVzc2FnZSIsIkVSUk9SIiwicmVxdWlyZWQiLCJ2YWxpZGF0ZSIsImVtYWlsIiwiaXNWYWxpZEVtYWlsIiwibWluTGVuZ3RoIiwidmFsdWUiLCJwYXNzd29yZCIsImNvbmZpcm1QYXNzd29yZCIsImN1cnJlbnQiLCJnaXZlbk5hbWUiLCJmYW1pbHlOYW1lIiwiTE9HSU4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUEsTUFBTUEsR0FBRyxHQUFJLEdBQUVDLGdFQUFrQixHQUFFQywwREFBVyxDQUFDQyxRQUFTLEVBQXhEO0FBQ0EsTUFBTUMsS0FBSyxHQUFHLFVBQWQ7QUFDQSxNQUFNQyxXQUFXLEdBQUcseUJBQXBCO0FBRWUsb0VBQUFDLHVFQUFhLENBQUNDLFFBQUQsQ0FBNUI7O0FBRUEsU0FBU0EsUUFBVCxHQUFvQjtBQUFBOztBQUFBOztBQUNsQixRQUFNO0FBQ0pDLGdCQURJO0FBRUpDLFlBRkk7QUFHSkMsY0FISTtBQUlKQyxlQUpJO0FBS0pDLFdBTEk7QUFNSkMsU0FOSTtBQU9KQyxhQVBJO0FBUUpDO0FBUkksTUFTRkMsa0VBQVcsRUFUZjtBQVdBLFFBQU07QUFBQ0M7QUFBRCxNQUFvQkMsNkVBQWUsRUFBekM7QUFFQUMsMERBQVMsQ0FBQyxNQUFNO0FBQ2QsUUFBSUwsU0FBSixFQUFlO0FBQ2JHLHFCQUFlLENBQUM7QUFDZEcsWUFBSSxFQUFFQyxzRUFBZ0IsQ0FBQ0MsT0FEVDtBQUVkbEIsYUFBSyxFQUNILCtGQUhZO0FBSWRtQixlQUFPLEVBQUU7QUFKSyxPQUFELENBQWY7QUFNRDs7QUFFRCxRQUFJWCxPQUFPLElBQUlDLEtBQWYsRUFBc0I7QUFDcEJJLHFCQUFlLENBQUM7QUFBQ0csWUFBSSxFQUFFQyxzRUFBZ0IsQ0FBQ0csS0FBeEI7QUFBK0JwQixhQUFLLEVBQUVTLEtBQUssQ0FBQ1U7QUFBNUMsT0FBRCxDQUFmO0FBQ0Q7QUFDRixHQWJRLEVBYU4sQ0FBQ04sZUFBRCxFQUFrQkosS0FBbEIsRUFBeUJELE9BQXpCLEVBQWtDRSxTQUFsQyxDQWJNLENBQVQ7QUFlQSxzQkFDRTtBQUFBLDRCQUNFLHFFQUFDLGdEQUFEO0FBQ0UsV0FBSyxFQUFFVixLQURUO0FBRUUsaUJBQVcsRUFBRUMsV0FGZjtBQUdFLGVBQVMsRUFBRUwsR0FIYjtBQUlFLGVBQVMsRUFBRTtBQUNUQSxXQURTO0FBRVRJLGFBRlM7QUFHVEM7QUFIUztBQUpiO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERixlQVdFLHFFQUFDLHVEQUFEO0FBQU0sZUFBUyxFQUFDLHFDQUFoQjtBQUFBLDZCQUNFO0FBQUssaUJBQVMsRUFBQyxTQUFmO0FBQUEsK0JBQ0U7QUFBSyxtQkFBUyxFQUFDLFdBQWY7QUFBQSxpQ0FjRTtBQUFLLHFCQUFTLEVBQUMsNENBQWY7QUFBQSxtQ0FDRTtBQUFLLHVCQUFTLEVBQUMsa0RBQWY7QUFBQSxzQ0FDQTtBQUFLLHlCQUFTLEVBQUMsK0JBQWY7QUFBQSx3Q0FDRjtBQUFLLDJCQUFTLEVBQUMsb0NBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBREUsZUFFRjtBQUFNLDJCQUFTLEVBQUMsb0NBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUZFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFEQSxlQU1FO0FBQU0seUJBQVMsRUFBQyxXQUFoQjtBQUE0Qix3QkFBUSxFQUFFRyxZQUF0QztBQUFvRCwwQkFBVSxNQUE5RDtBQUFBLHdDQUNFO0FBQUEsMENBQ0UscUVBQUMsdURBQUQ7QUFBTywyQkFBTyxFQUFDLE9BQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBREYsZUFFRSxxRUFBQyx1REFBRDtBQUNFLHdCQUFJLEVBQUMsT0FEUDtBQUVFLHNCQUFFLEVBQUMsT0FGTDtBQUdFLHdCQUFJLEVBQUMsT0FIUDtBQUlFLCtCQUFXLEVBQUMsbUJBSmQ7QUFLRSx1QkFBRyxFQUFFQyxRQUFRLENBQUM7QUFDWmdCLDhCQUFRLEVBQUUsb0JBREU7QUFFWkMsOEJBQVEsRUFBRUMsS0FBSyxJQUNiQyxrRUFBWSxDQUFDRCxLQUFELENBQVosSUFBdUI7QUFIYixxQkFBRCxDQUxmO0FBVUUseUJBQUssdUJBQUVqQixVQUFVLENBQUNpQixLQUFiLHNEQUFFLGtCQUFrQkosT0FWM0I7QUFXRSx3QkFBSSxlQUFFLHFFQUFDLGlFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFYUjtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFERixlQWtCRTtBQUFBLDBDQUNFLHFFQUFDLHVEQUFEO0FBQU8sMkJBQU8sRUFBQyxVQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQURGLGVBRUUscUVBQUMsdURBQUQ7QUFDRSx3QkFBSSxFQUFDLFVBRFA7QUFFRSxzQkFBRSxFQUFDLFVBRkw7QUFHRSx3QkFBSSxFQUFDLFVBSFA7QUFJRSwrQkFBVyxFQUFDLFVBSmQ7QUFLRSx1QkFBRyxFQUFFZCxRQUFRLENBQUM7QUFDWmdCLDhCQUFRLEVBQUUsdUJBREU7QUFFWkksK0JBQVMsRUFBRTtBQUNUQyw2QkFBSyxFQUFFLENBREU7QUFFVFAsK0JBQU8sRUFBRTtBQUZBO0FBRkMscUJBQUQsQ0FMZjtBQVlFLHlCQUFLLDBCQUFFYixVQUFVLENBQUNxQixRQUFiLHlEQUFFLHFCQUFxQlIsT0FaOUI7QUFhRSx3QkFBSSxlQUFFLHFFQUFDLGdFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFiUjtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFsQkYsZUFxQ0U7QUFBQSwwQ0FDRSxxRUFBQyx1REFBRDtBQUFPLDJCQUFPLEVBQUMsaUJBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBREYsZUFLRSxxRUFBQyx1REFBRDtBQUNFLHdCQUFJLEVBQUMsVUFEUDtBQUVFLHNCQUFFLEVBQUMsaUJBRkw7QUFHRSx3QkFBSSxFQUFDLGlCQUhQO0FBSUUsK0JBQVcsRUFBQyxrQkFKZDtBQUtFLHVCQUFHLEVBQUVkLFFBQVEsQ0FBQztBQUNaZ0IsOEJBQVEsRUFBRSxvQ0FERTtBQUVaSSwrQkFBUyxFQUFFO0FBQ1RDLDZCQUFLLEVBQUUsQ0FERTtBQUVUUCwrQkFBTyxFQUFFO0FBRkEsdUJBRkM7QUFNWkcsOEJBQVEsRUFBRU0sZUFBZSxJQUN2QkEsZUFBZSxLQUFLckIsV0FBVyxDQUFDc0IsT0FBaEMsSUFDQTtBQVJVLHFCQUFELENBTGY7QUFlRSx5QkFBSywyQkFBRXZCLFVBQVUsQ0FBQ3NCLGVBQWIsMERBQUUsc0JBQTRCVCxPQWZyQztBQWdCRSx3QkFBSSxlQUFFLHFFQUFDLGdFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFoQlI7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBckNGLGVBOERFO0FBQUEsMENBQ0UscUVBQUMsdURBQUQ7QUFBTywyQkFBTyxFQUFDLFdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBREYsZUFFRSxxRUFBQyx1REFBRDtBQUNFLHdCQUFJLEVBQUMsTUFEUDtBQUVFLHNCQUFFLEVBQUMsV0FGTDtBQUdFLHdCQUFJLEVBQUMsV0FIUDtBQUlFLCtCQUFXLEVBQUMsZUFKZDtBQUtFLHVCQUFHLEVBQUVkLFFBQVEsQ0FBQztBQUFDZ0IsOEJBQVEsRUFBRTtBQUFYLHFCQUFELENBTGY7QUFNRSx5QkFBSywyQkFBRWYsVUFBVSxDQUFDd0IsU0FBYiwwREFBRSxzQkFBc0JYLE9BTi9CO0FBT0Usd0JBQUksZUFBRSxxRUFBQyxnRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBUFI7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBOURGLGVBMkVFO0FBQUEsMENBQ0UscUVBQUMsdURBQUQ7QUFBTywyQkFBTyxFQUFDLFlBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBREYsZUFFRSxxRUFBQyx1REFBRDtBQUNFLHdCQUFJLEVBQUMsTUFEUDtBQUVFLHNCQUFFLEVBQUMsWUFGTDtBQUdFLHdCQUFJLEVBQUMsWUFIUDtBQUlFLCtCQUFXLEVBQUMsWUFKZDtBQUtFLHVCQUFHLEVBQUVkLFFBQVEsQ0FBQztBQUFDZ0IsOEJBQVEsRUFBRTtBQUFYLHFCQUFELENBTGY7QUFNRSx5QkFBSywyQkFBRWYsVUFBVSxDQUFDeUIsVUFBYiwwREFBRSxzQkFBdUJaLE9BTmhDO0FBT0Usd0JBQUksZUFBRSxxRUFBQyxnRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBUFI7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBM0VGLGVBd0ZFO0FBQUEseUNBQ0UscUVBQUMsd0RBQUQ7QUFBUSx3QkFBSSxFQUFDLFFBQWI7QUFBc0IsK0JBQVcsTUFBakM7QUFBa0MsNEJBQVEsRUFBRSxDQUFDLENBQUNSLFNBQTlDO0FBQUEsNENBQ1lBLFNBQVMsaUJBQUkscUVBQUMseUVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw0QkFEekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkF4RkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQU5GLGVBb0dFO0FBQUsseUJBQVMsRUFBQyx1QkFBZjtBQUFBLHdDQUNKO0FBQU0sMkJBQVMsRUFBQyxvQ0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBREksZUFFSixxRUFBQyw4REFBRDtBQUNVLHNCQUFJLEVBQUViLDBEQUFXLENBQUNrQyxLQUQ1QjtBQUVVLDJCQUFTLEVBQUMsMkRBRnBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUZJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFwR0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVhGO0FBQUEsa0JBREY7QUF3SkQ7O0dBckxRN0IsUTtVQVVIUywwRCxFQUVzQkUscUU7OztNQVpuQlgsUSIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9hdXRoL3JlZ2lzdGVyLmQ5ZWQ0NWI3ZTg3NzUxMWU2MDg1LmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge0J1dHRvbiwgSW5wdXQsIExhYmVsfSBmcm9tICdAY29tcG9uZW50cy9mb3Jtcyc7XG5pbXBvcnQge0hlYWRpbmcsIFN1YkhlYWRpbmd9IGZyb20gJ0Bjb21wb25lbnRzL2hlYWRpbmcvaGVhZGluZyc7XG5pbXBvcnQge0VtYWlsSWNvbiwgTG9ja0ljb24sIFVzZXJJY29ufSBmcm9tICdAY29tcG9uZW50cy9pY29ucy9pY29ucyc7XG5pbXBvcnQge0ZsZXh9IGZyb20gJ0Bjb21wb25lbnRzL2xheW91dCc7XG5pbXBvcnQge0xvYWRpbmdJbmxpbmV9IGZyb20gJ0Bjb21wb25lbnRzL2xvYWRpbmctc3Bpbm5lcic7XG5pbXBvcnQge05leHRMaW5rfSBmcm9tICdAY29tcG9uZW50cy9uZXh0LWxpbmsnO1xuaW1wb3J0IHtOb3RpZmljYXRpb25UeXBlLCB1c2VOb3RpZmljYXRpb259IGZyb20gJ0Bjb250ZXh0L25vdGlmaWNhdGlvbic7XG5pbXBvcnQge2lzVmFsaWRFbWFpbH0gZnJvbSAnQHNoYXJlZC9pbmRleCc7XG5pbXBvcnQge3dpdGhBbm9ueW1vdXN9IGZyb20gJ0B1dGlscy9yb3V0ZS1ob2NzJztcbmltcG9ydCB7TmV4dFNlb30gZnJvbSAnbmV4dC1zZW8nO1xuaW1wb3J0IHt1c2VFZmZlY3R9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7RlJPTlRFTkRfQkFTRV9VUkwsIElNQUdFX1BBVEhTLCBST1VURV9QQVRIU30gZnJvbSAnc3JjL2NvbnN0YW50cyc7XG5pbXBvcnQge3VzZVJlZ2lzdGVyfSBmcm9tICcuL3VzZS1yZWdpc3Rlcic7XG5cbmNvbnN0IHVybCA9IGAke0ZST05URU5EX0JBU0VfVVJMfSR7Uk9VVEVfUEFUSFMuUkVHSVNURVJ9YDtcbmNvbnN0IHRpdGxlID0gJ1JlZ2lzdGVyJztcbmNvbnN0IGRlc2NyaXB0aW9uID0gJ1JlZ2lzdGVyIGZvciBhbiBhY2NvdW50JztcblxuZXhwb3J0IGRlZmF1bHQgd2l0aEFub255bW91cyhSZWdpc3Rlcik7XG5cbmZ1bmN0aW9uIFJlZ2lzdGVyKCkge1xuICBjb25zdCB7XG4gICAgaGFuZGxlU3VibWl0LFxuICAgIHJlZ2lzdGVyLFxuICAgIGZvcm1FcnJvcnMsXG4gICAgcGFzc3dvcmRSZWYsXG4gICAgaXNFcnJvcixcbiAgICBlcnJvcixcbiAgICBpc1N1Y2Nlc3MsXG4gICAgaXNMb2FkaW5nLFxuICB9ID0gdXNlUmVnaXN0ZXIoKTtcblxuICBjb25zdCB7YWRkTm90aWZpY2F0aW9ufSA9IHVzZU5vdGlmaWNhdGlvbigpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGlzU3VjY2Vzcykge1xuICAgICAgYWRkTm90aWZpY2F0aW9uKHtcbiAgICAgICAgdHlwZTogTm90aWZpY2F0aW9uVHlwZS5TVUNDRVNTLFxuICAgICAgICB0aXRsZTpcbiAgICAgICAgICAnUGxlYXNlIGNsaWNrIG9uIHRoZSBhY3RpdmF0aW9uIGxpbmssIHNlbnQgdG8geW91ciBlbWFpbCBhZGRyZXNzIHRvIGNvbXBsZXRlIHRoZSByZWdpc3RyYXRpb24uJyxcbiAgICAgICAgbWVzc2FnZTogJ0Zvcm0gc3VibWl0dGVkIHN1Y2Nlc3NmdWxseS4nLFxuICAgICAgfSk7XG4gICAgfVxuXG4gICAgaWYgKGlzRXJyb3IgJiYgZXJyb3IpIHtcbiAgICAgIGFkZE5vdGlmaWNhdGlvbih7dHlwZTogTm90aWZpY2F0aW9uVHlwZS5FUlJPUiwgdGl0bGU6IGVycm9yLm1lc3NhZ2V9KTtcbiAgICB9XG4gIH0sIFthZGROb3RpZmljYXRpb24sIGVycm9yLCBpc0Vycm9yLCBpc1N1Y2Nlc3NdKTtcblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8TmV4dFNlb1xuICAgICAgICB0aXRsZT17dGl0bGV9XG4gICAgICAgIGRlc2NyaXB0aW9uPXtkZXNjcmlwdGlvbn1cbiAgICAgICAgY2Fub25pY2FsPXt1cmx9XG4gICAgICAgIG9wZW5HcmFwaD17e1xuICAgICAgICAgIHVybCxcbiAgICAgICAgICB0aXRsZSxcbiAgICAgICAgICBkZXNjcmlwdGlvbixcbiAgICAgICAgfX1cbiAgICAgIC8+XG4gICAgICA8RmxleCBjbGFzc05hbWU9XCJmbGV4LWNvbCBweS0xMiBtdC00IHNtOnB4LTYgbGc6cHgtOFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxnOmZsZXhcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxnOmZsZXgtMVwiPlxuICAgICAgICAgICAgey8qIDxkaXYgY2xhc3NOYW1lPVwicC0yIHNtOm14LWF1dG8gc206dy1mdWxsIHNtOm1heC13LW1kXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPEhlYWRpbmc+UmVnaXN0ZXIgZm9yIGFuIGFjY291bnQ8L0hlYWRpbmc+XG4gICAgICAgICAgICAgICAgICA8U3ViSGVhZGluZz5cbiAgICAgICAgICAgICAgICAgICAgQWZ0ZXIgeW91IGZpbGwgaW4gdGhlIGZvcm0sIHlvdSB3aWxsIHJlY2VpdmUgYW4gZW1haWwgd2l0aFxuICAgICAgICAgICAgICAgICAgICBhbiBhY3RpdmF0aW9uIGxpbmsgLSBjbGljayBvbiB0aGUgbGluayB0byBjb21wbGV0ZSB0aGVcbiAgICAgICAgICAgICAgICAgICAgcHJvY2Vzcy5cbiAgICAgICAgICAgICAgICAgIDwvU3ViSGVhZGluZz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj4gKi99XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtOCBzbTpteC1hdXRvIHNtOnctZnVsbCBzbTptYXgtdy1tZCB0ZXN0XCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNCBweS04IGJnLXdoaXRlIHNoYWRvdyBzbTpyb3VuZGVkLWxnIHNtOnB4LTEwXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgbWItNSBjdXN0b21oZWFkZXJcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC05MDAgdGV4dC0zeGwgZm9udC1tZWRpdW0gbWItM1wiPldlbGNvbWU8L2Rpdj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtNjAwIGZvbnQtbWVkaXVtIGxpbmUtaGVpZ2h0LTNcIj5DcmVhdGUgYW4gYWNjb3VudDwvc3Bhbj5cbiAgICAgICAgICAgIFxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJzcGFjZS15LTJcIiBvblN1Ym1pdD17aGFuZGxlU3VibWl0fSBub1ZhbGlkYXRlPlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPExhYmVsIGh0bWxGb3I9XCJlbWFpbFwiPkVtYWlsPC9MYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImVtYWlsXCJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cImVtYWlsXCJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZW1haWxcIlxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZW1haWxAYWRkcmVzcy5jb21cIlxuICAgICAgICAgICAgICAgICAgICAgIHJlZj17cmVnaXN0ZXIoe1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWQ6ICdFbWFpbCBpcyByZXF1aXJlZC4nLFxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdGU6IGVtYWlsID0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlzVmFsaWRFbWFpbChlbWFpbCkgfHwgJ0VtYWlsIGFkZHJlc3MgaXMgaW52YWxpZC4nLFxuICAgICAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgICAgICAgIGVycm9yPXtmb3JtRXJyb3JzLmVtYWlsPy5tZXNzYWdlfVxuICAgICAgICAgICAgICAgICAgICAgIGljb249ezxFbWFpbEljb24gLz59XG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPExhYmVsIGh0bWxGb3I9XCJwYXNzd29yZFwiPlBhc3N3b3JkPC9MYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiUGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgICAgIHJlZj17cmVnaXN0ZXIoe1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWQ6ICdQYXNzd29yZCBpcyByZXF1aXJlZC4nLFxuICAgICAgICAgICAgICAgICAgICAgICAgbWluTGVuZ3RoOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlOiA2LFxuICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiAnUGFzc3dvcmQgbXVzdCBiZSBhdCBsZWFzdCA2IGNoYXJhY3RlcnMuJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgZXJyb3I9e2Zvcm1FcnJvcnMucGFzc3dvcmQ/Lm1lc3NhZ2V9XG4gICAgICAgICAgICAgICAgICAgICAgaWNvbj17PExvY2tJY29uIC8+fVxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxMYWJlbCBodG1sRm9yPVwiY29uZmlybVBhc3N3b3JkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgQ29uZmlybSBQYXNzd29yZFxuICAgICAgICAgICAgICAgICAgICA8L0xhYmVsPlxuXG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJjb25maXJtUGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjb25maXJtUGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQ29uZmlybSBQYXNzd29yZFwiXG4gICAgICAgICAgICAgICAgICAgICAgcmVmPXtyZWdpc3Rlcih7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZDogJ1Bhc3N3b3JkIGNvbmZpcm1hdGlvbiBpcyByZXF1aXJlZC4nLFxuICAgICAgICAgICAgICAgICAgICAgICAgbWluTGVuZ3RoOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlOiA2LFxuICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiAnUGFzc3dvcmQgbXVzdCBiZSBhdCBsZWFzdCA2IGNoYXJhY3RlcnMuJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0ZTogY29uZmlybVBhc3N3b3JkID0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbmZpcm1QYXNzd29yZCA9PT0gcGFzc3dvcmRSZWYuY3VycmVudCB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgICAnVGhlIHBhc3N3b3JkcyBkbyBub3QgbWF0Y2guJyxcbiAgICAgICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICAgICAgICBlcnJvcj17Zm9ybUVycm9ycy5jb25maXJtUGFzc3dvcmQ/Lm1lc3NhZ2V9XG4gICAgICAgICAgICAgICAgICAgICAgaWNvbj17PExvY2tJY29uIC8+fVxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxMYWJlbCBodG1sRm9yPVwiZ2l2ZW5OYW1lXCI+UmVmZXJyYWwgQ29kZTwvTGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cImdpdmVuTmFtZVwiXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImdpdmVuTmFtZVwiXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJSZWZlcnJhbCBDb2RlXCJcbiAgICAgICAgICAgICAgICAgICAgICByZWY9e3JlZ2lzdGVyKHtyZXF1aXJlZDogJ0ZpcnN0IE5hbWUgaXMgcmVxdWlyZWQuJ30pfVxuICAgICAgICAgICAgICAgICAgICAgIGVycm9yPXtmb3JtRXJyb3JzLmdpdmVuTmFtZT8ubWVzc2FnZX1cbiAgICAgICAgICAgICAgICAgICAgICBpY29uPXs8VXNlckljb24gLz59XG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPExhYmVsIGh0bWxGb3I9XCJmYW1pbHlOYW1lXCI+TGFzdCBOYW1lPC9MYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwiZmFtaWx5TmFtZVwiXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImZhbWlseU5hbWVcIlxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZS5nLiBTbWl0aFwiXG4gICAgICAgICAgICAgICAgICAgICAgcmVmPXtyZWdpc3Rlcih7cmVxdWlyZWQ6ICdMYXN0IE5hbWUgaXMgcmVxdWlyZWQuJ30pfVxuICAgICAgICAgICAgICAgICAgICAgIGVycm9yPXtmb3JtRXJyb3JzLmZhbWlseU5hbWU/Lm1lc3NhZ2V9XG4gICAgICAgICAgICAgICAgICAgICAgaWNvbj17PFVzZXJJY29uIC8+fVxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxCdXR0b24gdHlwZT1cInN1Ym1pdFwiIGlzRnVsbFdpZHRoIGRpc2FibGVkPXshIWlzTG9hZGluZ30+XG4gICAgICAgICAgICAgICAgICAgICAgUmVnaXN0ZXIge2lzTG9hZGluZyAmJiA8TG9hZGluZ0lubGluZSAvPn1cbiAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBtdC01IG1iLTVcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtNjAwIGZvbnQtbWVkaXVtIGxpbmUtaGVpZ2h0LTNcIj5BbHJlYWR5IGhhdmUgYW4gYWNjb3VudCA8L3NwYW4+XG4gICAgICAgICAgICA8TmV4dExpbmtcbiAgICAgICAgICAgICAgICAgICAgICBocmVmPXtST1VURV9QQVRIUy5MT0dJTn1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtaW5kaWdvLTYwMCBob3Zlcjp0ZXh0LWluZGlnby01MDBcIlxuICAgICAgICAgICAgICAgICAgICA+TG9nIEluXG4gICAgICAgICAgICAgICAgICAgICAgIDwvTmV4dExpbms+XG4gICAgICAgICAgICB7LyogPGEgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gbm8tdW5kZXJsaW5lIG1sLTIgdGV4dC1ibHVlLTUwMCBjdXJzb3ItcG9pbnRlclwiPjwvYT4gKi99XG4gICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIHsvKiA8ZGl2IGNsYXNzTmFtZT1cImxnOmZsZXgtMVwiPlxuICAgICAgICAgICAgPGltZ1xuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoaWRkZW4gb2JqZWN0LWNvbnRhaW4gdy1mdWxsIGgtNTYgbGc6aC1mdWxsIGxnOmlubGluZVwiXG4gICAgICAgICAgICAgIHNyYz17SU1BR0VfUEFUSFMuV09NQU5fU0lHTklOR19VUH1cbiAgICAgICAgICAgICAgYWx0PVwid29tYW4gc2lnbmluZyB1cFwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PiAqL31cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L0ZsZXg+XG4gICAgPC8+XG4gICk7XG59XG4iXSwic291cmNlUm9vdCI6IiJ9