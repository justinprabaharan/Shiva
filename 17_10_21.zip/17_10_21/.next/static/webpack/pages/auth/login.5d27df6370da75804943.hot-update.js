webpackHotUpdate_N_E("pages/auth/login",{

/***/ "./src/pages/auth/login/login.tsx":
/*!****************************************!*\
  !*** ./src/pages/auth/login/login.tsx ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @components/forms */ "./src/components/forms/index.ts");
/* harmony import */ var _components_icons_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @components/icons/icons */ "./src/components/icons/icons.tsx");
/* harmony import */ var _components_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @components/layout */ "./src/components/layout/index.ts");
/* harmony import */ var _components_loading_spinner__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @components/loading-spinner */ "./src/components/loading-spinner/index.ts");
/* harmony import */ var _components_next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @components/next-link */ "./src/components/next-link/index.ts");
/* harmony import */ var _context_notification__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @context/notification */ "./src/context/notification/index.ts");
/* harmony import */ var _shared_index__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @shared/index */ "./shared/index.ts");
/* harmony import */ var _utils_route_hocs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @utils/route-hocs */ "./src/utils/route-hocs.tsx");
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! next-seo */ "./node_modules/next-seo/lib/next-seo.module.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var src_constants__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/constants */ "./src/constants.ts");
/* harmony import */ var _use_login__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./use-login */ "./src/pages/auth/login/use-login.js");



var _jsxFileName = "J:\\Project\\reference\\aws-amplify-react-auth-master-toshare\\aws-amplify-react-auth-master-toshare\\src\\pages\\auth\\login\\login.tsx",
    _s = $RefreshSig$();













const url = `${src_constants__WEBPACK_IMPORTED_MODULE_11__["FRONTEND_BASE_URL"]}${src_constants__WEBPACK_IMPORTED_MODULE_11__["ROUTE_PATHS"].LOGIN}`;
const title = 'Login';
const description = 'Sign into your account';
/* harmony default export */ __webpack_exports__["default"] = (_c = Object(_utils_route_hocs__WEBPACK_IMPORTED_MODULE_8__["withAnonymous"])(Login));

function Login() {
  _s();

  var _formErrors$email, _formErrors$password;

  const {
    handleSubmit,
    register,
    formErrors,
    isError,
    error,
    isLoading
  } = Object(_use_login__WEBPACK_IMPORTED_MODULE_12__["useLogin"])();
  const {
    addNotification
  } = Object(_context_notification__WEBPACK_IMPORTED_MODULE_6__["useNotification"])();
  Object(react__WEBPACK_IMPORTED_MODULE_10__["useEffect"])(() => {
    if (isError && error) {
      addNotification({
        type: _context_notification__WEBPACK_IMPORTED_MODULE_6__["NotificationType"].ERROR,
        title: error.message,
        message: 'Your request has failed.'
      });
    }
  }, [addNotification, error, isError]);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_seo__WEBPACK_IMPORTED_MODULE_9__["NextSeo"], {
      title: title,
      description: description,
      canonical: url,
      openGraph: {
        url,
        title,
        description
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 45,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "flex flex-col mt-12 sm:px-6 lg:px-8",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "lg:flex",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "lg:flex-1",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "mt-8 sm:mx-auto sm:w-full sm:max-w-md test",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "px-4 py-8 bg-white shadow sm:rounded-lg sm:px-10",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "sm:mx-auto sm:w-full sm:max-w-md",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "text-center",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "text-center mb-5 customheader",
                    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "text-900 text-3xl font-medium mb-3",
                      children: "Welcome Back!"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 65,
                      columnNumber: 21
                    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                      className: "text-600 font-medium line-height-3",
                      children: "Access the following Pillar life personal accounts:"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 66,
                      columnNumber: 21
                    }, this)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 64,
                    columnNumber: 19
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 63,
                  columnNumber: 19
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 62,
                columnNumber: 19
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("form", {
                className: "space-y-4",
                onSubmit: handleSubmit,
                noValidate: true,
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_forms__WEBPACK_IMPORTED_MODULE_1__["Label"], {
                    htmlFor: "email",
                    children: "Email"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 73,
                    columnNumber: 21
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_forms__WEBPACK_IMPORTED_MODULE_1__["Input"], {
                    type: "email",
                    id: "email",
                    name: "email",
                    placeholder: "email@address.com",
                    ref: register({
                      required: 'Email is required.',
                      validate: email => Object(_shared_index__WEBPACK_IMPORTED_MODULE_7__["isValidEmail"])(email) || 'Email address is invalid.'
                    }),
                    error: (_formErrors$email = formErrors.email) === null || _formErrors$email === void 0 ? void 0 : _formErrors$email.message,
                    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_icons_icons__WEBPACK_IMPORTED_MODULE_2__["EmailIcon"], {}, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 85,
                      columnNumber: 29
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 74,
                    columnNumber: 21
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 72,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_forms__WEBPACK_IMPORTED_MODULE_1__["Label"], {
                    htmlFor: "password",
                    children: "Password"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 90,
                    columnNumber: 21
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_forms__WEBPACK_IMPORTED_MODULE_1__["Input"], {
                    type: "password",
                    id: "password",
                    name: "password",
                    placeholder: "Password",
                    ref: register({
                      required: 'Password is required.',
                      minLength: {
                        value: 6,
                        message: 'Password must be at least 6 characters.'
                      }
                    }),
                    error: (_formErrors$password = formErrors.password) === null || _formErrors$password === void 0 ? void 0 : _formErrors$password.message,
                    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_icons_icons__WEBPACK_IMPORTED_MODULE_2__["LockIcon"], {}, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 104,
                      columnNumber: 29
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 91,
                    columnNumber: 21
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 89,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "flex align-items-center justify-content-between mb-3",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "flex align-items-center"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 108,
                    columnNumber: 21
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                    className: "font-medium no-underline ml-2 text-blue-500 text-right cursor-pointer",
                    children: "Forgot your password?"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 111,
                    columnNumber: 21
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 107,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_layout__WEBPACK_IMPORTED_MODULE_3__["Flex"], {
                  className: "items-center justify-between",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_next_link__WEBPACK_IMPORTED_MODULE_5__["NextLink"], {
                    href: src_constants__WEBPACK_IMPORTED_MODULE_11__["ROUTE_PATHS"].REQUEST_PASSWORD_RESET,
                    className: "text-sm font-medium text-indigo-600 hover:text-indigo-500",
                    children: "Forgot password?"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 121,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 113,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_forms__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                    type: "submit",
                    disabled: !!isLoading,
                    isFullWidth: true,
                    children: ["Log In ", isLoading && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_loading_spinner__WEBPACK_IMPORTED_MODULE_4__["LoadingInline"], {}, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 131,
                      columnNumber: 44
                    }, this)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 130,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 129,
                  columnNumber: 19
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 71,
                columnNumber: 17
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "text-center mb-5",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  className: "text-600 font-medium line-height-3",
                  children: "Not a member? "
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 136,
                  columnNumber: 13
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  className: "font-medium no-underline ml-2 text-blue-500 cursor-pointer",
                  children: "Create an account now"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 137,
                  columnNumber: 13
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 135,
                columnNumber: 17
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 61,
              columnNumber: 15
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 59,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 57,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 56,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 55,
      columnNumber: 7
    }, this)]
  }, void 0, true);
}

_s(Login, "UE7oUpBS961EQsNUlHtP3xXg1O8=", false, function () {
  return [_use_login__WEBPACK_IMPORTED_MODULE_12__["useLogin"], _context_notification__WEBPACK_IMPORTED_MODULE_6__["useNotification"]];
});

_c2 = Login;

var _c, _c2;

$RefreshReg$(_c, "%default%");
$RefreshReg$(_c2, "Login");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL3BhZ2VzL2F1dGgvbG9naW4vbG9naW4udHN4Il0sIm5hbWVzIjpbInVybCIsIkZST05URU5EX0JBU0VfVVJMIiwiUk9VVEVfUEFUSFMiLCJMT0dJTiIsInRpdGxlIiwiZGVzY3JpcHRpb24iLCJ3aXRoQW5vbnltb3VzIiwiTG9naW4iLCJoYW5kbGVTdWJtaXQiLCJyZWdpc3RlciIsImZvcm1FcnJvcnMiLCJpc0Vycm9yIiwiZXJyb3IiLCJpc0xvYWRpbmciLCJ1c2VMb2dpbiIsImFkZE5vdGlmaWNhdGlvbiIsInVzZU5vdGlmaWNhdGlvbiIsInVzZUVmZmVjdCIsInR5cGUiLCJOb3RpZmljYXRpb25UeXBlIiwiRVJST1IiLCJtZXNzYWdlIiwicmVxdWlyZWQiLCJ2YWxpZGF0ZSIsImVtYWlsIiwiaXNWYWxpZEVtYWlsIiwibWluTGVuZ3RoIiwidmFsdWUiLCJwYXNzd29yZCIsIlJFUVVFU1RfUEFTU1dPUkRfUkVTRVQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUEsTUFBTUEsR0FBRyxHQUFJLEdBQUVDLGdFQUFrQixHQUFFQywwREFBVyxDQUFDQyxLQUFNLEVBQXJEO0FBQ0EsTUFBTUMsS0FBSyxHQUFHLE9BQWQ7QUFDQSxNQUFNQyxXQUFXLEdBQUcsd0JBQXBCO0FBRWUsb0VBQUFDLHVFQUFhLENBQUNDLEtBQUQsQ0FBNUI7O0FBRUEsU0FBU0EsS0FBVCxHQUFpQjtBQUFBOztBQUFBOztBQUNmLFFBQU07QUFDSkMsZ0JBREk7QUFFSkMsWUFGSTtBQUdKQyxjQUhJO0FBSUpDLFdBSkk7QUFLSkMsU0FMSTtBQU1KQztBQU5JLE1BT0ZDLDREQUFRLEVBUFo7QUFTQSxRQUFNO0FBQUNDO0FBQUQsTUFBb0JDLDZFQUFlLEVBQXpDO0FBRUFDLDBEQUFTLENBQUMsTUFBTTtBQUNkLFFBQUlOLE9BQU8sSUFBSUMsS0FBZixFQUFzQjtBQUNwQkcscUJBQWUsQ0FBQztBQUNkRyxZQUFJLEVBQUVDLHNFQUFnQixDQUFDQyxLQURUO0FBRWRoQixhQUFLLEVBQUVRLEtBQUssQ0FBQ1MsT0FGQztBQUdkQSxlQUFPLEVBQUU7QUFISyxPQUFELENBQWY7QUFLRDtBQUNGLEdBUlEsRUFRTixDQUFDTixlQUFELEVBQWtCSCxLQUFsQixFQUF5QkQsT0FBekIsQ0FSTSxDQUFUO0FBVUEsc0JBQ0U7QUFBQSw0QkFDRSxxRUFBQyxnREFBRDtBQUNFLFdBQUssRUFBRVAsS0FEVDtBQUVFLGlCQUFXLEVBQUVDLFdBRmY7QUFHRSxlQUFTLEVBQUVMLEdBSGI7QUFJRSxlQUFTLEVBQUU7QUFDVEEsV0FEUztBQUVUSSxhQUZTO0FBR1RDO0FBSFM7QUFKYjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREYsZUFXRTtBQUFLLGVBQVMsRUFBQyxxQ0FBZjtBQUFBLDZCQUNFO0FBQUssaUJBQVMsRUFBQyxTQUFmO0FBQUEsK0JBQ0U7QUFBSyxtQkFBUyxFQUFDLFdBQWY7QUFBQSxpQ0FFRTtBQUFLLHFCQUFTLEVBQUMsNENBQWY7QUFBQSxtQ0FFRTtBQUFLLHVCQUFTLEVBQUMsa0RBQWY7QUFBQSxzQ0FDSTtBQUFLLHlCQUFTLEVBQUMsa0NBQWY7QUFBQSx1Q0FDQTtBQUFLLDJCQUFTLEVBQUMsYUFBZjtBQUFBLHlDQUNBO0FBQUssNkJBQVMsRUFBQywrQkFBZjtBQUFBLDRDQUNFO0FBQUssK0JBQVMsRUFBQyxvQ0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw0QkFERixlQUVFO0FBQU0sK0JBQVMsRUFBQyxvQ0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBREosZUFVRTtBQUFNLHlCQUFTLEVBQUMsV0FBaEI7QUFBNEIsd0JBQVEsRUFBRUcsWUFBdEM7QUFBb0QsMEJBQVUsTUFBOUQ7QUFBQSx3Q0FDRTtBQUFBLDBDQUNFLHFFQUFDLHVEQUFEO0FBQU8sMkJBQU8sRUFBQyxPQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQURGLGVBRUUscUVBQUMsdURBQUQ7QUFDRSx3QkFBSSxFQUFDLE9BRFA7QUFFRSxzQkFBRSxFQUFDLE9BRkw7QUFHRSx3QkFBSSxFQUFDLE9BSFA7QUFJRSwrQkFBVyxFQUFDLG1CQUpkO0FBS0UsdUJBQUcsRUFBRUMsUUFBUSxDQUFDO0FBQ1phLDhCQUFRLEVBQUUsb0JBREU7QUFFWkMsOEJBQVEsRUFBRUMsS0FBSyxJQUNiQyxrRUFBWSxDQUFDRCxLQUFELENBQVosSUFBdUI7QUFIYixxQkFBRCxDQUxmO0FBVUUseUJBQUssdUJBQUVkLFVBQVUsQ0FBQ2MsS0FBYixzREFBRSxrQkFBa0JILE9BVjNCO0FBV0Usd0JBQUksZUFBRSxxRUFBQyxpRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBWFI7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBREYsZUFrQkU7QUFBQSwwQ0FDRSxxRUFBQyx1REFBRDtBQUFPLDJCQUFPLEVBQUMsVUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFERixlQUVFLHFFQUFDLHVEQUFEO0FBQ0Usd0JBQUksRUFBQyxVQURQO0FBRUUsc0JBQUUsRUFBQyxVQUZMO0FBR0Usd0JBQUksRUFBQyxVQUhQO0FBSUUsK0JBQVcsRUFBQyxVQUpkO0FBS0UsdUJBQUcsRUFBRVosUUFBUSxDQUFDO0FBQ1phLDhCQUFRLEVBQUUsdUJBREU7QUFFWkksK0JBQVMsRUFBRTtBQUNUQyw2QkFBSyxFQUFFLENBREU7QUFFVE4sK0JBQU8sRUFBRTtBQUZBO0FBRkMscUJBQUQsQ0FMZjtBQVlFLHlCQUFLLDBCQUFFWCxVQUFVLENBQUNrQixRQUFiLHlEQUFFLHFCQUFxQlAsT0FaOUI7QUFhRSx3QkFBSSxlQUFFLHFFQUFDLGdFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFiUjtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFsQkYsZUFvQ0U7QUFBSywyQkFBUyxFQUFDLHNEQUFmO0FBQUEsMENBQ0U7QUFBSyw2QkFBUyxFQUFDO0FBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFERixlQUlFO0FBQUcsNkJBQVMsRUFBQyx1RUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBcENGLGVBMENFLHFFQUFDLHVEQUFEO0FBQU0sMkJBQVMsRUFBQyw4QkFBaEI7QUFBQSx5Q0FRRSxxRUFBQyw4REFBRDtBQUNFLHdCQUFJLEVBQUVuQiwwREFBVyxDQUFDMkIsc0JBRHBCO0FBRUUsNkJBQVMsRUFBQywyREFGWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBMUNGLGVBMERFO0FBQUEseUNBQ0UscUVBQUMsd0RBQUQ7QUFBUSx3QkFBSSxFQUFDLFFBQWI7QUFBc0IsNEJBQVEsRUFBRSxDQUFDLENBQUNoQixTQUFsQztBQUE2QywrQkFBVyxNQUF4RDtBQUFBLDBDQUNVQSxTQUFTLGlCQUFJLHFFQUFDLHlFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEJBRHZCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBMURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFWRixlQTBFRTtBQUFLLHlCQUFTLEVBQUMsa0JBQWY7QUFBQSx3Q0FDSjtBQUFNLDJCQUFTLEVBQUMsb0NBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQURJLGVBRUo7QUFBRywyQkFBUyxFQUFDLDREQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUZJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkExRUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVhGO0FBQUEsa0JBREY7QUF5R0Q7O0dBL0hRTixLO1VBUUhPLG9ELEVBRXNCRSxxRTs7O01BVm5CVCxLIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL2F1dGgvbG9naW4uNWQyN2RmNjM3MGRhNzU4MDQ5NDMuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7QnV0dG9uLCBJbnB1dCwgTGFiZWx9IGZyb20gJ0Bjb21wb25lbnRzL2Zvcm1zJztcbmltcG9ydCB7SGVhZGluZ30gZnJvbSAnQGNvbXBvbmVudHMvaGVhZGluZy9oZWFkaW5nJztcbmltcG9ydCB7RW1haWxJY29uLCBMb2NrSWNvbn0gZnJvbSAnQGNvbXBvbmVudHMvaWNvbnMvaWNvbnMnO1xuaW1wb3J0IHtGbGV4fSBmcm9tICdAY29tcG9uZW50cy9sYXlvdXQnO1xuaW1wb3J0IHtMb2FkaW5nSW5saW5lfSBmcm9tICdAY29tcG9uZW50cy9sb2FkaW5nLXNwaW5uZXInO1xuaW1wb3J0IHtOZXh0TGlua30gZnJvbSAnQGNvbXBvbmVudHMvbmV4dC1saW5rJztcbmltcG9ydCB7Tm90aWZpY2F0aW9uVHlwZSwgdXNlTm90aWZpY2F0aW9ufSBmcm9tICdAY29udGV4dC9ub3RpZmljYXRpb24nO1xuaW1wb3J0IHtpc1ZhbGlkRW1haWx9IGZyb20gJ0BzaGFyZWQvaW5kZXgnO1xuaW1wb3J0IHt3aXRoQW5vbnltb3VzfSBmcm9tICdAdXRpbHMvcm91dGUtaG9jcyc7XG5pbXBvcnQge05leHRTZW99IGZyb20gJ25leHQtc2VvJztcbmltcG9ydCB7dXNlRWZmZWN0fSBmcm9tICdyZWFjdCc7XG5pbXBvcnQge0ZST05URU5EX0JBU0VfVVJMLCBJTUFHRV9QQVRIUywgUk9VVEVfUEFUSFN9IGZyb20gJ3NyYy9jb25zdGFudHMnO1xuaW1wb3J0IHt1c2VMb2dpbn0gZnJvbSAnLi91c2UtbG9naW4nO1xuXG5jb25zdCB1cmwgPSBgJHtGUk9OVEVORF9CQVNFX1VSTH0ke1JPVVRFX1BBVEhTLkxPR0lOfWA7XG5jb25zdCB0aXRsZSA9ICdMb2dpbic7XG5jb25zdCBkZXNjcmlwdGlvbiA9ICdTaWduIGludG8geW91ciBhY2NvdW50JztcblxuZXhwb3J0IGRlZmF1bHQgd2l0aEFub255bW91cyhMb2dpbik7XG5cbmZ1bmN0aW9uIExvZ2luKCkge1xuICBjb25zdCB7XG4gICAgaGFuZGxlU3VibWl0LFxuICAgIHJlZ2lzdGVyLFxuICAgIGZvcm1FcnJvcnMsXG4gICAgaXNFcnJvcixcbiAgICBlcnJvcixcbiAgICBpc0xvYWRpbmcsXG4gIH0gPSB1c2VMb2dpbigpO1xuXG4gIGNvbnN0IHthZGROb3RpZmljYXRpb259ID0gdXNlTm90aWZpY2F0aW9uKCk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoaXNFcnJvciAmJiBlcnJvcikge1xuICAgICAgYWRkTm90aWZpY2F0aW9uKHtcbiAgICAgICAgdHlwZTogTm90aWZpY2F0aW9uVHlwZS5FUlJPUixcbiAgICAgICAgdGl0bGU6IGVycm9yLm1lc3NhZ2UsXG4gICAgICAgIG1lc3NhZ2U6ICdZb3VyIHJlcXVlc3QgaGFzIGZhaWxlZC4nLFxuICAgICAgfSk7XG4gICAgfVxuICB9LCBbYWRkTm90aWZpY2F0aW9uLCBlcnJvciwgaXNFcnJvcl0pO1xuXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDxOZXh0U2VvXG4gICAgICAgIHRpdGxlPXt0aXRsZX1cbiAgICAgICAgZGVzY3JpcHRpb249e2Rlc2NyaXB0aW9ufVxuICAgICAgICBjYW5vbmljYWw9e3VybH1cbiAgICAgICAgb3BlbkdyYXBoPXt7XG4gICAgICAgICAgdXJsLFxuICAgICAgICAgIHRpdGxlLFxuICAgICAgICAgIGRlc2NyaXB0aW9uLFxuICAgICAgICB9fVxuICAgICAgLz5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBtdC0xMiBzbTpweC02IGxnOnB4LThcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZzpmbGV4XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZzpmbGV4LTFcIj5cbiAgICAgICAgICAgXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTggc206bXgtYXV0byBzbTp3LWZ1bGwgc206bWF4LXctbWQgdGVzdFwiID5cbiAgICAgICAgICBcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC00IHB5LTggYmctd2hpdGUgc2hhZG93IHNtOnJvdW5kZWQtbGcgc206cHgtMTBcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206bXgtYXV0byBzbTp3LWZ1bGwgc206bWF4LXctbWRcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgbWItNSBjdXN0b21oZWFkZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LTkwMCB0ZXh0LTN4bCBmb250LW1lZGl1bSBtYi0zXCI+V2VsY29tZSBCYWNrITwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTYwMCBmb250LW1lZGl1bSBsaW5lLWhlaWdodC0zXCI+QWNjZXNzIHRoZSBmb2xsb3dpbmcgUGlsbGFyIGxpZmUgcGVyc29uYWwgYWNjb3VudHM6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cInNwYWNlLXktNFwiIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IG5vVmFsaWRhdGU+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8TGFiZWwgaHRtbEZvcj1cImVtYWlsXCI+RW1haWw8L0xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIlxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwiZW1haWxcIlxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJlbWFpbFwiXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlbWFpbEBhZGRyZXNzLmNvbVwiXG4gICAgICAgICAgICAgICAgICAgICAgcmVmPXtyZWdpc3Rlcih7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZDogJ0VtYWlsIGlzIHJlcXVpcmVkLicsXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0ZTogZW1haWwgPT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgaXNWYWxpZEVtYWlsKGVtYWlsKSB8fCAnRW1haWwgYWRkcmVzcyBpcyBpbnZhbGlkLicsXG4gICAgICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgZXJyb3I9e2Zvcm1FcnJvcnMuZW1haWw/Lm1lc3NhZ2V9XG4gICAgICAgICAgICAgICAgICAgICAgaWNvbj17PEVtYWlsSWNvbiAvPn1cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8TGFiZWwgaHRtbEZvcj1cInBhc3N3b3JkXCI+UGFzc3dvcmQ8L0xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwYXNzd29yZFwiXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJQYXNzd29yZFwiXG4gICAgICAgICAgICAgICAgICAgICAgcmVmPXtyZWdpc3Rlcih7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZDogJ1Bhc3N3b3JkIGlzIHJlcXVpcmVkLicsXG4gICAgICAgICAgICAgICAgICAgICAgICBtaW5MZW5ndGg6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IDYsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6ICdQYXNzd29yZCBtdXN0IGJlIGF0IGxlYXN0IDYgY2hhcmFjdGVycy4nLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICAgICAgICBlcnJvcj17Zm9ybUVycm9ycy5wYXNzd29yZD8ubWVzc2FnZX1cbiAgICAgICAgICAgICAgICAgICAgICBpY29uPXs8TG9ja0ljb24gLz59XG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBhbGlnbi1pdGVtcy1jZW50ZXIganVzdGlmeS1jb250ZW50LWJldHdlZW4gbWItM1wiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggYWxpZ24taXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgey8qIDxsYWJlbCBodG1sRm9yPVwicmVtZW1iZXJtZVwiPlJlbWVtYmVyIG1lPC9sYWJlbD4gKi99XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8YSBjbGFzc05hbWU9XCJmb250LW1lZGl1bSBuby11bmRlcmxpbmUgbWwtMiB0ZXh0LWJsdWUtNTAwIHRleHQtcmlnaHQgY3Vyc29yLXBvaW50ZXJcIj5Gb3Jnb3QgeW91ciBwYXNzd29yZD88L2E+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8RmxleCBjbGFzc05hbWU9XCJpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgIHsvKiA8TmV4dExpbmtcbiAgICAgICAgICAgICAgICAgICAgICBocmVmPXtST1VURV9QQVRIUy5SRUdJU1RFUn1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtaW5kaWdvLTYwMCBob3Zlcjp0ZXh0LWluZGlnby01MDBcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgRG8gbm90IGhhdmUgYW4gYWNjb3VudD9cbiAgICAgICAgICAgICAgICAgICAgPC9OZXh0TGluaz4gKi99XG5cbiAgICAgICAgICAgICAgICAgICAgPE5leHRMaW5rXG4gICAgICAgICAgICAgICAgICAgICAgaHJlZj17Uk9VVEVfUEFUSFMuUkVRVUVTVF9QQVNTV09SRF9SRVNFVH1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtaW5kaWdvLTYwMCBob3Zlcjp0ZXh0LWluZGlnby01MDBcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgRm9yZ290IHBhc3N3b3JkP1xuICAgICAgICAgICAgICAgICAgICA8L05leHRMaW5rPlxuICAgICAgICAgICAgICAgICAgPC9GbGV4PlxuXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBkaXNhYmxlZD17ISFpc0xvYWRpbmd9IGlzRnVsbFdpZHRoPlxuICAgICAgICAgICAgICAgICAgICAgIExvZyBJbiB7aXNMb2FkaW5nICYmIDxMb2FkaW5nSW5saW5lIC8+fVxuICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIG1iLTVcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtNjAwIGZvbnQtbWVkaXVtIGxpbmUtaGVpZ2h0LTNcIj5Ob3QgYSBtZW1iZXI/IDwvc3Bhbj5cbiAgICAgICAgICAgIDxhIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIG5vLXVuZGVybGluZSBtbC0yIHRleHQtYmx1ZS01MDAgY3Vyc29yLXBvaW50ZXJcIj5DcmVhdGUgYW4gYWNjb3VudCBub3c8L2E+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgXG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC8+XG4gICk7XG59XG4iXSwic291cmNlUm9vdCI6IiJ9