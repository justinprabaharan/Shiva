webpackHotUpdate_N_E("pages/auth/login",{

/***/ "./src/pages/auth/login/login.tsx":
/*!****************************************!*\
  !*** ./src/pages/auth/login/login.tsx ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @components/forms */ "./src/components/forms/index.ts");
/* harmony import */ var _components_icons_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @components/icons/icons */ "./src/components/icons/icons.tsx");
/* harmony import */ var _components_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @components/layout */ "./src/components/layout/index.ts");
/* harmony import */ var _components_loading_spinner__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @components/loading-spinner */ "./src/components/loading-spinner/index.ts");
/* harmony import */ var _components_next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @components/next-link */ "./src/components/next-link/index.ts");
/* harmony import */ var _context_notification__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @context/notification */ "./src/context/notification/index.ts");
/* harmony import */ var _shared_index__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @shared/index */ "./shared/index.ts");
/* harmony import */ var _utils_route_hocs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @utils/route-hocs */ "./src/utils/route-hocs.tsx");
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! next-seo */ "./node_modules/next-seo/lib/next-seo.module.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var src_constants__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/constants */ "./src/constants.ts");
/* harmony import */ var _use_login__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./use-login */ "./src/pages/auth/login/use-login.js");



var _jsxFileName = "J:\\Project\\reference\\aws-amplify-react-auth-master-toshare\\aws-amplify-react-auth-master-toshare\\src\\pages\\auth\\login\\login.tsx",
    _s = $RefreshSig$();













const url = `${src_constants__WEBPACK_IMPORTED_MODULE_11__["FRONTEND_BASE_URL"]}${src_constants__WEBPACK_IMPORTED_MODULE_11__["ROUTE_PATHS"].LOGIN}`;
const title = 'Login';
const description = 'Sign into your account';
/* harmony default export */ __webpack_exports__["default"] = (_c = Object(_utils_route_hocs__WEBPACK_IMPORTED_MODULE_8__["withAnonymous"])(Login));

function Login() {
  _s();

  var _formErrors$email, _formErrors$password;

  const {
    handleSubmit,
    register,
    formErrors,
    isError,
    error,
    isLoading
  } = Object(_use_login__WEBPACK_IMPORTED_MODULE_12__["useLogin"])();
  const {
    addNotification
  } = Object(_context_notification__WEBPACK_IMPORTED_MODULE_6__["useNotification"])();
  Object(react__WEBPACK_IMPORTED_MODULE_10__["useEffect"])(() => {
    if (isError && error) {
      addNotification({
        type: _context_notification__WEBPACK_IMPORTED_MODULE_6__["NotificationType"].ERROR,
        title: error.message,
        message: 'Your request has failed.'
      });
    }
  }, [addNotification, error, isError]);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_seo__WEBPACK_IMPORTED_MODULE_9__["NextSeo"], {
      title: title,
      description: description,
      canonical: url,
      openGraph: {
        url,
        title,
        description
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 45,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "flex flex-col mt-12 sm:px-6 lg:px-8",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "lg:flex",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "lg:flex-1",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "mt-8 sm:mx-auto sm:w-full sm:max-w-md test",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "px-4 py-8 bg-white shadow sm:rounded-lg sm:px-10",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "sm:mx-auto sm:w-full sm:max-w-md",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "text-center",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "text-center mb-5 customheader",
                    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "text-900 text-3xl font-medium mb-3",
                      children: "Welcome Back!"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 65,
                      columnNumber: 21
                    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                      className: "text-600 font-medium line-height-3",
                      children: "Access the following Pillar life personal accounts:"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 66,
                      columnNumber: 21
                    }, this)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 64,
                    columnNumber: 19
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 63,
                  columnNumber: 19
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 62,
                columnNumber: 19
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("form", {
                className: "space-y-4",
                onSubmit: handleSubmit,
                noValidate: true,
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_forms__WEBPACK_IMPORTED_MODULE_1__["Label"], {
                    htmlFor: "email",
                    children: "Email"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 73,
                    columnNumber: 21
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_forms__WEBPACK_IMPORTED_MODULE_1__["Input"], {
                    type: "email",
                    id: "email",
                    name: "email",
                    placeholder: "email@address.com",
                    ref: register({
                      required: 'Email is required.',
                      validate: email => Object(_shared_index__WEBPACK_IMPORTED_MODULE_7__["isValidEmail"])(email) || 'Email address is invalid.'
                    }),
                    error: (_formErrors$email = formErrors.email) === null || _formErrors$email === void 0 ? void 0 : _formErrors$email.message,
                    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_icons_icons__WEBPACK_IMPORTED_MODULE_2__["EmailIcon"], {}, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 85,
                      columnNumber: 29
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 74,
                    columnNumber: 21
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 72,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_forms__WEBPACK_IMPORTED_MODULE_1__["Label"], {
                    htmlFor: "password",
                    children: "Password"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 90,
                    columnNumber: 21
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_forms__WEBPACK_IMPORTED_MODULE_1__["Input"], {
                    type: "password",
                    id: "password",
                    name: "password",
                    placeholder: "Password",
                    ref: register({
                      required: 'Password is required.',
                      minLength: {
                        value: 6,
                        message: 'Password must be at least 6 characters.'
                      }
                    }),
                    error: (_formErrors$password = formErrors.password) === null || _formErrors$password === void 0 ? void 0 : _formErrors$password.message,
                    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_icons_icons__WEBPACK_IMPORTED_MODULE_2__["LockIcon"], {}, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 104,
                      columnNumber: 29
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 91,
                    columnNumber: 21
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 89,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_layout__WEBPACK_IMPORTED_MODULE_3__["Flex"], {
                  className: "items-center justify-between",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_next_link__WEBPACK_IMPORTED_MODULE_5__["NextLink"], {
                    href: src_constants__WEBPACK_IMPORTED_MODULE_11__["ROUTE_PATHS"].REGISTER,
                    className: "text-sm font-medium text-indigo-600 hover:text-indigo-500",
                    children: "Do not have an account?"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 109,
                    columnNumber: 21
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_next_link__WEBPACK_IMPORTED_MODULE_5__["NextLink"], {
                    href: src_constants__WEBPACK_IMPORTED_MODULE_11__["ROUTE_PATHS"].REQUEST_PASSWORD_RESET,
                    className: "text-sm font-medium text-indigo-600 hover:text-indigo-500",
                    children: "Forgot your password?"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 116,
                    columnNumber: 21
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 108,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_forms__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                    type: "submit",
                    disabled: !!isLoading,
                    isFullWidth: true,
                    children: ["Log In ", isLoading && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_loading_spinner__WEBPACK_IMPORTED_MODULE_4__["LoadingInline"], {}, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 126,
                      columnNumber: 44
                    }, this)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 125,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 124,
                  columnNumber: 19
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 71,
                columnNumber: 17
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 61,
              columnNumber: 15
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 59,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 57,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 56,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 55,
      columnNumber: 7
    }, this)]
  }, void 0, true);
}

_s(Login, "UE7oUpBS961EQsNUlHtP3xXg1O8=", false, function () {
  return [_use_login__WEBPACK_IMPORTED_MODULE_12__["useLogin"], _context_notification__WEBPACK_IMPORTED_MODULE_6__["useNotification"]];
});

_c2 = Login;

var _c, _c2;

$RefreshReg$(_c, "%default%");
$RefreshReg$(_c2, "Login");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL3BhZ2VzL2F1dGgvbG9naW4vbG9naW4udHN4Il0sIm5hbWVzIjpbInVybCIsIkZST05URU5EX0JBU0VfVVJMIiwiUk9VVEVfUEFUSFMiLCJMT0dJTiIsInRpdGxlIiwiZGVzY3JpcHRpb24iLCJ3aXRoQW5vbnltb3VzIiwiTG9naW4iLCJoYW5kbGVTdWJtaXQiLCJyZWdpc3RlciIsImZvcm1FcnJvcnMiLCJpc0Vycm9yIiwiZXJyb3IiLCJpc0xvYWRpbmciLCJ1c2VMb2dpbiIsImFkZE5vdGlmaWNhdGlvbiIsInVzZU5vdGlmaWNhdGlvbiIsInVzZUVmZmVjdCIsInR5cGUiLCJOb3RpZmljYXRpb25UeXBlIiwiRVJST1IiLCJtZXNzYWdlIiwicmVxdWlyZWQiLCJ2YWxpZGF0ZSIsImVtYWlsIiwiaXNWYWxpZEVtYWlsIiwibWluTGVuZ3RoIiwidmFsdWUiLCJwYXNzd29yZCIsIlJFR0lTVEVSIiwiUkVRVUVTVF9QQVNTV09SRF9SRVNFVCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQSxNQUFNQSxHQUFHLEdBQUksR0FBRUMsZ0VBQWtCLEdBQUVDLDBEQUFXLENBQUNDLEtBQU0sRUFBckQ7QUFDQSxNQUFNQyxLQUFLLEdBQUcsT0FBZDtBQUNBLE1BQU1DLFdBQVcsR0FBRyx3QkFBcEI7QUFFZSxvRUFBQUMsdUVBQWEsQ0FBQ0MsS0FBRCxDQUE1Qjs7QUFFQSxTQUFTQSxLQUFULEdBQWlCO0FBQUE7O0FBQUE7O0FBQ2YsUUFBTTtBQUNKQyxnQkFESTtBQUVKQyxZQUZJO0FBR0pDLGNBSEk7QUFJSkMsV0FKSTtBQUtKQyxTQUxJO0FBTUpDO0FBTkksTUFPRkMsNERBQVEsRUFQWjtBQVNBLFFBQU07QUFBQ0M7QUFBRCxNQUFvQkMsNkVBQWUsRUFBekM7QUFFQUMsMERBQVMsQ0FBQyxNQUFNO0FBQ2QsUUFBSU4sT0FBTyxJQUFJQyxLQUFmLEVBQXNCO0FBQ3BCRyxxQkFBZSxDQUFDO0FBQ2RHLFlBQUksRUFBRUMsc0VBQWdCLENBQUNDLEtBRFQ7QUFFZGhCLGFBQUssRUFBRVEsS0FBSyxDQUFDUyxPQUZDO0FBR2RBLGVBQU8sRUFBRTtBQUhLLE9BQUQsQ0FBZjtBQUtEO0FBQ0YsR0FSUSxFQVFOLENBQUNOLGVBQUQsRUFBa0JILEtBQWxCLEVBQXlCRCxPQUF6QixDQVJNLENBQVQ7QUFVQSxzQkFDRTtBQUFBLDRCQUNFLHFFQUFDLGdEQUFEO0FBQ0UsV0FBSyxFQUFFUCxLQURUO0FBRUUsaUJBQVcsRUFBRUMsV0FGZjtBQUdFLGVBQVMsRUFBRUwsR0FIYjtBQUlFLGVBQVMsRUFBRTtBQUNUQSxXQURTO0FBRVRJLGFBRlM7QUFHVEM7QUFIUztBQUpiO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERixlQVdFO0FBQUssZUFBUyxFQUFDLHFDQUFmO0FBQUEsNkJBQ0U7QUFBSyxpQkFBUyxFQUFDLFNBQWY7QUFBQSwrQkFDRTtBQUFLLG1CQUFTLEVBQUMsV0FBZjtBQUFBLGlDQUVFO0FBQUsscUJBQVMsRUFBQyw0Q0FBZjtBQUFBLG1DQUVFO0FBQUssdUJBQVMsRUFBQyxrREFBZjtBQUFBLHNDQUNJO0FBQUsseUJBQVMsRUFBQyxrQ0FBZjtBQUFBLHVDQUNBO0FBQUssMkJBQVMsRUFBQyxhQUFmO0FBQUEseUNBQ0E7QUFBSyw2QkFBUyxFQUFDLCtCQUFmO0FBQUEsNENBQ0U7QUFBSywrQkFBUyxFQUFDLG9DQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQURGLGVBRUU7QUFBTSwrQkFBUyxFQUFDLG9DQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw0QkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFEQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFESixlQVVFO0FBQU0seUJBQVMsRUFBQyxXQUFoQjtBQUE0Qix3QkFBUSxFQUFFRyxZQUF0QztBQUFvRCwwQkFBVSxNQUE5RDtBQUFBLHdDQUNFO0FBQUEsMENBQ0UscUVBQUMsdURBQUQ7QUFBTywyQkFBTyxFQUFDLE9BQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBREYsZUFFRSxxRUFBQyx1REFBRDtBQUNFLHdCQUFJLEVBQUMsT0FEUDtBQUVFLHNCQUFFLEVBQUMsT0FGTDtBQUdFLHdCQUFJLEVBQUMsT0FIUDtBQUlFLCtCQUFXLEVBQUMsbUJBSmQ7QUFLRSx1QkFBRyxFQUFFQyxRQUFRLENBQUM7QUFDWmEsOEJBQVEsRUFBRSxvQkFERTtBQUVaQyw4QkFBUSxFQUFFQyxLQUFLLElBQ2JDLGtFQUFZLENBQUNELEtBQUQsQ0FBWixJQUF1QjtBQUhiLHFCQUFELENBTGY7QUFVRSx5QkFBSyx1QkFBRWQsVUFBVSxDQUFDYyxLQUFiLHNEQUFFLGtCQUFrQkgsT0FWM0I7QUFXRSx3QkFBSSxlQUFFLHFFQUFDLGlFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFYUjtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFERixlQWtCRTtBQUFBLDBDQUNFLHFFQUFDLHVEQUFEO0FBQU8sMkJBQU8sRUFBQyxVQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQURGLGVBRUUscUVBQUMsdURBQUQ7QUFDRSx3QkFBSSxFQUFDLFVBRFA7QUFFRSxzQkFBRSxFQUFDLFVBRkw7QUFHRSx3QkFBSSxFQUFDLFVBSFA7QUFJRSwrQkFBVyxFQUFDLFVBSmQ7QUFLRSx1QkFBRyxFQUFFWixRQUFRLENBQUM7QUFDWmEsOEJBQVEsRUFBRSx1QkFERTtBQUVaSSwrQkFBUyxFQUFFO0FBQ1RDLDZCQUFLLEVBQUUsQ0FERTtBQUVUTiwrQkFBTyxFQUFFO0FBRkE7QUFGQyxxQkFBRCxDQUxmO0FBWUUseUJBQUssMEJBQUVYLFVBQVUsQ0FBQ2tCLFFBQWIseURBQUUscUJBQXFCUCxPQVo5QjtBQWFFLHdCQUFJLGVBQUUscUVBQUMsZ0VBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQWJSO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQWxCRixlQXFDRSxxRUFBQyx1REFBRDtBQUFNLDJCQUFTLEVBQUMsOEJBQWhCO0FBQUEsMENBQ0UscUVBQUMsOERBQUQ7QUFDRSx3QkFBSSxFQUFFbkIsMERBQVcsQ0FBQzJCLFFBRHBCO0FBRUUsNkJBQVMsRUFBQywyREFGWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFERixlQVFFLHFFQUFDLDhEQUFEO0FBQ0Usd0JBQUksRUFBRTNCLDBEQUFXLENBQUM0QixzQkFEcEI7QUFFRSw2QkFBUyxFQUFDLDJEQUZaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFyQ0YsZUFxREU7QUFBQSx5Q0FDRSxxRUFBQyx3REFBRDtBQUFRLHdCQUFJLEVBQUMsUUFBYjtBQUFzQiw0QkFBUSxFQUFFLENBQUMsQ0FBQ2pCLFNBQWxDO0FBQTZDLCtCQUFXLE1BQXhEO0FBQUEsMENBQ1VBLFNBQVMsaUJBQUkscUVBQUMseUVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw0QkFEdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFyREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFYRjtBQUFBLGtCQURGO0FBZ0dEOztHQXRIUU4sSztVQVFITyxvRCxFQUVzQkUscUU7OztNQVZuQlQsSyIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9hdXRoL2xvZ2luLjUzZjU3ODgzMTM2OWFjYjBmYzI3LmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge0J1dHRvbiwgSW5wdXQsIExhYmVsfSBmcm9tICdAY29tcG9uZW50cy9mb3Jtcyc7XG5pbXBvcnQge0hlYWRpbmd9IGZyb20gJ0Bjb21wb25lbnRzL2hlYWRpbmcvaGVhZGluZyc7XG5pbXBvcnQge0VtYWlsSWNvbiwgTG9ja0ljb259IGZyb20gJ0Bjb21wb25lbnRzL2ljb25zL2ljb25zJztcbmltcG9ydCB7RmxleH0gZnJvbSAnQGNvbXBvbmVudHMvbGF5b3V0JztcbmltcG9ydCB7TG9hZGluZ0lubGluZX0gZnJvbSAnQGNvbXBvbmVudHMvbG9hZGluZy1zcGlubmVyJztcbmltcG9ydCB7TmV4dExpbmt9IGZyb20gJ0Bjb21wb25lbnRzL25leHQtbGluayc7XG5pbXBvcnQge05vdGlmaWNhdGlvblR5cGUsIHVzZU5vdGlmaWNhdGlvbn0gZnJvbSAnQGNvbnRleHQvbm90aWZpY2F0aW9uJztcbmltcG9ydCB7aXNWYWxpZEVtYWlsfSBmcm9tICdAc2hhcmVkL2luZGV4JztcbmltcG9ydCB7d2l0aEFub255bW91c30gZnJvbSAnQHV0aWxzL3JvdXRlLWhvY3MnO1xuaW1wb3J0IHtOZXh0U2VvfSBmcm9tICduZXh0LXNlbyc7XG5pbXBvcnQge3VzZUVmZmVjdH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHtGUk9OVEVORF9CQVNFX1VSTCwgSU1BR0VfUEFUSFMsIFJPVVRFX1BBVEhTfSBmcm9tICdzcmMvY29uc3RhbnRzJztcbmltcG9ydCB7dXNlTG9naW59IGZyb20gJy4vdXNlLWxvZ2luJztcblxuY29uc3QgdXJsID0gYCR7RlJPTlRFTkRfQkFTRV9VUkx9JHtST1VURV9QQVRIUy5MT0dJTn1gO1xuY29uc3QgdGl0bGUgPSAnTG9naW4nO1xuY29uc3QgZGVzY3JpcHRpb24gPSAnU2lnbiBpbnRvIHlvdXIgYWNjb3VudCc7XG5cbmV4cG9ydCBkZWZhdWx0IHdpdGhBbm9ueW1vdXMoTG9naW4pO1xuXG5mdW5jdGlvbiBMb2dpbigpIHtcbiAgY29uc3Qge1xuICAgIGhhbmRsZVN1Ym1pdCxcbiAgICByZWdpc3RlcixcbiAgICBmb3JtRXJyb3JzLFxuICAgIGlzRXJyb3IsXG4gICAgZXJyb3IsXG4gICAgaXNMb2FkaW5nLFxuICB9ID0gdXNlTG9naW4oKTtcblxuICBjb25zdCB7YWRkTm90aWZpY2F0aW9ufSA9IHVzZU5vdGlmaWNhdGlvbigpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGlzRXJyb3IgJiYgZXJyb3IpIHtcbiAgICAgIGFkZE5vdGlmaWNhdGlvbih7XG4gICAgICAgIHR5cGU6IE5vdGlmaWNhdGlvblR5cGUuRVJST1IsXG4gICAgICAgIHRpdGxlOiBlcnJvci5tZXNzYWdlLFxuICAgICAgICBtZXNzYWdlOiAnWW91ciByZXF1ZXN0IGhhcyBmYWlsZWQuJyxcbiAgICAgIH0pO1xuICAgIH1cbiAgfSwgW2FkZE5vdGlmaWNhdGlvbiwgZXJyb3IsIGlzRXJyb3JdKTtcblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8TmV4dFNlb1xuICAgICAgICB0aXRsZT17dGl0bGV9XG4gICAgICAgIGRlc2NyaXB0aW9uPXtkZXNjcmlwdGlvbn1cbiAgICAgICAgY2Fub25pY2FsPXt1cmx9XG4gICAgICAgIG9wZW5HcmFwaD17e1xuICAgICAgICAgIHVybCxcbiAgICAgICAgICB0aXRsZSxcbiAgICAgICAgICBkZXNjcmlwdGlvbixcbiAgICAgICAgfX1cbiAgICAgIC8+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgbXQtMTIgc206cHgtNiBsZzpweC04XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGc6ZmxleFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGc6ZmxleC0xXCI+XG4gICAgICAgICAgIFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC04IHNtOm14LWF1dG8gc206dy1mdWxsIHNtOm1heC13LW1kIHRlc3RcIiA+XG4gICAgICAgICAgXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNCBweS04IGJnLXdoaXRlIHNoYWRvdyBzbTpyb3VuZGVkLWxnIHNtOnB4LTEwXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOm14LWF1dG8gc206dy1mdWxsIHNtOm1heC13LW1kXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIG1iLTUgY3VzdG9taGVhZGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC05MDAgdGV4dC0zeGwgZm9udC1tZWRpdW0gbWItM1wiPldlbGNvbWUgQmFjayE8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC02MDAgZm9udC1tZWRpdW0gbGluZS1oZWlnaHQtM1wiPkFjY2VzcyB0aGUgZm9sbG93aW5nIFBpbGxhciBsaWZlIHBlcnNvbmFsIGFjY291bnRzOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJzcGFjZS15LTRcIiBvblN1Ym1pdD17aGFuZGxlU3VibWl0fSBub1ZhbGlkYXRlPlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPExhYmVsIGh0bWxGb3I9XCJlbWFpbFwiPkVtYWlsPC9MYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImVtYWlsXCJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cImVtYWlsXCJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZW1haWxcIlxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZW1haWxAYWRkcmVzcy5jb21cIlxuICAgICAgICAgICAgICAgICAgICAgIHJlZj17cmVnaXN0ZXIoe1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWQ6ICdFbWFpbCBpcyByZXF1aXJlZC4nLFxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdGU6IGVtYWlsID0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlzVmFsaWRFbWFpbChlbWFpbCkgfHwgJ0VtYWlsIGFkZHJlc3MgaXMgaW52YWxpZC4nLFxuICAgICAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgICAgICAgIGVycm9yPXtmb3JtRXJyb3JzLmVtYWlsPy5tZXNzYWdlfVxuICAgICAgICAgICAgICAgICAgICAgIGljb249ezxFbWFpbEljb24gLz59XG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPExhYmVsIGh0bWxGb3I9XCJwYXNzd29yZFwiPlBhc3N3b3JkPC9MYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiUGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgICAgIHJlZj17cmVnaXN0ZXIoe1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWQ6ICdQYXNzd29yZCBpcyByZXF1aXJlZC4nLFxuICAgICAgICAgICAgICAgICAgICAgICAgbWluTGVuZ3RoOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlOiA2LFxuICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiAnUGFzc3dvcmQgbXVzdCBiZSBhdCBsZWFzdCA2IGNoYXJhY3RlcnMuJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgZXJyb3I9e2Zvcm1FcnJvcnMucGFzc3dvcmQ/Lm1lc3NhZ2V9XG4gICAgICAgICAgICAgICAgICAgICAgaWNvbj17PExvY2tJY29uIC8+fVxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIDxGbGV4IGNsYXNzTmFtZT1cIml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgPE5leHRMaW5rXG4gICAgICAgICAgICAgICAgICAgICAgaHJlZj17Uk9VVEVfUEFUSFMuUkVHSVNURVJ9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWluZGlnby02MDAgaG92ZXI6dGV4dC1pbmRpZ28tNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIERvIG5vdCBoYXZlIGFuIGFjY291bnQ/XG4gICAgICAgICAgICAgICAgICAgIDwvTmV4dExpbms+XG5cbiAgICAgICAgICAgICAgICAgICAgPE5leHRMaW5rXG4gICAgICAgICAgICAgICAgICAgICAgaHJlZj17Uk9VVEVfUEFUSFMuUkVRVUVTVF9QQVNTV09SRF9SRVNFVH1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtaW5kaWdvLTYwMCBob3Zlcjp0ZXh0LWluZGlnby01MDBcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgRm9yZ290IHlvdXIgcGFzc3dvcmQ/XG4gICAgICAgICAgICAgICAgICAgIDwvTmV4dExpbms+XG4gICAgICAgICAgICAgICAgICA8L0ZsZXg+XG5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxCdXR0b24gdHlwZT1cInN1Ym1pdFwiIGRpc2FibGVkPXshIWlzTG9hZGluZ30gaXNGdWxsV2lkdGg+XG4gICAgICAgICAgICAgICAgICAgICAgTG9nIEluIHtpc0xvYWRpbmcgJiYgPExvYWRpbmdJbmxpbmUgLz59XG4gICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9mb3JtPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgXG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC8+XG4gICk7XG59XG4iXSwic291cmNlUm9vdCI6IiJ9