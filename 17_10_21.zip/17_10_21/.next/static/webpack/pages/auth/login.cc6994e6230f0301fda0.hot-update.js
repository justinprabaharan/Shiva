webpackHotUpdate_N_E("pages/auth/login",{

/***/ "./src/pages/auth/login/login.tsx":
/*!****************************************!*\
  !*** ./src/pages/auth/login/login.tsx ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @components/forms */ "./src/components/forms/index.ts");
/* harmony import */ var _components_icons_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @components/icons/icons */ "./src/components/icons/icons.tsx");
/* harmony import */ var _components_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @components/layout */ "./src/components/layout/index.ts");
/* harmony import */ var _components_loading_spinner__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @components/loading-spinner */ "./src/components/loading-spinner/index.ts");
/* harmony import */ var _components_next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @components/next-link */ "./src/components/next-link/index.ts");
/* harmony import */ var _context_notification__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @context/notification */ "./src/context/notification/index.ts");
/* harmony import */ var _shared_index__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @shared/index */ "./shared/index.ts");
/* harmony import */ var _utils_route_hocs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @utils/route-hocs */ "./src/utils/route-hocs.tsx");
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! next-seo */ "./node_modules/next-seo/lib/next-seo.module.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var src_constants__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/constants */ "./src/constants.ts");
/* harmony import */ var _use_login__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./use-login */ "./src/pages/auth/login/use-login.js");



var _jsxFileName = "J:\\Project\\reference\\aws-amplify-react-auth-master-toshare\\aws-amplify-react-auth-master-toshare\\src\\pages\\auth\\login\\login.tsx",
    _s = $RefreshSig$();













const url = `${src_constants__WEBPACK_IMPORTED_MODULE_11__["FRONTEND_BASE_URL"]}${src_constants__WEBPACK_IMPORTED_MODULE_11__["ROUTE_PATHS"].LOGIN}`;
const title = 'Login';
const description = 'Sign into your account';
/* harmony default export */ __webpack_exports__["default"] = (_c = Object(_utils_route_hocs__WEBPACK_IMPORTED_MODULE_8__["withAnonymous"])(Login));

function Login() {
  _s();

  var _formErrors$email, _formErrors$password;

  const {
    handleSubmit,
    register,
    formErrors,
    isError,
    error,
    isLoading
  } = Object(_use_login__WEBPACK_IMPORTED_MODULE_12__["useLogin"])();
  const {
    addNotification
  } = Object(_context_notification__WEBPACK_IMPORTED_MODULE_6__["useNotification"])();
  Object(react__WEBPACK_IMPORTED_MODULE_10__["useEffect"])(() => {
    if (isError && error) {
      addNotification({
        type: _context_notification__WEBPACK_IMPORTED_MODULE_6__["NotificationType"].ERROR,
        title: error.message,
        message: 'Your request has failed.'
      });
    }
  }, [addNotification, error, isError]);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_seo__WEBPACK_IMPORTED_MODULE_9__["NextSeo"], {
      title: title,
      description: description,
      canonical: url,
      openGraph: {
        url,
        title,
        description
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 45,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "flex flex-col mt-12 sm:px-6 lg:px-8",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "lg:flex",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "lg:flex-1",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "mt-8 sm:mx-auto sm:w-full sm:max-w-md test",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "px-4 py-8 bg-white shadow sm:rounded-lg sm:px-10",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "sm:mx-auto sm:w-full sm:max-w-md",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "text-center",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "text-center mb-5 customheader",
                    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "text-900 text-3xl font-medium mb-3",
                      children: "Welcome Back!"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 65,
                      columnNumber: 21
                    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                      className: "text-600 font-medium line-height-3",
                      children: "Access the following Pillar life personal account:"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 66,
                      columnNumber: 21
                    }, this)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 64,
                    columnNumber: 19
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 63,
                  columnNumber: 19
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 62,
                columnNumber: 19
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("form", {
                className: "space-y-4",
                onSubmit: handleSubmit,
                noValidate: true,
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_forms__WEBPACK_IMPORTED_MODULE_1__["Label"], {
                    htmlFor: "email",
                    children: "Email"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 73,
                    columnNumber: 21
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_forms__WEBPACK_IMPORTED_MODULE_1__["Input"], {
                    type: "email",
                    id: "email",
                    name: "email",
                    placeholder: "email@address.com",
                    ref: register({
                      required: 'Email is required.',
                      validate: email => Object(_shared_index__WEBPACK_IMPORTED_MODULE_7__["isValidEmail"])(email) || 'Email address is invalid.'
                    }),
                    error: (_formErrors$email = formErrors.email) === null || _formErrors$email === void 0 ? void 0 : _formErrors$email.message,
                    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_icons_icons__WEBPACK_IMPORTED_MODULE_2__["EmailIcon"], {}, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 85,
                      columnNumber: 29
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 74,
                    columnNumber: 21
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 72,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_forms__WEBPACK_IMPORTED_MODULE_1__["Label"], {
                    htmlFor: "password",
                    children: "Password"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 90,
                    columnNumber: 21
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_forms__WEBPACK_IMPORTED_MODULE_1__["Input"], {
                    type: "password",
                    id: "password",
                    name: "password",
                    placeholder: "Password",
                    ref: register({
                      required: 'Password is required.',
                      minLength: {
                        value: 6,
                        message: 'Password must be at least 6 characters.'
                      }
                    }),
                    error: (_formErrors$password = formErrors.password) === null || _formErrors$password === void 0 ? void 0 : _formErrors$password.message,
                    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_icons_icons__WEBPACK_IMPORTED_MODULE_2__["LockIcon"], {}, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 104,
                      columnNumber: 29
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 91,
                    columnNumber: 21
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 89,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_layout__WEBPACK_IMPORTED_MODULE_3__["Flex"], {
                  className: "items-center justify-end",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_next_link__WEBPACK_IMPORTED_MODULE_5__["NextLink"], {
                    href: src_constants__WEBPACK_IMPORTED_MODULE_11__["ROUTE_PATHS"].REQUEST_PASSWORD_RESET,
                    className: "text-sm font-medium text-indigo-600 hover:text-indigo-500",
                    children: "Forgot password?"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 116,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 108,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_forms__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                    type: "submit",
                    disabled: !!isLoading,
                    isFullWidth: true,
                    children: ["Log In ", isLoading && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_loading_spinner__WEBPACK_IMPORTED_MODULE_4__["LoadingInline"], {}, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 126,
                      columnNumber: 44
                    }, this)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 125,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 124,
                  columnNumber: 19
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 71,
                columnNumber: 17
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "text-center mb-5",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  className: "text-600 font-medium line-height-3",
                  children: "Not a member? "
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 131,
                  columnNumber: 13
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  className: "font-medium no-underline ml-2 text-blue-500 cursor-pointer",
                  children: "Create an account now"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 132,
                  columnNumber: 13
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 130,
                columnNumber: 17
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 61,
              columnNumber: 15
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 59,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 57,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 56,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 55,
      columnNumber: 7
    }, this)]
  }, void 0, true);
}

_s(Login, "UE7oUpBS961EQsNUlHtP3xXg1O8=", false, function () {
  return [_use_login__WEBPACK_IMPORTED_MODULE_12__["useLogin"], _context_notification__WEBPACK_IMPORTED_MODULE_6__["useNotification"]];
});

_c2 = Login;

var _c, _c2;

$RefreshReg$(_c, "%default%");
$RefreshReg$(_c2, "Login");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL3BhZ2VzL2F1dGgvbG9naW4vbG9naW4udHN4Il0sIm5hbWVzIjpbInVybCIsIkZST05URU5EX0JBU0VfVVJMIiwiUk9VVEVfUEFUSFMiLCJMT0dJTiIsInRpdGxlIiwiZGVzY3JpcHRpb24iLCJ3aXRoQW5vbnltb3VzIiwiTG9naW4iLCJoYW5kbGVTdWJtaXQiLCJyZWdpc3RlciIsImZvcm1FcnJvcnMiLCJpc0Vycm9yIiwiZXJyb3IiLCJpc0xvYWRpbmciLCJ1c2VMb2dpbiIsImFkZE5vdGlmaWNhdGlvbiIsInVzZU5vdGlmaWNhdGlvbiIsInVzZUVmZmVjdCIsInR5cGUiLCJOb3RpZmljYXRpb25UeXBlIiwiRVJST1IiLCJtZXNzYWdlIiwicmVxdWlyZWQiLCJ2YWxpZGF0ZSIsImVtYWlsIiwiaXNWYWxpZEVtYWlsIiwibWluTGVuZ3RoIiwidmFsdWUiLCJwYXNzd29yZCIsIlJFUVVFU1RfUEFTU1dPUkRfUkVTRVQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUEsTUFBTUEsR0FBRyxHQUFJLEdBQUVDLGdFQUFrQixHQUFFQywwREFBVyxDQUFDQyxLQUFNLEVBQXJEO0FBQ0EsTUFBTUMsS0FBSyxHQUFHLE9BQWQ7QUFDQSxNQUFNQyxXQUFXLEdBQUcsd0JBQXBCO0FBRWUsb0VBQUFDLHVFQUFhLENBQUNDLEtBQUQsQ0FBNUI7O0FBRUEsU0FBU0EsS0FBVCxHQUFpQjtBQUFBOztBQUFBOztBQUNmLFFBQU07QUFDSkMsZ0JBREk7QUFFSkMsWUFGSTtBQUdKQyxjQUhJO0FBSUpDLFdBSkk7QUFLSkMsU0FMSTtBQU1KQztBQU5JLE1BT0ZDLDREQUFRLEVBUFo7QUFTQSxRQUFNO0FBQUNDO0FBQUQsTUFBb0JDLDZFQUFlLEVBQXpDO0FBRUFDLDBEQUFTLENBQUMsTUFBTTtBQUNkLFFBQUlOLE9BQU8sSUFBSUMsS0FBZixFQUFzQjtBQUNwQkcscUJBQWUsQ0FBQztBQUNkRyxZQUFJLEVBQUVDLHNFQUFnQixDQUFDQyxLQURUO0FBRWRoQixhQUFLLEVBQUVRLEtBQUssQ0FBQ1MsT0FGQztBQUdkQSxlQUFPLEVBQUU7QUFISyxPQUFELENBQWY7QUFLRDtBQUNGLEdBUlEsRUFRTixDQUFDTixlQUFELEVBQWtCSCxLQUFsQixFQUF5QkQsT0FBekIsQ0FSTSxDQUFUO0FBVUEsc0JBQ0U7QUFBQSw0QkFDRSxxRUFBQyxnREFBRDtBQUNFLFdBQUssRUFBRVAsS0FEVDtBQUVFLGlCQUFXLEVBQUVDLFdBRmY7QUFHRSxlQUFTLEVBQUVMLEdBSGI7QUFJRSxlQUFTLEVBQUU7QUFDVEEsV0FEUztBQUVUSSxhQUZTO0FBR1RDO0FBSFM7QUFKYjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREYsZUFXRTtBQUFLLGVBQVMsRUFBQyxxQ0FBZjtBQUFBLDZCQUNFO0FBQUssaUJBQVMsRUFBQyxTQUFmO0FBQUEsK0JBQ0U7QUFBSyxtQkFBUyxFQUFDLFdBQWY7QUFBQSxpQ0FFRTtBQUFLLHFCQUFTLEVBQUMsNENBQWY7QUFBQSxtQ0FFRTtBQUFLLHVCQUFTLEVBQUMsa0RBQWY7QUFBQSxzQ0FDSTtBQUFLLHlCQUFTLEVBQUMsa0NBQWY7QUFBQSx1Q0FDQTtBQUFLLDJCQUFTLEVBQUMsYUFBZjtBQUFBLHlDQUNBO0FBQUssNkJBQVMsRUFBQywrQkFBZjtBQUFBLDRDQUNFO0FBQUssK0JBQVMsRUFBQyxvQ0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw0QkFERixlQUVFO0FBQU0sK0JBQVMsRUFBQyxvQ0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBREosZUFVRTtBQUFNLHlCQUFTLEVBQUMsV0FBaEI7QUFBNEIsd0JBQVEsRUFBRUcsWUFBdEM7QUFBb0QsMEJBQVUsTUFBOUQ7QUFBQSx3Q0FDRTtBQUFBLDBDQUNFLHFFQUFDLHVEQUFEO0FBQU8sMkJBQU8sRUFBQyxPQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQURGLGVBRUUscUVBQUMsdURBQUQ7QUFDRSx3QkFBSSxFQUFDLE9BRFA7QUFFRSxzQkFBRSxFQUFDLE9BRkw7QUFHRSx3QkFBSSxFQUFDLE9BSFA7QUFJRSwrQkFBVyxFQUFDLG1CQUpkO0FBS0UsdUJBQUcsRUFBRUMsUUFBUSxDQUFDO0FBQ1phLDhCQUFRLEVBQUUsb0JBREU7QUFFWkMsOEJBQVEsRUFBRUMsS0FBSyxJQUNiQyxrRUFBWSxDQUFDRCxLQUFELENBQVosSUFBdUI7QUFIYixxQkFBRCxDQUxmO0FBVUUseUJBQUssdUJBQUVkLFVBQVUsQ0FBQ2MsS0FBYixzREFBRSxrQkFBa0JILE9BVjNCO0FBV0Usd0JBQUksZUFBRSxxRUFBQyxpRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBWFI7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBREYsZUFrQkU7QUFBQSwwQ0FDRSxxRUFBQyx1REFBRDtBQUFPLDJCQUFPLEVBQUMsVUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFERixlQUVFLHFFQUFDLHVEQUFEO0FBQ0Usd0JBQUksRUFBQyxVQURQO0FBRUUsc0JBQUUsRUFBQyxVQUZMO0FBR0Usd0JBQUksRUFBQyxVQUhQO0FBSUUsK0JBQVcsRUFBQyxVQUpkO0FBS0UsdUJBQUcsRUFBRVosUUFBUSxDQUFDO0FBQ1phLDhCQUFRLEVBQUUsdUJBREU7QUFFWkksK0JBQVMsRUFBRTtBQUNUQyw2QkFBSyxFQUFFLENBREU7QUFFVE4sK0JBQU8sRUFBRTtBQUZBO0FBRkMscUJBQUQsQ0FMZjtBQVlFLHlCQUFLLDBCQUFFWCxVQUFVLENBQUNrQixRQUFiLHlEQUFFLHFCQUFxQlAsT0FaOUI7QUFhRSx3QkFBSSxlQUFFLHFFQUFDLGdFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFiUjtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFsQkYsZUFxQ0UscUVBQUMsdURBQUQ7QUFBTSwyQkFBUyxFQUFDLDBCQUFoQjtBQUFBLHlDQVFFLHFFQUFDLDhEQUFEO0FBQ0Usd0JBQUksRUFBRW5CLDBEQUFXLENBQUMyQixzQkFEcEI7QUFFRSw2QkFBUyxFQUFDLDJEQUZaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFyQ0YsZUFxREU7QUFBQSx5Q0FDRSxxRUFBQyx3REFBRDtBQUFRLHdCQUFJLEVBQUMsUUFBYjtBQUFzQiw0QkFBUSxFQUFFLENBQUMsQ0FBQ2hCLFNBQWxDO0FBQTZDLCtCQUFXLE1BQXhEO0FBQUEsMENBQ1VBLFNBQVMsaUJBQUkscUVBQUMseUVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw0QkFEdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFyREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQVZGLGVBcUVFO0FBQUsseUJBQVMsRUFBQyxrQkFBZjtBQUFBLHdDQUNKO0FBQU0sMkJBQVMsRUFBQyxvQ0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBREksZUFFSjtBQUFHLDJCQUFTLEVBQUMsNERBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBRkk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQXJFRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBWEY7QUFBQSxrQkFERjtBQW9HRDs7R0ExSFFOLEs7VUFRSE8sb0QsRUFFc0JFLHFFOzs7TUFWbkJULEsiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvYXV0aC9sb2dpbi5jYzY5OTRlNjIzMGYwMzAxZmRhMC5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtCdXR0b24sIElucHV0LCBMYWJlbH0gZnJvbSAnQGNvbXBvbmVudHMvZm9ybXMnO1xuaW1wb3J0IHtIZWFkaW5nfSBmcm9tICdAY29tcG9uZW50cy9oZWFkaW5nL2hlYWRpbmcnO1xuaW1wb3J0IHtFbWFpbEljb24sIExvY2tJY29ufSBmcm9tICdAY29tcG9uZW50cy9pY29ucy9pY29ucyc7XG5pbXBvcnQge0ZsZXh9IGZyb20gJ0Bjb21wb25lbnRzL2xheW91dCc7XG5pbXBvcnQge0xvYWRpbmdJbmxpbmV9IGZyb20gJ0Bjb21wb25lbnRzL2xvYWRpbmctc3Bpbm5lcic7XG5pbXBvcnQge05leHRMaW5rfSBmcm9tICdAY29tcG9uZW50cy9uZXh0LWxpbmsnO1xuaW1wb3J0IHtOb3RpZmljYXRpb25UeXBlLCB1c2VOb3RpZmljYXRpb259IGZyb20gJ0Bjb250ZXh0L25vdGlmaWNhdGlvbic7XG5pbXBvcnQge2lzVmFsaWRFbWFpbH0gZnJvbSAnQHNoYXJlZC9pbmRleCc7XG5pbXBvcnQge3dpdGhBbm9ueW1vdXN9IGZyb20gJ0B1dGlscy9yb3V0ZS1ob2NzJztcbmltcG9ydCB7TmV4dFNlb30gZnJvbSAnbmV4dC1zZW8nO1xuaW1wb3J0IHt1c2VFZmZlY3R9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7RlJPTlRFTkRfQkFTRV9VUkwsIElNQUdFX1BBVEhTLCBST1VURV9QQVRIU30gZnJvbSAnc3JjL2NvbnN0YW50cyc7XG5pbXBvcnQge3VzZUxvZ2lufSBmcm9tICcuL3VzZS1sb2dpbic7XG5cbmNvbnN0IHVybCA9IGAke0ZST05URU5EX0JBU0VfVVJMfSR7Uk9VVEVfUEFUSFMuTE9HSU59YDtcbmNvbnN0IHRpdGxlID0gJ0xvZ2luJztcbmNvbnN0IGRlc2NyaXB0aW9uID0gJ1NpZ24gaW50byB5b3VyIGFjY291bnQnO1xuXG5leHBvcnQgZGVmYXVsdCB3aXRoQW5vbnltb3VzKExvZ2luKTtcblxuZnVuY3Rpb24gTG9naW4oKSB7XG4gIGNvbnN0IHtcbiAgICBoYW5kbGVTdWJtaXQsXG4gICAgcmVnaXN0ZXIsXG4gICAgZm9ybUVycm9ycyxcbiAgICBpc0Vycm9yLFxuICAgIGVycm9yLFxuICAgIGlzTG9hZGluZyxcbiAgfSA9IHVzZUxvZ2luKCk7XG5cbiAgY29uc3Qge2FkZE5vdGlmaWNhdGlvbn0gPSB1c2VOb3RpZmljYXRpb24oKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChpc0Vycm9yICYmIGVycm9yKSB7XG4gICAgICBhZGROb3RpZmljYXRpb24oe1xuICAgICAgICB0eXBlOiBOb3RpZmljYXRpb25UeXBlLkVSUk9SLFxuICAgICAgICB0aXRsZTogZXJyb3IubWVzc2FnZSxcbiAgICAgICAgbWVzc2FnZTogJ1lvdXIgcmVxdWVzdCBoYXMgZmFpbGVkLicsXG4gICAgICB9KTtcbiAgICB9XG4gIH0sIFthZGROb3RpZmljYXRpb24sIGVycm9yLCBpc0Vycm9yXSk7XG5cbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPE5leHRTZW9cbiAgICAgICAgdGl0bGU9e3RpdGxlfVxuICAgICAgICBkZXNjcmlwdGlvbj17ZGVzY3JpcHRpb259XG4gICAgICAgIGNhbm9uaWNhbD17dXJsfVxuICAgICAgICBvcGVuR3JhcGg9e3tcbiAgICAgICAgICB1cmwsXG4gICAgICAgICAgdGl0bGUsXG4gICAgICAgICAgZGVzY3JpcHRpb24sXG4gICAgICAgIH19XG4gICAgICAvPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIG10LTEyIHNtOnB4LTYgbGc6cHgtOFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxnOmZsZXhcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxnOmZsZXgtMVwiPlxuICAgICAgICAgICBcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtOCBzbTpteC1hdXRvIHNtOnctZnVsbCBzbTptYXgtdy1tZCB0ZXN0XCIgPlxuICAgICAgICAgIFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTQgcHktOCBiZy13aGl0ZSBzaGFkb3cgc206cm91bmRlZC1sZyBzbTpweC0xMFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpteC1hdXRvIHNtOnctZnVsbCBzbTptYXgtdy1tZFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBtYi01IGN1c3RvbWhlYWRlclwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtOTAwIHRleHQtM3hsIGZvbnQtbWVkaXVtIG1iLTNcIj5XZWxjb21lIEJhY2shPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtNjAwIGZvbnQtbWVkaXVtIGxpbmUtaGVpZ2h0LTNcIj5BY2Nlc3MgdGhlIGZvbGxvd2luZyBQaWxsYXIgbGlmZSBwZXJzb25hbCBhY2NvdW50Ojwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJzcGFjZS15LTRcIiBvblN1Ym1pdD17aGFuZGxlU3VibWl0fSBub1ZhbGlkYXRlPlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPExhYmVsIGh0bWxGb3I9XCJlbWFpbFwiPkVtYWlsPC9MYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImVtYWlsXCJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cImVtYWlsXCJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZW1haWxcIlxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZW1haWxAYWRkcmVzcy5jb21cIlxuICAgICAgICAgICAgICAgICAgICAgIHJlZj17cmVnaXN0ZXIoe1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWQ6ICdFbWFpbCBpcyByZXF1aXJlZC4nLFxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdGU6IGVtYWlsID0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlzVmFsaWRFbWFpbChlbWFpbCkgfHwgJ0VtYWlsIGFkZHJlc3MgaXMgaW52YWxpZC4nLFxuICAgICAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgICAgICAgIGVycm9yPXtmb3JtRXJyb3JzLmVtYWlsPy5tZXNzYWdlfVxuICAgICAgICAgICAgICAgICAgICAgIGljb249ezxFbWFpbEljb24gLz59XG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPExhYmVsIGh0bWxGb3I9XCJwYXNzd29yZFwiPlBhc3N3b3JkPC9MYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiUGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgICAgIHJlZj17cmVnaXN0ZXIoe1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWQ6ICdQYXNzd29yZCBpcyByZXF1aXJlZC4nLFxuICAgICAgICAgICAgICAgICAgICAgICAgbWluTGVuZ3RoOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlOiA2LFxuICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiAnUGFzc3dvcmQgbXVzdCBiZSBhdCBsZWFzdCA2IGNoYXJhY3RlcnMuJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgZXJyb3I9e2Zvcm1FcnJvcnMucGFzc3dvcmQ/Lm1lc3NhZ2V9XG4gICAgICAgICAgICAgICAgICAgICAgaWNvbj17PExvY2tJY29uIC8+fVxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgPEZsZXggY2xhc3NOYW1lPVwiaXRlbXMtY2VudGVyIGp1c3RpZnktZW5kXCI+XG4gICAgICAgICAgICAgICAgICAgIHsvKiA8TmV4dExpbmtcbiAgICAgICAgICAgICAgICAgICAgICBocmVmPXtST1VURV9QQVRIUy5SRUdJU1RFUn1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtaW5kaWdvLTYwMCBob3Zlcjp0ZXh0LWluZGlnby01MDBcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgRG8gbm90IGhhdmUgYW4gYWNjb3VudD9cbiAgICAgICAgICAgICAgICAgICAgPC9OZXh0TGluaz4gKi99XG5cbiAgICAgICAgICAgICAgICAgICAgPE5leHRMaW5rXG4gICAgICAgICAgICAgICAgICAgICAgaHJlZj17Uk9VVEVfUEFUSFMuUkVRVUVTVF9QQVNTV09SRF9SRVNFVH1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtaW5kaWdvLTYwMCBob3Zlcjp0ZXh0LWluZGlnby01MDBcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgRm9yZ290IHBhc3N3b3JkP1xuICAgICAgICAgICAgICAgICAgICA8L05leHRMaW5rPlxuICAgICAgICAgICAgICAgICAgPC9GbGV4PlxuXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBkaXNhYmxlZD17ISFpc0xvYWRpbmd9IGlzRnVsbFdpZHRoPlxuICAgICAgICAgICAgICAgICAgICAgIExvZyBJbiB7aXNMb2FkaW5nICYmIDxMb2FkaW5nSW5saW5lIC8+fVxuICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIG1iLTVcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtNjAwIGZvbnQtbWVkaXVtIGxpbmUtaGVpZ2h0LTNcIj5Ob3QgYSBtZW1iZXI/IDwvc3Bhbj5cbiAgICAgICAgICAgIDxhIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIG5vLXVuZGVybGluZSBtbC0yIHRleHQtYmx1ZS01MDAgY3Vyc29yLXBvaW50ZXJcIj5DcmVhdGUgYW4gYWNjb3VudCBub3c8L2E+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgXG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC8+XG4gICk7XG59XG4iXSwic291cmNlUm9vdCI6IiJ9