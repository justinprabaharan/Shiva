import CompleteRegistration from './complete-registration';

export default CompleteRegistration;
